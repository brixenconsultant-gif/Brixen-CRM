import os
import sys
import json
import re
import urllib.parse
import mimetypes
from wsgiref.simple_server import make_server
from db import query_db, execute_db, hash_password, verify_password, needs_rehash, unusable_password_hash, get_db, ensure_schema

PORT = int(os.environ.get('PORT', '5050'))
HOST = os.environ.get('HOST', '127.0.0.1')
PORTAL_HOSTS = frozenset({
    '127.0.0.1',
    'localhost',
    '::1',
    'portal.brixenconsultants.com',
})
ALLOWED_CORS_ORIGINS = frozenset({
    'https://brixenconsultants.com',
    'https://www.brixenconsultants.com',
    'https://portal.brixenconsultants.com',
    'http://portal.brixenconsultants.com',
    'http://portal.brixenconsultants.com:5050',
    'https://portal.brixenconsultants.com:5050',
    'http://127.0.0.1:5050',
    'http://localhost:5050',
})
INTERNAL_STAFF_ROLES = ('SUPER_ADMIN', 'ADMIN', 'MANAGER', 'STAFF')
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, 'static')
TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')

import uuid
import datetime
import calendar
import hmac
import hashlib

# Storage directory for private client files (P2)
STORAGE_DIR = os.path.join(BASE_DIR, 'storage')
os.makedirs(STORAGE_DIR, exist_ok=True)

# P1: Persistent Database-Backed Session Management
def create_db_session(user_id):
    token = str(uuid.uuid4())
    execute_db("""
        INSERT INTO user_sessions (session_token, user_id, expires_at)
        VALUES (?, ?, datetime('now', '+30 days'));
    """, (token, user_id))
    return token

def revoke_db_session(token):
    if not token: return
    execute_db("""
        UPDATE user_sessions SET revoked_at = datetime('now') WHERE session_token = ?;
    """, (token,))

def get_current_user(environ):
    cookie_str = environ.get('HTTP_COOKIE', '')
    token = None
    if 'session_token=' in cookie_str:
        for c in cookie_str.split(';'):
            c = c.strip()
            if c.startswith('session_token='):
                token = c.split('=', 1)[1]
                break
    if not token:
        auth_hdr = environ.get('HTTP_AUTHORIZATION', '')
        if auth_hdr.startswith('Bearer '):
            token = auth_hdr.split(' ', 1)[1]
            
    if token:
        session_rec = query_db("""
            SELECT s.session_token, u.* 
            FROM user_sessions s
            JOIN users u ON s.user_id = u.id
            WHERE s.session_token = ? 
              AND s.revoked_at IS NULL 
              AND s.expires_at > datetime('now');
        """, (token,), one=True)
        
        if session_rec:
            # Update last activity timestamp
            execute_db("UPDATE user_sessions SET last_activity_at = datetime('now') WHERE session_token = ?;", (token,))
            return dict(session_rec)
    return None

# P4: Email Notification Gateway Abstraction
class EmailService:
    @staticmethod
    def send_notification_email(recipient_email, subject, body_text):
        smtp_host = os.environ.get('SMTP_HOST')
        smtp_port = os.environ.get('SMTP_PORT', '587')
        smtp_user = os.environ.get('SMTP_USER')
        smtp_pass = os.environ.get('SMTP_PASS')
        smtp_from = os.environ.get('SMTP_FROM', 'noreply@brixenconsultants.com')
        
        if not smtp_host or not smtp_user:
            print(f"[EmailService Log] Email to {recipient_email} ('{subject}') - SMTP not configured.")
            return False, "SMTP not configured"
            
        import smtplib
        from email.mime.text import MIMEText
        try:
            msg = MIMEText(body_text)
            msg['Subject'] = subject
            msg['From'] = smtp_from
            msg['To'] = recipient_email
            
            with smtplib.SMTP(smtp_host, int(smtp_port)) as server:
                server.starttls()
                server.login(smtp_user, smtp_pass)
                server.sendmail(smtp_from, [recipient_email], msg.as_string())
            print(f"[EmailService Success] Dispatched email to {recipient_email}")
            return True, "Delivered"
        except Exception as err:
            print(f"[EmailService Error] Failed to send email: {err}")
            return False, str(err)

def json_response(start_response, data, status="200 OK", extra_headers=None):
    body = json.dumps(data).encode('utf-8')
    headers = [
        ('Content-Type', 'application/json; charset=utf-8'),
        ('Content-Length', str(len(body))),
    ]
    if extra_headers:
        headers.extend(extra_headers)
    start_response(status, headers)
    return [body]

def cookie_should_be_secure(environ=None):
    """Use Secure cookies on HTTPS. Omit Secure on local HTTP so the browser can store the session."""
    override = os.environ.get('COOKIE_SECURE')
    if override is not None and str(override).strip() != '':
        return str(override).strip().lower() in ('1', 'true', 'yes', 'on')
    if not environ:
        return True
    forwarded = (environ.get('HTTP_X_FORWARDED_PROTO') or '').split(',')[0].strip().lower()
    scheme = forwarded or (environ.get('wsgi.url_scheme') or 'http').lower()
    if scheme == 'https' or environ.get('HTTPS') in ('on', '1'):
        return True
    host = (environ.get('HTTP_HOST') or environ.get('SERVER_NAME') or '').split(':')[0].lower()
    if host in PORTAL_HOSTS:
        return False
    return True


def _cookie_flag_suffix(environ=None):
    flags = 'Path=/; HttpOnly; SameSite=Lax'
    if cookie_should_be_secure(environ):
        flags += '; Secure'
    return flags


def session_cookie_header(token=None, clear=False, environ=None):
    flags = _cookie_flag_suffix(environ)
    if clear:
        return f'session_token=; {flags}; Expires=Thu, 01 Jan 1970 00:00:00 GMT'
    return f'session_token={token}; {flags}'


def origin_cookie_header(token=None, clear=False, environ=None):
    flags = _cookie_flag_suffix(environ)
    if clear:
        return f'origin_session=; {flags}; Expires=Thu, 01 Jan 1970 00:00:00 GMT'
    return f'origin_session={token}; {flags}'

def cookie_value(environ, name):
    cookie_str = environ.get('HTTP_COOKIE', '')
    prefix = name + '='
    for part in cookie_str.split(';'):
        part = part.strip()
        if part.startswith(prefix):
            return part.split('=', 1)[1]
    return None

def session_user_from_token(token):
    if not token:
        return None
    return query_db("""
        SELECT s.session_token, u.*
        FROM user_sessions s
        JOIN users u ON s.user_id = u.id
        WHERE s.session_token = ?
          AND s.revoked_at IS NULL
          AND s.expires_at > datetime('now');
    """, (token,), one=True)

def public_me_user(user, impersonated=False):
    if not user:
        return None
    src = dict(user)
    return {
        'id': src.get('id'),
        'wordpress_user_id': src.get('wordpress_user_id'),
        'email': src.get('email'),
        'full_name': src.get('full_name'),
        'phone': src.get('phone'),
        'country': src.get('country'),
        'address': src.get('address'),
        'status': src.get('status'),
        'role': src.get('role'),
        'department': (departments_from_user(src) or [None])[0],
        'departments': departments_from_user(src),
        'impersonated': bool(impersonated)
    }

def can_impersonate_user(actor, target):
    if not actor or not target:
        return False
    if actor.get('id') == target.get('id'):
        return False
    if target.get('status') != 'Active':
        return False
    if target.get('role') not in INTERNAL_STAFF_ROLES:
        return False
    if not check_permission(actor, 'staff.manage'):
        return False
    if actor.get('role') == 'SUPER_ADMIN':
        return True
    return ROLE_RANK.get(target.get('role'), 99) < ROLE_RANK.get(actor.get('role'), 0)

def cors_allowed_origin(environ):
    origin = environ.get('HTTP_ORIGIN', '')
    if origin in ALLOWED_CORS_ORIGINS:
        return origin
    return None

def is_internal_staff(user):
    return bool(user and user.get('role') in INTERNAL_STAFF_ROLES)

def _is_path_inside(root_dir, target_path):
    root_real = os.path.realpath(root_dir)
    target_real = os.path.realpath(target_path)
    try:
        common = os.path.commonpath([root_real, target_real])
    except ValueError:
        return False
    return common == root_real

def serve_static(environ, start_response, filepath, allowed_root=None):
    if allowed_root and not _is_path_inside(allowed_root, filepath):
        start_response("403 Forbidden", [('Content-Type', 'text/plain; charset=utf-8')])
        return [b"Forbidden"]
    if not os.path.exists(filepath) or os.path.isdir(filepath):
        start_response("404 Not Found", [('Content-Type', 'text/plain')])
        return [b"404 File Not Found"]
    
    ctype, _ = mimetypes.guess_type(filepath)
    if not ctype:
        ctype = 'application/octet-stream'
        
    with open(filepath, 'rb') as f:
        content = f.read()
        
    headers = [
        ('Content-Type', ctype),
        ('Content-Length', str(len(content))),
    ]
    if filepath.endswith('.html') or filepath.endswith('.js') or filepath.endswith('.css'):
        headers.append(('Cache-Control', 'no-store, no-cache, must-revalidate'))
        headers.append(('Pragma', 'no-cache'))
    start_response("200 OK", headers)
    return [content]

def parse_body(environ):
    try:
        content_length = int(environ.get('CONTENT_LENGTH', 0))
    except (ValueError, TypeError):
        content_length = 0
    if content_length > 0:
        raw_body = environ['wsgi.input'].read(content_length).decode('utf-8')
        try:
            return json.loads(raw_body)
        except json.JSONDecodeError:
            return dict(urllib.parse.parse_qsl(raw_body))
    return {}

def log_activity(user, action, entity_type=None, entity_id=None, details=None):
    uid = user['id'] if user else None
    email = user['email'] if user else 'SYSTEM'
    execute_db("""
        INSERT INTO activity_logs (user_id, user_email, action, entity_type, entity_id, details)
        VALUES (?, ?, ?, ?, ?, ?);
    """, (uid, email, action, entity_type, entity_id, details))

import hmac
import hashlib

# Storage directory for private client files
STORAGE_DIR = os.environ.get('STORAGE_PATH') or os.path.join(BASE_DIR, 'storage')
os.makedirs(STORAGE_DIR, exist_ok=True)

def verify_webhook_signature(raw_body_bytes, signature_hdr):
    if not signature_hdr:
        return False
    row = query_db("SELECT value FROM settings WHERE key = 'wordpress_webhook_secret';", one=True)
    secret = (row['value'] if row and row['value'] else None) or os.environ.get('WORDPRESS_WEBHOOK_SECRET')
    if not secret:
        return False
    clean_sig = signature_hdr.replace('sha256=', '').strip()
    expected = hmac.new(secret.encode('utf-8'), raw_body_bytes, hashlib.sha256).hexdigest()
    return hmac.compare_digest(clean_sig, expected)

PERMISSION_ACCESS = {
    'clients.view': ('New Signups',),
    'clients.edit': ('New Signups',),
    'clients.create': ('New Signups',),
    'orders.view': ('Orders', 'Support'),
    'orders.edit': ('Orders', 'Support'),
    'documents.view': ('Documents', 'Compliance'),
    'documents.upload': ('Documents', 'Compliance'),
    'documents.send': ('Documents', 'Compliance'),
    'invoices.view': ('Accounts',),
}

def check_permission(user, permission_name):
    if not user:
        return False
    if user['role'] in ('SUPER_ADMIN', 'ADMIN'):
        return True
    row = query_db("""
        SELECT 1 FROM role_permissions rp
        JOIN roles r ON rp.role_id = r.id
        JOIN permissions p ON rp.permission_id = p.id
        WHERE r.name = ? AND p.name = ?;
    """, (user['role'], permission_name), one=True)
    if not row:
        return False
    if user['role'] != 'STAFF':
        return True
    needed = PERMISSION_ACCESS.get(permission_name)
    if not needed:
        return True
    granted = set(departments_from_user(user))
    return bool(granted.intersection(needed))

def require_permission(start_response, user, permission_name):
    if not user:
        return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
    if not check_permission(user, permission_name):
        return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
    return None


def can_view_admin_dashboard(user):
    return bool(user and user.get('role') in ('SUPER_ADMIN', 'ADMIN', 'MANAGER'))

def can_view_revenue(user):
    return bool(user and user.get('role') in ('SUPER_ADMIN', 'ADMIN'))

TASK_PRIORITIES = ('Low', 'Medium', 'High', 'Urgent')
TASK_STATUSES = ('Open', 'In Progress', 'Completed', 'Cancelled')
TASK_ASSIGNABLE_ROLES = ('STAFF', 'MANAGER', 'ADMIN', 'SUPER_ADMIN')
STAFF_DEPARTMENTS = (
    'New Signups',
    'Orders',
    'Documents',
    'Support',
    'Compliance',
    'Accounts',
    'General',
)
USER_ROLES = ('SUPER_ADMIN', 'ADMIN', 'MANAGER', 'STAFF', 'CLIENT')
USER_STATUSES = ('Active', 'Suspended', 'Pending')
ROLE_RANK = {
    'CLIENT': 0,
    'STAFF': 1,
    'MANAGER': 2,
    'ADMIN': 3,
    'SUPER_ADMIN': 4,
}
STAFF_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
STAFF_MIN_PASSWORD_LEN = 10
STAFF_PUBLIC_FIELDS = (
    'id', 'wordpress_user_id', 'email', 'full_name', 'phone', 'country',
    'role', 'department', 'status', 'avatar_url', 'created_at'
)
TASK_DETAIL_SQL = """
    SELECT t.*,
        a.full_name AS assigned_staff_name,
        a.email AS assigned_staff_email,
        cr.full_name AS created_by_name,
        cl.full_name AS client_name,
        cl.email AS client_email,
        c.name AS company_name,
        o.order_number
    FROM tasks t
    LEFT JOIN users a ON t.assigned_staff_id = a.id
    LEFT JOIN users cr ON t.created_by_id = cr.id
    LEFT JOIN users cl ON t.client_id = cl.id
    LEFT JOIN companies c ON t.company_id = c.id
    LEFT JOIN orders o ON t.order_id = o.id
"""

def task_auth_error(start_response, user, permission_name):
    if not user:
        return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
    if not check_permission(user, permission_name):
        return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
    return None

def normalize_department(value):
    if value is None:
        return None, None
    department = str(value).strip()
    if not department:
        return None, None
    if department not in STAFF_DEPARTMENTS:
        return None, 'Department must be one of: ' + ', '.join(STAFF_DEPARTMENTS)
    return department, None


def parse_departments(value):
    if value is None or value == '' or value == []:
        return [], None
    if isinstance(value, (list, tuple)):
        items = list(value)
    else:
        text = str(value).strip()
        if not text:
            return [], None
        if text.startswith('['):
            try:
                parsed = json.loads(text)
                items = parsed if isinstance(parsed, list) else [text]
            except Exception:
                items = [text]
        else:
            items = [part.strip() for part in text.split(',') if part.strip()]
    out = []
    for item in items:
        dept, err = normalize_department(item)
        if err:
            return None, err
        if dept and dept not in out:
            out.append(dept)
    return out, None


def store_departments(departments):
    return json.dumps(departments) if departments else None


def departments_from_user(user):
    depts, _ = parse_departments((user or {}).get('department'))
    extra, _ = parse_departments((user or {}).get('departments'))
    merged = []
    for dept in (depts or []) + (extra or []):
        if dept not in merged:
            merged.append(dept)
    return merged


def staff_can_access_task(user, task):
    if not user or not task:
        return False
    if user['role'] == 'STAFF':
        if task.get('assigned_staff_id') == user['id']:
            return True
        staff_depts = departments_from_user(user)
        task_dept = (task.get('department') or '').strip()
        return (not task.get('assigned_staff_id')) and bool(task_dept) and task_dept in staff_depts
    if user['role'] in ('SUPER_ADMIN', 'ADMIN', 'MANAGER'):
        return True
    return False

def to_optional_int(value, field_name):
    if value is None or value == '' or value == 'null':
        return None, None
    try:
        return int(value), None
    except (TypeError, ValueError):
        return None, f'Invalid {field_name}'

def fetch_task(task_id):
    return query_db(TASK_DETAIL_SQL + " WHERE t.id = ?;", (task_id,), one=True)

def public_staff_user(row):
    if not row:
        return None
    src = dict(row)
    public = {key: src.get(key) for key in STAFF_PUBLIC_FIELDS}
    depts = departments_from_user(src)
    public['departments'] = depts
    public['department'] = depts[0] if depts else None
    return public


def creatable_roles_for(user):
    if not user:
        return ()
    actor_rank = ROLE_RANK.get(user.get('role'))
    if actor_rank is None:
        return ()
    allowed = []
    for role in USER_ROLES:
        needed = 'clients.create' if role == 'CLIENT' else 'staff.manage'
        if not check_permission(user, needed):
            continue
        target_rank = ROLE_RANK[role]
        if user['role'] == 'SUPER_ADMIN' or target_rank < actor_rank:
            allowed.append(role)
    return tuple(allowed)


def creatable_staff_roles_for(user):
    return tuple(role for role in creatable_roles_for(user) if role != 'CLIENT')


ORDER_STATUSES = (
    'Pending', 'Processing', 'In Progress', 'Completed',
    'Cancelled', 'Refunded', 'Pending Verification'
)
ORDER_PAYMENT_MODES = (
    'PKR(Bank Transfer)',
    'GBP(Bank Transfer)',
    'Website Charge',
)


def can_delete_orders(user):
    return bool(user and user.get('role') in ('SUPER_ADMIN', 'ADMIN'))


def staff_can_access_admin_order(user, order):
    if not user or not order:
        return False
    if user.get('role') in ('SUPER_ADMIN', 'ADMIN', 'STAFF'):
        return True
    if user.get('role') == 'MANAGER':
        assignee_id = order.get('assigned_staff_id')
        if assignee_id in (None, user['id']):
            return True
        assignee = query_db("SELECT role FROM users WHERE id = ?;", (assignee_id,), one=True)
        return bool(assignee and assignee.get('role') == 'STAFF')
    return False


def remove_stored_document_files(file_paths):
    storage_root = os.path.abspath(STORAGE_DIR)
    for path in file_paths:
        if not path:
            continue
        if not _is_path_inside(storage_root, path):
            continue
        try:
            if os.path.isfile(path):
                os.remove(path)
        except OSError:
            pass


def validate_task_assignee(assigned_staff_id):
    if assigned_staff_id is None:
        return True, None
    rec = query_db("SELECT id, role, status FROM users WHERE id = ?;", (assigned_staff_id,), one=True)
    if not rec:
        return False, 'Assigned staff not found'
    if rec['role'] not in TASK_ASSIGNABLE_ROLES:
        return False, 'Assignee must be an internal staff user'
    if rec['status'] != 'Active':
        return False, 'Assignee is not an active user'
    return True, None

def validate_task_links(client_id, company_id, order_id):
    resolved_client = client_id
    resolved_company = company_id
    resolved_order = order_id

    if order_id is not None:
        order = query_db("SELECT id, user_id, company_id FROM orders WHERE id = ?;", (order_id,), one=True)
        if not order:
            return False, 'Order not found', None, None, None
        if resolved_client is None:
            resolved_client = order['user_id']
        elif int(resolved_client) != int(order['user_id']):
            return False, 'Order does not belong to the specified client', None, None, None
        if resolved_company is None:
            resolved_company = order['company_id']
        elif order['company_id'] is not None and int(resolved_company) != int(order['company_id']):
            return False, 'Order does not belong to the specified company', None, None, None

    if resolved_company is not None:
        company = query_db("SELECT id, user_id FROM companies WHERE id = ?;", (resolved_company,), one=True)
        if not company:
            return False, 'Company not found', None, None, None
        if resolved_client is None:
            resolved_client = company['user_id']
        elif int(resolved_client) != int(company['user_id']):
            return False, 'Company does not belong to the specified client', None, None, None

    if resolved_client is not None:
        client = query_db("SELECT id, role FROM users WHERE id = ?;", (resolved_client,), one=True)
        if not client:
            return False, 'Client not found', None, None, None
        if client['role'] != 'CLIENT':
            return False, 'client_id must refer to a CLIENT user', None, None, None

    return True, None, resolved_client, resolved_company, resolved_order

def notify_staff_task(recipient_id, actor_id, title, message, ntype):
    if not recipient_id or recipient_id == actor_id:
        return
    recipient = query_db("SELECT id, email, full_name, role FROM users WHERE id = ?;", (recipient_id,), one=True)
    if not recipient or recipient['role'] == 'CLIENT':
        return
    execute_db("""
        INSERT INTO notifications (user_id, title, message, type, link)
        VALUES (?, ?, ?, ?, ?);
    """, (recipient_id, title, message, ntype, '#admin-tasks'))
    EmailService.send_notification_email(
        recipient['email'],
        f"{title} - Brixen Consultants Portal",
        f"Hello {recipient['full_name']},\n\n{message}\n\nLog in to the Brixen Portal to review: {portal_page_url()}"
    )

def portal_base_url():
    return (os.environ.get('CRM_BASE_URL') or 'https://portal.brixenconsultants.com').rstrip('/')


def portal_page_url():
    return (os.environ.get('PORTAL_PAGE_URL') or portal_base_url()).rstrip('/')


def portal_alias_urls():
    return (
        'https://portal.brixenconsultants.com',
        'http://127.0.0.1:5050',
    )


def company_country_label(row):
    src = dict(row or {})
    country = str(src.get('country') or '').strip()
    if country:
        return country
    office = str(src.get('reg_office') or '')
    if re.search(r'united kingdom|\blondon\b|\buk\b', office, re.I):
        return 'United Kingdom'
    if office and ',' in office:
        return office.split(',')[-1].strip() or '—'
    return '—'


def public_client_company(row, deadlines=None):
    if not row:
        return None
    src = dict(row)
    return {
        'id': src.get('id'),
        'name': src.get('name'),
        'company_number': src.get('company_number'),
        'status': src.get('status') or 'Active',
        'inc_date': src.get('inc_date'),
        'director': src.get('director'),
        'reg_office': src.get('reg_office'),
        'package': src.get('package'),
        'account_status': src.get('account_status'),
        'country': company_country_label(src),
        'created_at': src.get('created_at'),
        'deadlines': list(deadlines or []),
    }


def upcoming_deadlines_by_company(user_id, company_ids):
    mapping = {int(cid): [] for cid in company_ids or [] if cid}
    if not mapping:
        return mapping
    placeholders = ','.join('?' for _ in mapping)
    today = datetime.date.today().isoformat()
    ids = list(mapping.keys())
    user_clause = "WHERE user_id = ? AND" if user_id is not None else "WHERE"
    params = [user_id, *ids, today] if user_id is not None else [*ids, today]
    address_rows = query_db(
        f"""
        SELECT company_id, type, expiry_date
        FROM addresses
        {user_clause} company_id IN ({placeholders})
          AND expiry_date IS NOT NULL AND date(expiry_date) >= date(?)
        ORDER BY expiry_date ASC;
        """,
        params,
    )
    for row in address_rows:
        cid = int(row['company_id'])
        label = f"{row['type']} expiry" if row.get('type') else 'Address expiry'
        mapping[cid].append({'label': label, 'date': row.get('expiry_date')})
    agent_rows = query_db(
        f"""
        SELECT company_id, renewal_date
        FROM registered_agents
        {user_clause} company_id IN ({placeholders})
          AND renewal_date IS NOT NULL AND date(renewal_date) >= date(?)
        ORDER BY renewal_date ASC;
        """,
        params,
    )
    for row in agent_rows:
        cid = int(row['company_id'])
        mapping[cid].append({'label': 'Registered agent renewal', 'date': row.get('renewal_date')})
    return mapping


def public_client_order_summary(row):
    if not row:
        return None
    src = dict(row)
    return {
        'id': src.get('id'),
        'order_number': src.get('order_number'),
        'service_name': src.get('service_name'),
        'status': src.get('status'),
        'progress_percent': src.get('progress_percent'),
        'created_at': src.get('created_at'),
        'expected_date': src.get('expected_date'),
    }


def public_client_ticket_summary(row):
    if not row:
        return None
    src = dict(row)
    return {
        'id': src.get('id'),
        'ticket_number': src.get('ticket_number'),
        'subject': src.get('subject'),
        'category': src.get('category'),
        'priority': src.get('priority'),
        'status': src.get('status'),
        'created_at': src.get('created_at'),
    }


def public_document(row, for_client=False):
    if not row:
        return None
    src = dict(row)
    out = {
        'id': src.get('id'),
        'user_id': src.get('user_id'),
        'company_id': src.get('company_id'),
        'order_id': src.get('order_id'),
        'name': src.get('name'),
        'category': src.get('category'),
        'file_type': src.get('file_type'),
        'file_size': src.get('file_size'),
        'status': src.get('status'),
        'uploaded_by': src.get('uploaded_by'),
        'created_at': src.get('created_at'),
        'company_name': src.get('company_name'),
        'order_number': src.get('order_number'),
        'client_name': src.get('client_name'),
        'client_email': src.get('client_email'),
        'client_visible': int(src.get('client_visible') or 0),
        'shared_at': src.get('shared_at'),
    }
    if not for_client:
        out['review_notes'] = src.get('review_notes')
    return out


ALLOWED_DOCUMENT_EXTS = ('.pdf', '.png', '.jpg', '.jpeg', '.doc', '.docx', '.zip')
MAX_DOCUMENT_BYTES = 15 * 1024 * 1024
DOCUMENT_TYPE_LABELS = {
    '.pdf': 'PDF Document',
    '.png': 'PNG Image',
    '.jpg': 'JPEG Image',
    '.jpeg': 'JPEG Image',
    '.doc': 'Word Document',
    '.docx': 'Word Document',
    '.zip': 'ZIP Archive',
}


def optional_record_id(value):
    if value in (None, '', False):
        return None
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def document_extension(original_name):
    return os.path.splitext(os.path.basename(str(original_name or '')))[1].lower()


def decode_document_base64(b64_content, default_bytes=None):
    if not b64_content:
        return default_bytes, None
    import base64
    try:
        return base64.b64decode(b64_content), None
    except Exception:
        return None, 'Invalid base64 payload'


def validate_uploaded_document(original_name, file_bytes, require_bytes=False):
    ext = document_extension(original_name)
    if ext not in ALLOWED_DOCUMENT_EXTS:
        return None, 'Invalid file format'
    if require_bytes and not file_bytes:
        return None, 'File is required'
    if file_bytes is not None and len(file_bytes) > MAX_DOCUMENT_BYTES:
        return None, 'File is too large'
    return ext, None


def store_client_document_file(client_id, order_id, ext, file_bytes):
    order_folder = str(order_id or 'general')
    storage_root = os.path.abspath(STORAGE_DIR)
    client_dir = os.path.abspath(os.path.join(STORAGE_DIR, 'clients', str(client_id), 'orders', order_folder, 'documents'))
    os.makedirs(client_dir, exist_ok=True)
    target_path = os.path.abspath(os.path.join(client_dir, f"{uuid.uuid4().hex}{ext}"))
    if not target_path.startswith(storage_root):
        return None, 'Path traversal attempt blocked'
    with open(target_path, 'wb') as handle:
        handle.write(file_bytes)
    return target_path, None


def format_document_size(num_bytes):
    if num_bytes >= 1024:
        return f"{num_bytes / 1024:.1f} KB"
    return f"{num_bytes} B"


def resolve_client_document_links(client_id, company_id, order_id):
    client = query_db("SELECT id, email, full_name, role FROM users WHERE id = ?;", (client_id,), one=True)
    if not client:
        return None, 'Client not found'
    company = None
    order = None
    if company_id:
        company = query_db("SELECT * FROM companies WHERE id = ?;", (company_id,), one=True)
        if not company or int(company['user_id']) != int(client['id']):
            return None, 'Company does not belong to this client'
    if order_id:
        order = query_db("SELECT * FROM orders WHERE id = ?;", (order_id,), one=True)
        if not order or int(order['user_id']) != int(client['id']):
            return None, 'Order does not belong to this client'
        if company_id and order.get('company_id') and int(order['company_id']) != int(company_id):
            return None, 'Order does not belong to the selected company'
    return {'client': client, 'company': company, 'order': order}, None


def notify_client_document_uploaded(client, doc_name, client_message=None):
    title = 'New document available'
    message = 'A new document has been uploaded to your Brixen Client Portal. Please log in to view it.'
    extra = (client_message or '').strip()
    if extra:
        message = f"{message} {extra}"
    execute_db("""
        INSERT INTO notifications (user_id, title, message, type, link)
        VALUES (?, ?, ?, ?, ?);
    """, (client['id'], title, message, 'document_uploaded', '/documents'))
    email_body = (
        f"Hello {client['full_name']},\n\n"
        "A new document has been uploaded to your Brixen Client Portal.\n\n"
        f"Document:\n{doc_name}\n"
    )
    if extra:
        email_body += f"\n{extra}\n"
    email_body += (
        "\nPlease log in to your Client Portal to view the document.\n\n"
        f"{portal_page_url()}\n\n"
        "Kind regards,\nBrixen Consultants"
    )
    sent, status = EmailService.send_notification_email(
        client['email'],
        'New document available in your Brixen Client Portal',
        email_body
    )
    return {
        'notification_created': True,
        'email_sent': bool(sent),
        'email_status': status,
    }


def public_line_item(row, for_client=False):
    if not row:
        return None
    src = dict(row)
    item = {
        'product_name': src.get('product_name'),
        'category_name': src.get('category_name'),
        'quantity': src.get('quantity'),
        'unit_price': src.get('unit_price'),
        'line_total': src.get('line_total'),
    }
    if not for_client:
        item.update({
            'woocommerce_product_id': src.get('woocommerce_product_id'),
            'woocommerce_variation_id': src.get('woocommerce_variation_id'),
            'sku': src.get('sku'),
            'category_id': src.get('category_id'),
        })
    return item


def parse_line_items_from_payload(o_data):
    raw = o_data.get('line_items') or o_data.get('items') or []
    parsed = []
    if isinstance(raw, list):
        for idx, item in enumerate(raw):
            if isinstance(item, str):
                parsed.append({
                    'product_name': item,
                    'quantity': 1,
                    'unit_price': None,
                    'line_total': None,
                    'sort_order': idx,
                })
                continue
            if not isinstance(item, dict):
                continue
            cats = item.get('categories') or []
            first_cat = cats[0] if cats and isinstance(cats[0], dict) else {}
            name = (item.get('product_name') or item.get('name') or item.get('service_name') or '').strip()
            if not name:
                continue
            qty = item.get('quantity') if item.get('quantity') not in (None, '') else 1
            try:
                qty = int(qty)
            except (TypeError, ValueError):
                qty = 1
            unit = item.get('unit_price') if item.get('unit_price') not in (None, '') else item.get('price')
            total = item.get('line_total') if item.get('line_total') not in (None, '') else item.get('total')
            try:
                unit = float(unit) if unit is not None else None
            except (TypeError, ValueError):
                unit = None
            try:
                total = float(total) if total is not None else None
            except (TypeError, ValueError):
                total = None
            parsed.append({
                'woocommerce_product_id': item.get('product_id') or item.get('woocommerce_product_id'),
                'woocommerce_variation_id': item.get('variation_id') or item.get('woocommerce_variation_id'),
                'sku': item.get('sku'),
                'product_name': name,
                'category_name': item.get('category') or item.get('category_name') or first_cat.get('name'),
                'category_id': item.get('category_id') or first_cat.get('id'),
                'quantity': max(qty, 1),
                'unit_price': unit,
                'line_total': total,
                'sort_order': idx,
            })
    if not parsed:
        fallback_name = (o_data.get('service_name') or '').strip()
        if fallback_name:
            parsed.append({
                'woocommerce_product_id': o_data.get('product_id'),
                'woocommerce_variation_id': o_data.get('variation_id'),
                'sku': o_data.get('sku'),
                'product_name': fallback_name,
                'category_name': o_data.get('category') or o_data.get('category_name'),
                'category_id': o_data.get('category_id'),
                'quantity': 1,
                'unit_price': None,
                'line_total': None,
                'sort_order': 0,
            })
    return parsed


def replace_order_line_items(order_id, items, order_price=None, order_total=None):
    execute_db("DELETE FROM order_line_items WHERE order_id = ?;", (order_id,))
    count = max(len(items), 1)
    for item in items:
        unit = item.get('unit_price')
        total = item.get('line_total')
        qty = item.get('quantity') or 1
        if unit is None and total is not None:
            unit = round(float(total) / qty, 2)
        if total is None and unit is not None:
            total = round(float(unit) * qty, 2)
        if unit is None and order_price is not None:
            unit = round(float(order_price) / count, 2)
        if total is None and order_total is not None:
            total = round(float(order_total) / count, 2)
        execute_db("""
            INSERT INTO order_line_items (
                order_id, woocommerce_product_id, woocommerce_variation_id, sku,
                product_name, category_name, category_id, quantity, unit_price, line_total, sort_order
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            order_id,
            str(item.get('woocommerce_product_id') or '') or None,
            str(item.get('woocommerce_variation_id') or '') or None,
            item.get('sku') or None,
            item['product_name'],
            item.get('category_name') or None,
            str(item.get('category_id') or '') or None,
            qty,
            float(unit or 0),
            float(total or 0),
            item.get('sort_order') or 0,
        ))


def match_company_for_client(client_id, company_name):
    if not company_name or not str(company_name).strip():
        return None
    rec = query_db(
        "SELECT id FROM companies WHERE user_id = ? AND LOWER(name) = LOWER(?);",
        (client_id, str(company_name).strip()),
        one=True
    )
    return rec['id'] if rec else None


def match_service_id(product_name):
    if not product_name:
        return None
    rec = query_db("SELECT id FROM services WHERE LOWER(name) = LOWER(?) LIMIT 1;", (product_name.strip(),), one=True)
    return rec['id'] if rec else None


def shift_calendar_month(year, month, delta):
    total = year * 12 + (month - 1) + delta
    return total // 12, (total % 12) + 1


def build_monthly_revenue_chart(months=6):
    today = datetime.date.today()
    rows = query_db("""
        SELECT strftime('%Y-%m', created_at) AS month,
               COUNT(*) AS cnt,
               COALESCE(SUM(CASE WHEN status NOT IN ('Cancelled', 'Refunded') THEN total ELSE 0 END), 0) AS rev
        FROM orders
        GROUP BY strftime('%Y-%m', created_at);
    """)
    by_month = {}
    for row in rows or []:
        key = row.get('month')
        if not key:
            continue
        by_month[str(key)] = {
            'cnt': int(row.get('cnt') or 0),
            'rev': float(row.get('rev') or 0),
        }
    series = []
    for offset in range(months - 1, -1, -1):
        year, month = shift_calendar_month(today.year, today.month, -offset)
        key = f'{year:04d}-{month:02d}'
        item = by_month.get(key, {'cnt': 0, 'rev': 0.0})
        series.append({
            'month': key,
            'label': datetime.date(year, month, 1).strftime('%b %Y'),
            'cnt': item['cnt'],
            'rev': round(float(item['rev']), 2),
        })
    return series


def ensure_order_timeline(order_id):
    existing = query_db("SELECT id FROM order_timeline WHERE order_id = ? LIMIT 1;", (order_id,), one=True)
    if existing:
        return
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    steps = [
        ('Order Placed', 'Completed', now),
        ('Payment Confirmed', 'Completed', now),
        ('Processing', 'Current', now),
        ('Documents Received', 'Pending', None),
        ('Service Completed', 'Pending', None),
    ]
    for title, step_status, step_date in steps:
        execute_db(
            "INSERT INTO order_timeline (order_id, title, status, step_date) VALUES (?, ?, ?, ?);",
            (order_id, title, step_status, step_date)
        )


def append_order_history(order_id, title):
    if not order_id or not title:
        return
    execute_db(
        "INSERT INTO order_timeline (order_id, title, status, step_date) VALUES (?, ?, 'Completed', CURRENT_TIMESTAMP);",
        (order_id, title)
    )


def _qs_first(qs, key, default=''):
    return (qs.get(key, [default])[0] or default).strip()


def resolve_admin_order_dates(qs):
    today = datetime.date.today()
    preset = _qs_first(qs, 'date_preset')
    date_from = _qs_first(qs, 'date_from')
    date_to = _qs_first(qs, 'date_to')
    month = _qs_first(qs, 'month')
    year = _qs_first(qs, 'year')
    if preset == 'today':
        return str(today), str(today)
    if preset == 'yesterday':
        day = today - datetime.timedelta(days=1)
        return str(day), str(day)
    if preset == 'this_week':
        start = today - datetime.timedelta(days=today.weekday())
        return str(start), str(today)
    if preset == 'this_month':
        return f"{today.year:04d}-{today.month:02d}-01", str(today)
    if preset == 'last_month':
        first_this = today.replace(day=1)
        last_end = first_this - datetime.timedelta(days=1)
        return f"{last_end.year:04d}-{last_end.month:02d}-01", str(last_end)
    if preset == 'this_year':
        return f"{today.year:04d}-01-01", str(today)
    if month:
        try:
            m = int(month)
            y = int(year) if year else today.year
            if m < 1 or m > 12 or y < 2000 or y > 2100:
                return None, None
            last = calendar.monthrange(y, m)[1]
            return f"{y:04d}-{m:02d}-01", f"{y:04d}-{m:02d}-{last:02d}"
        except ValueError:
            return None, None
    if year and not date_from and not date_to:
        try:
            y = int(year)
            return f"{y:04d}-01-01", f"{y:04d}-12-31"
        except ValueError:
            return None, None
    return (date_from or None), (date_to or None)


def manager_order_scope(user):
    if user and user.get('role') == 'MANAGER':
        return (
            "(o.assigned_staff_id = ? OR o.assigned_staff_id IS NULL OR o.assigned_staff_id IN (SELECT id FROM users WHERE role = 'STAFF'))",
            [user['id']]
        )
    return '', []


def build_admin_order_filters(user, qs):
    clauses = []
    params = []
    scope_sql, scope_params = manager_order_scope(user)
    if scope_sql:
        clauses.append(scope_sql)
        params.extend(scope_params)

    search = _qs_first(qs, 'search')
    if search:
        term = f"%{search}%"
        clauses.append("""(
            o.order_number LIKE ? OR o.service_name LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?
            OR c.name LIKE ?
            OR EXISTS (SELECT 1 FROM order_line_items li WHERE li.order_id = o.id AND (li.product_name LIKE ? OR li.category_name LIKE ?))
        )""")
        params.extend([term, term, term, term, term, term, term])

    order_number = _qs_first(qs, 'order_number')
    if order_number:
        clauses.append("o.order_number LIKE ?")
        params.append(f"%{order_number}%")

    customer_id = _qs_first(qs, 'customer_id')
    if customer_id:
        cid, err = to_optional_int(customer_id, 'customer_id')
        if not err and cid:
            clauses.append("o.user_id = ?")
            params.append(cid)

    status_filter = _qs_first(qs, 'status')
    status_group = _qs_first(qs, 'status_group')
    if status_filter:
        clauses.append("o.status = ?")
        params.append(status_filter)
    elif status_group == 'pending':
        clauses.append("o.status IN ('Pending', 'Pending Verification')")
    elif status_group == 'in_progress':
        clauses.append("o.status IN ('Processing', 'In Progress')")
    elif status_group == 'completed':
        clauses.append("o.status = 'Completed'")

    product = _qs_first(qs, 'product')
    if product:
        clauses.append("(o.service_name = ? OR EXISTS (SELECT 1 FROM order_line_items li WHERE li.order_id = o.id AND li.product_name = ?))")
        params.extend([product, product])

    category = _qs_first(qs, 'category')
    if category:
        clauses.append("""(
            EXISTS (SELECT 1 FROM order_line_items li WHERE li.order_id = o.id AND li.category_name = ?)
            OR EXISTS (SELECT 1 FROM services sv WHERE sv.id = o.service_id AND sv.category = ?)
        )""")
        params.extend([category, category])

    payment_status = _qs_first(qs, 'payment_status')
    if payment_status == 'Unpaid':
        clauses.append("NOT EXISTS (SELECT 1 FROM invoices inv WHERE inv.order_id = o.id AND inv.status = 'Paid')")
    elif payment_status:
        clauses.append("EXISTS (SELECT 1 FROM invoices inv WHERE inv.order_id = o.id AND inv.status = ?)")
        params.append(payment_status)

    progress_min = _qs_first(qs, 'progress_min')
    progress_max = _qs_first(qs, 'progress_max')
    if progress_min:
        try:
            clauses.append("o.progress_percent >= ?")
            params.append(int(progress_min))
        except ValueError:
            pass
    if progress_max:
        try:
            clauses.append("o.progress_percent <= ?")
            params.append(int(progress_max))
        except ValueError:
            pass

    date_from, date_to = resolve_admin_order_dates(qs)
    date_clauses = []
    date_params = []
    if date_from:
        date_clauses.append("date(o.created_at) >= date(?)")
        date_params.append(date_from)
    if date_to:
        date_clauses.append("date(o.created_at) <= date(?)")
        date_params.append(date_to)

    return clauses, params, date_clauses, date_params


def notify_staff_new_order(order_number, client_name):
    staff = query_db("SELECT id FROM users WHERE role IN ('SUPER_ADMIN', 'ADMIN') AND status = 'Active';")
    for row in staff:
        execute_db("""
            INSERT INTO notifications (user_id, title, message, type, link)
            VALUES (?, ?, ?, ?, ?);
        """, (
            row['id'],
            'New website order',
            f"Order {order_number} from {client_name} is in the CRM.",
            'order_update',
            '#admin-orders'
        ))


def upsert_woocommerce_order(o_data):
    order_num = o_data.get('order_number') or f"#GB{int(datetime.datetime.now().timestamp())}"
    wp_user_id = str(o_data.get('wordpress_user_id') or '')
    email = (o_data.get('email') or '').strip()
    line_items = parse_line_items_from_payload(o_data)
    service_name = (o_data.get('service_name') or '').strip()
    if not service_name and line_items:
        service_name = ', '.join(item['product_name'] for item in line_items)
    if not service_name:
        service_name = 'Corporate Formation Service'
    price = float(o_data.get('price', 150.00))
    total = float(o_data.get('total', price * 1.2))
    vat = total - price
    status = o_data.get('status') or 'Processing'
    if status not in ('Pending', 'Processing', 'In Progress', 'Completed', 'Cancelled', 'Refunded', 'Pending Verification'):
        status = 'Processing'
    wc_order_id = str(o_data.get('woocommerce_order_id') or '') or None
    company_name = o_data.get('company_name') or o_data.get('billing_company')

    client_rec = None
    if wp_user_id:
        client_rec = query_db("SELECT id, full_name FROM users WHERE wordpress_user_id = ?;", (wp_user_id,), one=True)
    if not client_rec and email:
        client_rec = query_db("SELECT id, full_name FROM users WHERE email = ?;", (email,), one=True)

    guest_pending = False
    if client_rec:
        cid = client_rec['id']
        client_name = client_rec.get('full_name') or email or 'Client'
        order_notes = o_data.get('notes', '')
    else:
        guest_user = query_db("SELECT id FROM users WHERE email = 'guest.unlinked@brixenconsultants.com';", one=True)
        if not guest_user:
            cid = execute_db("""
                INSERT INTO users (wordpress_user_id, email, password_hash, full_name, role, status, last_synced_at)
                VALUES ('guest_unlinked', 'guest.unlinked@brixenconsultants.com', ?, 'Unlinked Guest Customer', 'CLIENT', 'Active', CURRENT_TIMESTAMP);
            """, (unusable_password_hash(),))
        else:
            cid = guest_user['id']
        client_name = email or 'Guest'
        order_notes = f"Guest Order (Email: {email}) - Pending Staff Verification"
        status = 'Pending Verification'
        guest_pending = True

    company_id = match_company_for_client(cid, company_name) if not guest_pending else None
    service_id = match_service_id(line_items[0]['product_name'] if line_items else service_name)

    existing_ord = query_db("SELECT id FROM orders WHERE order_number = ?;", (order_num,), one=True)
    created = False
    if existing_ord:
        execute_db("""
            UPDATE orders SET status = ?, total = ?, price = ?, vat = ?, service_name = ?,
                company_id = COALESCE(?, company_id), service_id = COALESCE(?, service_id),
                woocommerce_order_id = COALESCE(?, woocommerce_order_id),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?;
        """, (status, total, price, vat, service_name, company_id, service_id, wc_order_id, existing_ord['id']))
        ord_id = existing_ord['id']
    else:
        ord_id = execute_db("""
            INSERT INTO orders (
                order_number, user_id, company_id, service_id, service_name,
                price, vat, total, status, progress_percent, notes, woocommerce_order_id, payment_mode
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 20, ?, ?, ?);
        """, (order_num, cid, company_id, service_id, service_name, price, vat, total, status, order_notes, wc_order_id, 'Website Charge'))
        created = True
        log_activity(None, 'ORDER_SYNCED', 'orders', str(ord_id), f"Website order {order_num}")
        ensure_order_timeline(ord_id)
        if not guest_pending:
            notify_staff_new_order(order_num, client_name)

    if line_items:
        replace_order_line_items(ord_id, line_items, price, total)
    return {'order_id': ord_id, 'order_number': order_num, 'created': created, 'guest': guest_pending}


ensure_schema()

def application(environ, start_response):
    path = environ.get('PATH_INFO', '')
    method = environ.get('REQUEST_METHOD', 'GET')
    allowed_origin = cors_allowed_origin(environ)
    orig_start_response = start_response

    def secured_start_response(status, headers, exc_info=None):
        filtered = [(k, v) for k, v in headers if k.lower() != 'access-control-allow-origin']
        if allowed_origin:
            filtered.append(('Access-Control-Allow-Origin', allowed_origin))
            filtered.append(('Access-Control-Allow-Credentials', 'true'))
        filtered.append(('Vary', 'Origin'))
        if exc_info is not None:
            return orig_start_response(status, filtered, exc_info)
        return orig_start_response(status, filtered)

    start_response = secured_start_response

    # Handle CORS preflight
    if method == 'OPTIONS':
        start_response("200 OK", [
            ('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS'),
            ('Access-Control-Allow-Headers', 'Content-Type, Authorization, Cookie, X-Brixen-Signature, X-WP-Signature')
        ])
        return [b""]
    
    user = get_current_user(environ)
    
    # ----------------------------------------------------
    # Static files & Homepage
    # ----------------------------------------------------
    if path == '/' or path == '/index.html':
        return serve_static(environ, start_response, os.path.join(TEMPLATES_DIR, 'index.html'), allowed_root=TEMPLATES_DIR)
    elif path.startswith('/static/'):
        rel_path = urllib.parse.unquote(path[len('/static/'):]).replace('\\', '/')
        if not rel_path or '\x00' in rel_path:
            start_response("404 Not Found", [('Content-Type', 'text/plain; charset=utf-8')])
            return [b"Not Found"]
        candidate = os.path.join(STATIC_DIR, rel_path)
        return serve_static(environ, start_response, candidate, allowed_root=STATIC_DIR)

    # ----------------------------------------------------
    # WORDPRESS INTEGRATION & WEBHOOK APIs
    # ----------------------------------------------------
    if path == '/api/v1/wordpress/webhook' and method == 'POST':
        sig = environ.get('HTTP_X_BRIXEN_SIGNATURE', '') or environ.get('HTTP_X_WP_SIGNATURE', '')
        try:
            content_length = int(environ.get('CONTENT_LENGTH', 0))
        except (ValueError, TypeError):
            content_length = 0
        raw_bytes = environ['wsgi.input'].read(content_length) if content_length > 0 else b""
        
        # Mandatory HMAC Signature Verification
        if not sig or not verify_webhook_signature(raw_bytes, sig):
            return json_response(start_response, {'status': 'error', 'message': 'Missing or invalid HMAC signature'}, "401 Unauthorized")
            
        try:
            payload = json.loads(raw_bytes.decode('utf-8'))
        except Exception as e:
            return json_response(start_response, {'status': 'error', 'message': 'Invalid JSON payload'}, "400 Bad Request")
            
        event_id = payload.get('event_id') or payload.get('id') or f"evt_{int(datetime.datetime.now().timestamp())}"
        event_type = payload.get('event_type') or payload.get('event') or 'user.created'
        
        # 1. Idempotency Check: Prevent duplicate event processing
        existing_evt = query_db("SELECT id FROM webhook_events WHERE event_id = ?;", (event_id,), one=True)
        if existing_evt:
            return json_response(start_response, {
                'status': 'ignored',
                'message': 'Duplicate event ignored',
                'event_id': event_id
            })
            
        # Log webhook event
        execute_db("""
            INSERT INTO webhook_events (event_id, event_type, payload, status)
            VALUES (?, ?, ?, 'Processed');
        """, (event_id, event_type, json.dumps(payload)))
        
        # 2. Process Registration / Update Events
        if event_type in ('user.created', 'user.updated'):
            u_data = payload.get('data', payload)
            wp_user_id = str(u_data.get('wordpress_user_id') or u_data.get('user_id') or u_data.get('id', ''))
            email = u_data.get('email', '').strip()
            first_name = u_data.get('first_name', '')
            last_name = u_data.get('last_name', '')
            full_name = u_data.get('full_name') or f"{first_name} {last_name}".strip() or email.split('@')[0]
            phone = u_data.get('phone', '')
            country = u_data.get('country', 'United Kingdom')
            
            if not email:
                return json_response(start_response, {'status': 'error', 'message': 'Email required'}, "400 Bad Request")
                
            # Match existing user by wordpress_user_id or email
            existing_user = query_db("SELECT id FROM users WHERE wordpress_user_id = ? OR email = ?;", (wp_user_id, email), one=True)
            if existing_user:
                execute_db("""
                    UPDATE users 
                    SET wordpress_user_id = ?, full_name = ?, phone = ?, country = ?, last_synced_at = CURRENT_TIMESTAMP
                    WHERE id = ?;
                """, (wp_user_id, full_name, phone, country, existing_user['id']))
                action_msg = "Updated existing client from WordPress webhook"
                client_id = existing_user['id']
            else:
                pwd_hash = unusable_password_hash()
                client_id = execute_db("""
                    INSERT INTO users (wordpress_user_id, email, password_hash, full_name, phone, country, role, status, last_synced_at)
                    VALUES (?, ?, ?, ?, ?, ?, 'CLIENT', 'Active', CURRENT_TIMESTAMP);
                """, (wp_user_id, email, pwd_hash, full_name, phone, country))
                action_msg = "Created new client from WordPress webhook"
                
                # Auto-create notification for new client
                execute_db("""
                    INSERT INTO notifications (user_id, title, message, type)
                    VALUES (?, 'Welcome to Brixen Consultants', 'Your client portal has been connected to your website account.', 'system');
                """, (client_id,))
                
            log_activity(None, action_msg, 'users', client_id, f"WP User ID: {wp_user_id}, Email: {email}")
            return json_response(start_response, {
                'status': 'success',
                'message': action_msg,
                'client_id': client_id,
                'wordpress_user_id': wp_user_id
            })
            
        elif event_type in ('order.created', 'order.updated'):
            o_data = payload.get('data', payload)
            result = upsert_woocommerce_order(o_data)
            return json_response(start_response, {
                'status': 'success',
                'order_id': result['order_id'],
                'order_number': result['order_number']
            })

        elif event_type == 'payment.completed':
            o_data = payload.get('data', payload)
            order_num = o_data.get('order_number')
            if order_num:
                existing_ord = query_db("SELECT id, user_id FROM orders WHERE order_number = ?;", (order_num,), one=True)
                if existing_ord:
                    execute_db("""
                        UPDATE orders SET status = CASE WHEN status = 'Pending Verification' THEN status ELSE 'Processing' END,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?;
                    """, (existing_ord['id'],))
                    execute_db("UPDATE invoices SET status = 'Paid', paid_at = CURRENT_TIMESTAMP WHERE order_id = ?;", (existing_ord['id'],))
            return json_response(start_response, {'status': 'success', 'message': 'Payment recorded'})
            
        return json_response(start_response, {'status': 'success', 'message': f'Event {event_type} received'})

    if path == '/api/v1/wordpress/sync-users' and method == 'POST':
        sig = environ.get('HTTP_X_BRIXEN_SIGNATURE', '') or environ.get('HTTP_X_WP_SIGNATURE', '')
        try:
            content_length = int(environ.get('CONTENT_LENGTH', 0))
        except (ValueError, TypeError):
            content_length = 0
        raw_bytes = environ['wsgi.input'].read(content_length) if content_length > 0 else b""

        has_valid_sig = sig and verify_webhook_signature(raw_bytes, sig)
        has_admin_perm = user and check_permission(user, 'settings.manage')
        if not (has_valid_sig or has_admin_perm):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions or invalid signature'}, "403 Forbidden")
            
        data = parse_body(environ) if not raw_bytes else json.loads(raw_bytes.decode('utf-8'))
        user_list = data.get('users', [])
        synced_cnt = 0
        updated_cnt = 0
        
        for u in user_list:
            wp_id = str(u.get('wordpress_user_id') or u.get('id', ''))
            email = u.get('email', '').strip()
            name = u.get('full_name') or u.get('display_name') or email.split('@')[0]
            phone = u.get('phone', '')
            if not email: continue
            
            existing = query_db("SELECT id FROM users WHERE wordpress_user_id = ? OR email = ?;", (wp_id, email), one=True)
            if existing:
                execute_db("UPDATE users SET wordpress_user_id = ?, full_name = ?, last_synced_at = CURRENT_TIMESTAMP WHERE id = ?;", (wp_id, name, existing['id']))
                updated_cnt += 1
            else:
                execute_db("""
                    INSERT INTO users (wordpress_user_id, email, password_hash, full_name, phone, role, status, last_synced_at)
                    VALUES (?, ?, ?, ?, ?, 'CLIENT', 'Active', CURRENT_TIMESTAMP);
                """, (wp_id, email, unusable_password_hash(), name, phone))
                synced_cnt += 1
                
        return json_response(start_response, {
            'status': 'success',
            'summary': {
                'created': synced_cnt,
                'updated': updated_cnt,
                'total_processed': len(user_list)
            }
        })

    if path == '/api/v1/wordpress/sync-orders' and method == 'POST':
        sig = environ.get('HTTP_X_BRIXEN_SIGNATURE', '') or environ.get('HTTP_X_WP_SIGNATURE', '')
        try:
            content_length = int(environ.get('CONTENT_LENGTH', 0))
        except (ValueError, TypeError):
            content_length = 0
        raw_bytes = environ['wsgi.input'].read(content_length) if content_length > 0 else b""

        has_valid_sig = sig and verify_webhook_signature(raw_bytes, sig)
        has_admin_perm = user and check_permission(user, 'settings.manage')
        if not (has_valid_sig or has_admin_perm):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions or invalid signature'}, "403 Forbidden")
            
        data = parse_body(environ) if not raw_bytes else json.loads(raw_bytes.decode('utf-8'))
        order_list = data.get('orders', [])
        synced_cnt = 0
        updated_cnt = 0
        
        for o in order_list:
            result = upsert_woocommerce_order(o)
            if result['created']:
                synced_cnt += 1
            else:
                updated_cnt += 1
                
        return json_response(start_response, {
            'status': 'success',
            'summary': {
                'created': synced_cnt,
                'updated': updated_cnt,
                'total_processed': len(order_list)
            }
        })

    if path == '/api/v1/auth/sso' and method in ('GET', 'POST'):
        if method == 'GET':
            query_str = environ.get('QUERY_STRING', '')
            from urllib.parse import parse_qs
            params = parse_qs(query_str)
            wp_id = params.get('wordpress_user_id', [''])[0]
            email = params.get('email', [''])[0]
            timestamp = params.get('timestamp', [''])[0]
            sig = params.get('signature', [''])[0]
        else:
            data = parse_body(environ)
            wp_id = str(data.get('wordpress_user_id') or '')
            email = str(data.get('email') or '')
            timestamp = str(data.get('timestamp') or '')
            sig = str(data.get('signature') or '')

        wp_id = wp_id.strip()
        email = email.strip()
        timestamp = timestamp.strip()
        sig = sig.strip()

        if not wp_id:
            return json_response(start_response, {'status': 'error', 'message': 'Missing wordpress_user_id'}, "401 Unauthorized")
        if not timestamp or timestamp == '0':
            return json_response(start_response, {'status': 'error', 'message': 'Missing timestamp'}, "401 Unauthorized")
        if not sig:
            return json_response(start_response, {'status': 'error', 'message': 'Missing signature'}, "401 Unauthorized")

        row = query_db("SELECT value FROM settings WHERE key = 'wordpress_webhook_secret';", one=True)
        secret = (row['value'] if row and row['value'] else None) or os.environ.get('WORDPRESS_WEBHOOK_SECRET')
        if not secret:
            return json_response(start_response, {'status': 'error', 'message': 'SSO feature unconfigured'}, "500 Internal Server Error")

        try:
            ts_int = int(timestamp)
        except (TypeError, ValueError):
            return json_response(start_response, {'status': 'error', 'message': 'Invalid timestamp'}, "401 Unauthorized")
        if abs(int(datetime.datetime.now().timestamp()) - ts_int) > 300:
            return json_response(start_response, {'status': 'error', 'message': 'SSO token expired'}, "401 Unauthorized")

        expected_payload = f"{wp_id}|{email}|{timestamp}".encode('utf-8')
        expected_sig = hmac.new(secret.encode('utf-8'), expected_payload, hashlib.sha256).hexdigest()
        provided_sig = sig.replace('sha256=', '').strip()
        try:
            sig_ok = hmac.compare_digest(provided_sig, expected_sig)
        except (TypeError, ValueError):
            sig_ok = False
        if not sig_ok:
            return json_response(start_response, {'status': 'error', 'message': 'Invalid SSO signature'}, "401 Unauthorized")

        client_rec = query_db("SELECT id, email, full_name, role FROM users WHERE wordpress_user_id = ? OR email = ?;", (wp_id, email), one=True)
        if not client_rec:
            return json_response(start_response, {'status': 'error', 'message': 'Client record not found for SSO'}, "404 Not Found")
            
        token = create_db_session(client_rec['id'])
        log_activity(client_rec, 'Client logged in via WordPress SSO', 'users', client_rec['id'])

        if method == 'GET':
            start_response("302 Found", [
                ('Location', '/'),
                ('Set-Cookie', session_cookie_header(token, environ=environ))
            ])
            return [b""]
        else:
            return json_response(start_response, {
                'status': 'success',
                'user': dict(client_rec)
            }, extra_headers=[('Set-Cookie', session_cookie_header(token, environ=environ))])

    # ----------------------------------------------------
    # P3: ADMIN WEBHOOK MONITORING & RETRY API
    # ----------------------------------------------------
    if path == '/api/admin/webhooks' and method == 'GET':
        if not user or not check_permission(user, 'settings.manage'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
            
        qs = urllib.parse.parse_qs(environ.get('QUERY_STRING', ''))
        status_filter = qs.get('status', [''])[0].strip()
        
        sql = "SELECT * FROM webhook_events"
        params = []
        if status_filter:
            sql += " WHERE status = ?"
            params.append(status_filter)
        sql += " ORDER BY created_at DESC LIMIT 100;"
        
        events = query_db(sql, params)
        return json_response(start_response, {'status': 'success', 'events': events})

    if path.startswith('/api/admin/webhooks/') and path.endswith('/retry') and method == 'POST':
        if not user or not check_permission(user, 'settings.manage'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
            
        evt_id = path.split('/')[4]
        evt = query_db("SELECT * FROM webhook_events WHERE id = ?;", (evt_id,), one=True)
        if not evt:
            return json_response(start_response, {'status': 'error', 'message': 'Webhook event not found'}, "404 Not Found")
            
        try:
            payload = json.loads(evt['payload'])
            event_type = evt['event_type']
            
            # Update retry attempt
            execute_db("""
                UPDATE webhook_events 
                SET retry_count = retry_count + 1, last_attempt = datetime('now'), status = 'Processed'
                WHERE id = ?;
            """, (evt_id,))
            
            log_activity(user, 'WEBHOOK_RETRY', 'webhook_events', str(evt_id), f"Retried webhook event {evt['event_id']}")
            return json_response(start_response, {'status': 'success', 'message': f'Successfully re-processed webhook event #{evt_id}'})
        except Exception as err:
            execute_db("UPDATE webhook_events SET status = 'Failed', error_message = ? WHERE id = ?;", (str(err), evt_id))
            return json_response(start_response, {'status': 'error', 'message': f'Retry failed: {err}'}, "500 Internal Error")

    # ----------------------------------------------------
    # ADMIN / STAFF: CENTRALIZED CLIENT CRM RECORD API
    # ----------------------------------------------------
    if path.startswith('/api/admin/clients/') and path.endswith('/full') and method == 'GET':
        if not user or not check_permission(user, 'clients.view'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
            
        cid = path.split('/')[4]
        target_user = query_db("SELECT id, wordpress_user_id, email, full_name, phone, country, address, avatar_url, role, status, last_synced_at, created_at FROM users WHERE id = ?;", (cid,), one=True)
        if not target_user:
            return json_response(start_response, {'status': 'error', 'message': 'Client not found'}, "404 Not Found")
            
        companies = query_db("SELECT * FROM companies WHERE user_id = ? ORDER BY id DESC;", (cid,))
        orders = query_db("SELECT o.*, c.name as company_name FROM orders o LEFT JOIN companies c ON o.company_id = c.id WHERE o.user_id = ? ORDER BY o.created_at DESC;", (cid,))
        invoices = query_db("SELECT * FROM invoices WHERE user_id = ? ORDER BY created_at DESC;", (cid,))
        documents = query_db("""
            SELECT d.*, c.name as company_name, o.order_number
            FROM documents d
            LEFT JOIN companies c ON d.company_id = c.id
            LEFT JOIN orders o ON d.order_id = o.id
            WHERE d.user_id = ?
            ORDER BY d.created_at DESC;
        """, (cid,))
        tickets = query_db("SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC;", (cid,))
        notifications = query_db("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC;", (cid,))
        logs = query_db("SELECT * FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 50;", (cid,))
        
        return json_response(start_response, {
            'status': 'success',
            'client': dict(target_user),
            'companies': companies,
            'orders': orders,
            'invoices': invoices,
            'documents': [public_document(d) for d in documents],
            'support_tickets': tickets,
            'notifications': notifications,
            'activity_logs': logs
        })

    # ----------------------------------------------------
    # PRIVATE SECURE DOCUMENT STREAMING API
    # ----------------------------------------------------
    if path.startswith('/api/documents/') and path.endswith('/download') and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
            
        parts = path.split('/')
        doc_id = parts[3]
        doc = query_db("SELECT * FROM documents WHERE id = ?;", (doc_id,), one=True)
        if not doc:
            return json_response(start_response, {'status': 'error', 'message': 'Document not found'}, "404 Not Found")
            
        # Security: CLIENT may only download their own shared files; staff need documents.view
        if user['role'] == 'CLIENT':
            if doc['user_id'] != user['id'] or not int(doc.get('client_visible') or 0):
                return json_response(start_response, {'status': 'error', 'message': 'Access denied to target document'}, "403 Forbidden")
        elif not check_permission(user, 'documents.view'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
            
        file_path = doc['file_path']
        if os.path.exists(file_path):
            with open(file_path, 'rb') as f:
                content = f.read()
            mime_type = 'application/pdf' if file_path.lower().endswith('.pdf') else 'application/octet-stream'
            safe_name = os.path.basename(doc['name'])
            start_response("200 OK", [
                ('Content-Type', mime_type),
                ('Content-Length', str(len(content))),
                ('Content-Disposition', f'attachment; filename="{safe_name}"')
            ])
            return [content]
        return json_response(start_response, {'status': 'error', 'message': 'Document file not found'}, "404 Not Found")

    # ----------------------------------------------------
    # API: System Settings
    # ----------------------------------------------------
    if path == '/api/settings' and method == 'GET':
        public_keys = {
            'company_name', 'logo_url', 'primary_color', 'support_email',
            'support_phone', 'currency', 'vat_rate', 'order_prefix', 'invoice_prefix',
            'portal_url'
        }
        blocked_fragments = (
            'secret', 'password', 'passwd', 'token', 'hash', 'credential',
            'private_key', 'api_key', 'session'
        )
        rows = query_db("SELECT key, value FROM settings;")
        settings_dict = {}
        for r in rows:
            key = r['key']
            key_l = (key or '').lower()
            if key not in public_keys:
                continue
            if any(frag in key_l for frag in blocked_fragments):
                continue
            settings_dict[key] = r['value']
        return json_response(start_response, {'status': 'success', 'settings': settings_dict})

    # ----------------------------------------------------
    # API: Auth
    # ----------------------------------------------------
    if path == '/api/auth/login' and method == 'POST':
        data = parse_body(environ)
        email = data.get('email', '').strip().lower()
        password = data.get('password', '')

        found_user = query_db("SELECT * FROM users WHERE LOWER(email) = ?;", (email,), one=True)
        stored_hash = found_user['password_hash'] if found_user else None
        if not verify_password(password, stored_hash):
            return json_response(start_response, {'status': 'error', 'message': 'Invalid email or password.'}, "401 Unauthorized")
        if needs_rehash(stored_hash):
            execute_db(
                "UPDATE users SET password_hash = ? WHERE id = ?;",
                (hash_password(password), found_user['id'])
            )
        
        if found_user['status'] != 'Active':
            return json_response(start_response, {'status': 'error', 'message': 'Your account is suspended. Please contact support.'}, "403 Forbidden")
            
        token = create_db_session(found_user['id'])
        log_activity(found_user, 'USER_LOGIN', 'users', str(found_user['id']), 'User logged in successfully.')
        
        u_dict = public_me_user(found_user, impersonated=False)
        cookie_header = ('Set-Cookie', session_cookie_header(token, environ=environ))
        origin_clear = ('Set-Cookie', origin_cookie_header(clear=True, environ=environ))
        return json_response(start_response, {'status': 'success', 'user': u_dict}, extra_headers=[origin_clear, cookie_header])

    if path == '/api/auth/me' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        origin_token = cookie_value(environ, 'origin_session')
        origin_rec = session_user_from_token(origin_token)
        impersonated = bool(origin_rec and origin_rec.get('id') != user.get('id'))
        u_dict = public_me_user(user, impersonated=impersonated)
        return json_response(start_response, {'status': 'success', 'user': u_dict})

    if path == '/api/auth/logout' and method == 'POST':
        cookie_str = environ.get('HTTP_COOKIE', '')
        token = None
        if 'session_token=' in cookie_str:
            for c in cookie_str.split(';'):
                if c.strip().startswith('session_token='):
                    token = c.strip().split('=', 1)[1]
                    break
        if not token:
            auth_hdr = environ.get('HTTP_AUTHORIZATION', '')
            if auth_hdr.startswith('Bearer '):
                token = auth_hdr.split(' ', 1)[1]
                
        revoke_db_session(token)
        origin_token = cookie_value(environ, 'origin_session')
        if origin_token and origin_token != token:
            revoke_db_session(origin_token)
        cookie_header = ('Set-Cookie', session_cookie_header(clear=True, environ=environ))
        origin_clear = ('Set-Cookie', origin_cookie_header(clear=True, environ=environ))
        return json_response(start_response, {'status': 'success', 'message': 'Logged out'}, extra_headers=[origin_clear, cookie_header])

    if path == '/api/auth/profile' and method == 'POST':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        origin_token = cookie_value(environ, 'origin_session')
        origin_rec = session_user_from_token(origin_token)
        impersonating = bool(origin_rec and origin_rec.get('id') != user.get('id'))
        data = parse_body(environ)
        full_name = (data.get('full_name') if 'full_name' in data else user.get('full_name')) or user.get('full_name')
        phone = data.get('phone') if 'phone' in data else user.get('phone')
        country = data.get('country') if 'country' in data else user.get('country')
        address = data.get('address') if 'address' in data else user.get('address')
        new_password = data.get('new_password') or ''
        if not isinstance(new_password, str):
            new_password = ''
        new_password = new_password.strip()

        if new_password:
            if impersonating:
                return json_response(start_response, {
                    'status': 'error',
                    'message': 'Return to your own account to change the password.'
                }, "403 Forbidden")
            current_password = data.get('current_password') or ''
            stored = query_db("SELECT password_hash FROM users WHERE id = ?;", (user['id'],), one=True)
            if not stored or not verify_password(current_password, stored.get('password_hash')):
                return json_response(start_response, {
                    'status': 'error',
                    'message': 'Current password is incorrect.'
                }, "400 Bad Request")
            if len(new_password) < STAFF_MIN_PASSWORD_LEN:
                return json_response(start_response, {
                    'status': 'error',
                    'message': f'Password must be at least {STAFF_MIN_PASSWORD_LEN} characters'
                }, "400 Bad Request")
            if 'confirm_password' in data and (data.get('confirm_password') or '') != new_password:
                return json_response(start_response, {
                    'status': 'error',
                    'message': 'New passwords do not match.'
                }, "400 Bad Request")
            execute_db("UPDATE users SET password_hash = ? WHERE id = ?;", (hash_password(new_password), user['id']))

        execute_db("""
            UPDATE users SET full_name = ?, phone = ?, country = ?, address = ? WHERE id = ?;
        """, (full_name, phone, country, address, user['id']))
        updated = query_db("SELECT * FROM users WHERE id = ?;", (user['id'],), one=True)
        log_activity(user, 'PROFILE_UPDATE', 'users', str(user['id']), 'Updated profile settings.')
        return json_response(start_response, {
            'status': 'success',
            'message': 'Password updated.' if new_password else 'Profile updated successfully',
            'user': public_me_user(updated, impersonated=impersonating)
        })

    # ----------------------------------------------------
    # API: Client Stats & Orders
    # ----------------------------------------------------
    if path == '/api/client/stats' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        
        uid = user['id']
        comp_count = query_db("SELECT COUNT(*) as c FROM companies WHERE user_id = ?;", (uid,), one=True)['c']
        active_services = query_db("SELECT COUNT(*) as c FROM orders WHERE user_id = ? AND status IN ('Completed', 'Processing', 'In Progress');", (uid,), one=True)['c']
        pending_orders = query_db("SELECT COUNT(*) as c FROM orders WHERE user_id = ? AND status IN ('Pending', 'Processing', 'In Progress');", (uid,), one=True)['c']
        total_spent = query_db("SELECT COALESCE(SUM(total), 0) as s FROM orders WHERE user_id = ? AND status != 'Cancelled';", (uid,), one=True)['s']
        
        return json_response(start_response, {
            'status': 'success',
            'stats': {
                'companies_count': comp_count,
                'active_services': active_services,
                'pending_orders': pending_orders,
                'total_spent': f"£{total_spent:,.2f}"
            }
        })

    if path == '/api/client/dashboard' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        
        uid = user['id']
        comp_count = query_db("SELECT COUNT(*) as c FROM companies WHERE user_id = ?;", (uid,), one=True)['c']
        uk_comps = query_db("SELECT COUNT(*) as c FROM companies WHERE user_id = ? AND (reg_office LIKE '%London%' OR reg_office LIKE '%UK%' OR reg_office LIKE '%United Kingdom%');", (uid,), one=True)['c']
        intl_comps = query_db("SELECT COUNT(*) as c FROM companies WHERE user_id = ? AND (reg_office NOT LIKE '%London%' AND reg_office NOT LIKE '%UK%' AND reg_office NOT LIKE '%United Kingdom%');", (uid,), one=True)['c']
        companies = query_db("""
            SELECT id, name, company_number, status, account_status, reg_office, package
            FROM companies WHERE user_id = ? ORDER BY created_at DESC;
        """, (uid,))

        overdue_cnt = query_db("SELECT COUNT(*) as c FROM addresses WHERE user_id = ? AND expiry_date < date('now') AND status != 'Active';", (uid,), one=True)['c']
        upcoming_cnt = query_db("SELECT COUNT(*) as c FROM addresses WHERE user_id = ? AND expiry_date BETWEEN date('now') AND date('now', '+30 days');", (uid,), one=True)['c']

        active_orders = query_db("""
            SELECT o.*, c.name as company_name
            FROM orders o
            LEFT JOIN companies c ON o.company_id = c.id
            WHERE o.user_id = ?
              AND o.status NOT IN ('Completed', 'Cancelled', 'Refunded')
              AND o.service_name NOT LIKE '%Proxy%'
              AND o.service_name NOT LIKE '%Registered Agent%'
            ORDER BY o.created_at DESC;
        """, (uid,))

        enhanced_orders = []
        for ord_row in active_orders:
            o_dict = dict(ord_row)
            o_dict.pop('notes', None)
            o_dict.pop('woocommerce_order_id', None)
            progress = int(o_dict.get('progress_percent') or 0)
            line_rows = query_db(
                "SELECT * FROM order_line_items WHERE order_id = ? ORDER BY sort_order ASC, id ASC;",
                (o_dict['id'],)
            )
            timeline_rows = query_db(
                "SELECT title, status, step_date FROM order_timeline WHERE order_id = ? ORDER BY id ASC;",
                (o_dict['id'],)
            )
            stages = []
            for step in timeline_rows:
                step_status = (step.get('status') or 'Pending')
                if step_status == 'Completed':
                    visual = 'completed'
                elif step_status == 'Current':
                    visual = 'current'
                else:
                    visual = 'pending'
                stages.append({'name': step.get('title') or step_status, 'status': visual})
            if not stages:
                stages = [{'name': o_dict.get('status') or 'Pending', 'status': 'current'}]
            o_dict['stages'] = stages

            service_items = []
            for item in line_rows:
                item_status = 'Done' if progress >= 100 else (o_dict.get('status') or 'Pending')
                service_items.append({
                    'name': item.get('product_name'),
                    'category': item.get('category_name'),
                    'status': item_status,
                })
            if not service_items:
                service_items = [{
                    'name': o_dict.get('service_name'),
                    'category': None,
                    'status': 'Done' if progress >= 100 else (o_dict.get('status') or 'Pending'),
                }]
            o_dict['service_items'] = service_items
            o_dict['total_items_count'] = len(service_items)
            o_dict['done_items_count'] = sum(1 for item in service_items if item['status'] == 'Done')
            enhanced_orders.append(o_dict)

        display_name = (user.get('full_name') or '').strip() or user.get('email') or 'there'
        now_str = datetime.datetime.now().strftime("%d %B %Y")

        return json_response(start_response, {
            'status': 'success',
            'current_date': now_str,
            'user_name': display_name,
            'total_companies': comp_count,
            'uk_companies': uk_comps,
            'intl_companies': intl_comps,
            'overdue_deadlines': overdue_cnt,
            'upcoming_deadlines': upcoming_cnt,
            'active_orders_count': len(enhanced_orders),
            'active_orders': enhanced_orders,
            'companies': companies,
        })

    if path == '/api/client/orders' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
            
        qs = urllib.parse.parse_qs(environ.get('QUERY_STRING', ''))
        search = qs.get('search', [''])[0].strip()
        status_filter = qs.get('status', [''])[0].strip()
        sort_by = qs.get('sort', ['date_desc'])[0]
        page = int(qs.get('page', [1])[0])
        limit = int(qs.get('limit', [12])[0])
        
        uid = user['id']
        sql = """SELECT o.*, c.name as company_name,
            COALESCE((SELECT GROUP_CONCAT(li.product_name, ', ') FROM order_line_items li WHERE li.order_id = o.id), o.service_name) as products_summary,
            (SELECT li.category_name FROM order_line_items li WHERE li.order_id = o.id ORDER BY li.sort_order ASC, li.id ASC LIMIT 1) as category_name
            FROM orders o LEFT JOIN companies c ON o.company_id = c.id
            WHERE o.user_id = ? AND o.service_name NOT LIKE '%Proxy%' AND o.service_name NOT LIKE '%Registered Agent%'"""
        params = [uid]
        
        if search:
            sql += " AND (o.order_number LIKE ? OR o.service_name LIKE ? OR c.name LIKE ?)"
            s_term = f"%{search}%"
            params.extend([s_term, s_term, s_term])
            
        if status_filter:
            sql += " AND o.status = ?"
            params.append(status_filter)
            
        if sort_by == 'date_asc':
            sql += " ORDER BY o.created_at ASC"
        elif sort_by == 'price_desc':
            sql += " ORDER BY o.total DESC"
        elif sort_by == 'price_asc':
            sql += " ORDER BY o.total ASC"
        else:
            sql += " ORDER BY o.created_at DESC"
            
        all_rows = query_db(sql, params)
        total_records = len(all_rows)
        
        offset = (page - 1) * limit
        paged_rows = all_rows[offset:offset+limit]
        for row in paged_rows:
            row.pop('notes', None)
            row.pop('woocommerce_order_id', None)
        
        # Calculate Top 4 Stat Cards dynamically from client DB
        total_orders_cnt = query_db("SELECT COUNT(*) as c FROM orders WHERE user_id = ?;", (uid,), one=True)['c']
        completed_cnt = query_db("SELECT COUNT(*) as c FROM orders WHERE user_id = ? AND status = 'Completed';", (uid,), one=True)['c']
        in_progress_cnt = query_db("SELECT COUNT(*) as c FROM orders WHERE user_id = ? AND status IN ('Processing', 'In Progress');", (uid,), one=True)['c']
        total_spent_val = query_db("SELECT COALESCE(SUM(total), 0) as s FROM orders WHERE user_id = ? AND status != 'Cancelled';", (uid,), one=True)['s']
        
        return json_response(start_response, {
            'status': 'success',
            'orders': paged_rows,
            'pagination': {
                'page': page,
                'limit': limit,
                'total': total_records,
                'total_pages': (total_records + limit - 1) // limit if limit else 1
            },
            'stats': {
                'total_orders': total_orders_cnt,
                'completed': completed_cnt,
                'in_progress': in_progress_cnt,
                'total_spent': f"£{total_spent_val:,.2f}"
            }
        })

    if path.startswith('/api/client/orders/') and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        oid = path.split('/')[-1]
        order = query_db("""
            SELECT o.*, c.name as company_name, c.reg_office as company_address, c.company_number,
                   u.full_name as client_name, u.email as client_email, u.phone as client_phone,
                   u.address as client_address, u.country as client_country,
                   s.full_name as assigned_staff_name
            FROM orders o
            LEFT JOIN companies c ON o.company_id = c.id
            LEFT JOIN users u ON o.user_id = u.id
            LEFT JOIN users s ON o.assigned_staff_id = s.id
            WHERE o.id = ?;
        """, (oid,), one=True)
        
        if not order:
            return json_response(start_response, {'status': 'error', 'message': 'Order not found'}, "404 Not Found")
        if user['role'] == 'CLIENT':
            if order['user_id'] != user['id']:
                return json_response(start_response, {'status': 'error', 'message': 'Order not found'}, "404 Not Found")
        elif not check_permission(user, 'orders.view'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
            
        timeline = query_db("SELECT * FROM order_timeline WHERE order_id = ? ORDER BY id ASC;", (oid,))
        invoice = query_db("SELECT * FROM invoices WHERE order_id = ?;", (oid,), one=True)
        for_client = user['role'] == 'CLIENT'
        if for_client:
            documents = query_db("SELECT * FROM documents WHERE order_id = ? AND client_visible = 1;", (oid,))
        else:
            documents = query_db("SELECT * FROM documents WHERE order_id = ?;", (oid,))
        line_rows = query_db("SELECT * FROM order_line_items WHERE order_id = ? ORDER BY sort_order ASC, id ASC;", (oid,))
        tickets = query_db("""
            SELECT id, ticket_number, subject, status, created_at
            FROM support_tickets WHERE order_id = ? ORDER BY created_at DESC;
        """, (oid,)) if not for_client else query_db("""
            SELECT id, ticket_number, subject, status, created_at
            FROM support_tickets WHERE order_id = ? AND user_id = ? ORDER BY created_at DESC;
        """, (oid, user['id']))
        order_out = dict(order)
        if for_client:
            order_out.pop('notes', None)
            order_out.pop('woocommerce_order_id', None)
        addresses = []
        if not for_client:
            addresses = query_db("""
                SELECT type, line1, line2, city, postal_code, country, status
                FROM addresses WHERE user_id = ?
                ORDER BY created_at DESC;
            """, (order['user_id'],))

        invoice_out = None
        if invoice:
            invoice_out = {
                'invoice_number': invoice.get('invoice_number'),
                'status': invoice.get('status'),
                'amount': invoice.get('amount'),
                'tax': invoice.get('tax'),
                'total': invoice.get('total'),
                'due_date': invoice.get('due_date'),
                'paid_at': invoice.get('paid_at'),
                'payment_method': invoice.get('payment_method'),
            }

        return json_response(start_response, {
            'status': 'success',
            'order': order_out,
            'timeline': timeline,
            'invoice': invoice_out,
            'documents': [public_document(d, for_client=for_client) for d in documents],
            'line_items': [public_line_item(r, for_client=for_client) for r in line_rows],
            'tickets': tickets,
            'addresses': addresses
        })

    # ----------------------------------------------------
    # API: Companies, Addresses, Invoices, Documents, etc.
    # ----------------------------------------------------
    if path == '/api/admin/companies' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        if user['role'] == 'CLIENT':
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        comps = query_db("""
            SELECT id, name, company_number, status, inc_date, director, reg_office, package, account_status, created_at, user_id
            FROM companies ORDER BY created_at DESC;
        """)
        deadlines_map = upcoming_deadlines_by_company(None, [row['id'] for row in comps])
        uk_count = query_db("SELECT COUNT(*) as cnt FROM companies WHERE reg_office LIKE '%London%' OR reg_office LIKE '%UK%' OR reg_office LIKE '%United Kingdom%';", one=True)['cnt']
        return json_response(start_response, {
            'status': 'success',
            'companies': [public_client_company(row, deadlines_map.get(int(row['id']), [])) for row in comps],
            'total_uk': uk_count
        })

    if path == '/api/client/companies' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        comps = query_db(
            """
            SELECT id, name, company_number, status, inc_date, director, reg_office, package, account_status, created_at
            FROM companies WHERE user_id = ? ORDER BY created_at DESC;
            """,
            (user['id'],),
        )
        deadlines_map = upcoming_deadlines_by_company(user['id'], [row['id'] for row in comps])
        return json_response(start_response, {
            'status': 'success',
            'companies': [public_client_company(row, deadlines_map.get(int(row['id']), [])) for row in comps],
        })

    if path.startswith('/api/client/companies/') and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        parts = [p for p in path.split('/') if p]
        if len(parts) != 4:
            return json_response(start_response, {'status': 'error', 'message': 'Company not found'}, "404 Not Found")
        try:
            company_id = int(parts[3])
        except (TypeError, ValueError):
            return json_response(start_response, {'status': 'error', 'message': 'Company not found'}, "404 Not Found")
        company = query_db(
            """
            SELECT id, name, company_number, status, inc_date, director, reg_office, package, account_status, created_at
            FROM companies WHERE id = ? AND user_id = ?;
            """,
            (company_id, user['id']),
            one=True,
        )
        if not company:
            return json_response(start_response, {'status': 'error', 'message': 'Company not found'}, "404 Not Found")
        deadlines_map = upcoming_deadlines_by_company(user['id'], [company_id])
        office = query_db(
            """
            SELECT line1, line2, city, postal_code, country
            FROM addresses
            WHERE user_id = ? AND company_id = ? AND type = 'Registered Office'
            ORDER BY id DESC LIMIT 1;
            """,
            (user['id'], company_id),
            one=True,
        )
        registered_office = None
        if office:
            lines = [office.get('line1'), office.get('line2'), office.get('city')]
            registered_office = {
                'address': ', '.join([part for part in lines if part]),
                'postcode': office.get('postal_code') or '',
                'country': office.get('country') or company_country_label(company),
            }
        elif company.get('reg_office'):
            registered_office = {
                'address': company.get('reg_office'),
                'postcode': '',
                'country': company_country_label(company),
            }
        orders = query_db(
            """
            SELECT id, order_number, service_name, status, progress_percent, created_at, expected_date
            FROM orders WHERE user_id = ? AND company_id = ? ORDER BY created_at DESC;
            """,
            (user['id'], company_id),
        )
        documents = query_db(
            """
            SELECT d.*, c.name as company_name, o.order_number
            FROM documents d
            LEFT JOIN companies c ON d.company_id = c.id
            LEFT JOIN orders o ON d.order_id = o.id
            WHERE d.user_id = ? AND d.company_id = ? AND d.client_visible = 1
            ORDER BY d.created_at DESC;
            """,
            (user['id'], company_id),
        )
        tickets = query_db(
            """
            SELECT id, ticket_number, subject, category, priority, status, created_at
            FROM support_tickets WHERE user_id = ? AND company_id = ? ORDER BY created_at DESC;
            """,
            (user['id'], company_id),
        )
        return json_response(start_response, {
            'status': 'success',
            'company': public_client_company(company, deadlines_map.get(company_id, [])),
            'registered_office': registered_office,
            'orders': [public_client_order_summary(row) for row in orders],
            'documents': [public_document(row, for_client=True) for row in documents],
            'tickets': [public_client_ticket_summary(row) for row in tickets],
        })

    if path == '/api/client/addresses' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        addrs = query_db("""
            SELECT a.*, c.name as company_name 
            FROM addresses a 
            LEFT JOIN companies c ON a.company_id = c.id 
            WHERE a.user_id = ? ORDER BY a.created_at DESC;
        """, (user['id'],))
        return json_response(start_response, {'status': 'success', 'addresses': addrs})

    if path == '/api/client/invoices' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        invs = query_db("""
            SELECT i.*, o.order_number, o.service_name
            FROM invoices i
            JOIN orders o ON i.order_id = o.id
            WHERE i.user_id = ? ORDER BY i.created_at DESC;
        """, (user['id'],))
        return json_response(start_response, {'status': 'success', 'invoices': invs})

    if path == '/api/client/documents' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        docs = query_db("""
            SELECT d.*, c.name as company_name, o.order_number
            FROM documents d
            LEFT JOIN companies c ON d.company_id = c.id
            LEFT JOIN orders o ON d.order_id = o.id
            WHERE d.user_id = ? AND d.client_visible = 1
            ORDER BY d.created_at DESC;
        """, (user['id'],))
        return json_response(start_response, {'status': 'success', 'documents': [public_document(d, for_client=True) for d in docs]})

    if path == '/api/client/services' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        svcs = query_db("SELECT * FROM services WHERE status = 'Active' ORDER BY category ASC, price ASC;")
        return json_response(start_response, {'status': 'success', 'services': svcs})

    if path == '/api/client/payments' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        pymts = query_db("""
            SELECT i.*, o.order_number, o.service_name
            FROM invoices i
            JOIN orders o ON i.order_id = o.id
            WHERE i.user_id = ? ORDER BY i.created_at DESC;
        """, (user['id'],))
        return json_response(start_response, {'status': 'success', 'payments': pymts})

    if path == '/api/client/messages' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        msgs = query_db("""
            SELECT m.*, t.ticket_number, t.subject, t.status as ticket_status
            FROM support_messages m
            JOIN support_tickets t ON m.ticket_id = t.id
            WHERE t.user_id = ? ORDER BY m.created_at DESC;
        """, (user['id'],))
        return json_response(start_response, {'status': 'success', 'messages': msgs})

    if path == '/api/client/documents/upload' and method == 'POST':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        data = parse_body(environ)
        doc_name = data.get('name', 'Uploaded_Document.pdf')
        category = data.get('category', 'Company Documents')
        company_id = data.get('company_id')
        order_id = data.get('order_id')
        b64_content = data.get('file_content_base64', '')
        
        file_bytes, decode_err = decode_document_base64(
            b64_content,
            default_bytes=f"Sample Document Content for {doc_name}".encode('utf-8')
        )
        if decode_err:
            return json_response(start_response, {'status': 'error', 'message': decode_err}, "400 Bad Request")
        ext, upload_err = validate_uploaded_document(doc_name, file_bytes)
        if upload_err:
            return json_response(start_response, {'status': 'error', 'message': upload_err}, "400 Bad Request")
        target_path, store_err = store_client_document_file(user['id'], order_id, ext, file_bytes)
        if store_err:
            return json_response(start_response, {'status': 'error', 'message': store_err}, "400 Bad Request")
        file_size_str = format_document_size(len(file_bytes))
            
        doc_id = execute_db("""
            INSERT INTO documents (user_id, company_id, order_id, name, category, file_path, file_type, file_size, status, uploaded_by, review_notes, client_visible)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1);
        """, (user['id'], company_id, order_id, doc_name, category, target_path, 'PDF Document', file_size_str, 'Pending Review', user['full_name'], 'Awaiting compliance officer audit.'))
        
        log_activity(user, 'DOCUMENT_UPLOAD', 'documents', str(doc_id), f"Uploaded document {doc_name}")
        
        # P4: Portal notification & Email dispatch
        note_title = "Document Uploaded"
        note_msg = f"New document '{doc_name}' uploaded successfully and queued for review."
        execute_db("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'DOCUMENT');", (user['id'], note_title, note_msg))
        EmailService.send_notification_email(user['email'], 'Document Uploaded - Brixen Consultants Portal', f"Hello {user['full_name']},\n\nYour document '{doc_name}' has been uploaded to your secure Brixen Consultants portal.\n\nLog in to review: {portal_page_url()}")
        
        return json_response(start_response, {'status': 'success', 'message': 'Document uploaded successfully and queued for review.', 'document_id': doc_id})



    # ----------------------------------------------------
    # API: Support Tickets & Notifications
    # ----------------------------------------------------
    if path == '/api/client/tickets' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        if is_internal_staff(user):
            tickets = query_db("""
                SELECT t.*, u.full_name as client_name, u.email as client_email, c.name as company_name, o.order_number
                FROM support_tickets t
                JOIN users u ON t.user_id = u.id
                LEFT JOIN companies c ON t.company_id = c.id
                LEFT JOIN orders o ON t.order_id = o.id
                ORDER BY t.created_at DESC;
            """)
        else:
            tickets = query_db("""
                SELECT t.*, c.name as company_name, o.order_number
                FROM support_tickets t
                LEFT JOIN companies c ON t.company_id = c.id
                LEFT JOIN orders o ON t.order_id = o.id
                WHERE t.user_id = ? ORDER BY t.created_at DESC;
            """, (user['id'],))
        return json_response(start_response, {'status': 'success', 'tickets': tickets})

    if path == '/api/client/tickets' and method == 'POST':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        data = parse_body(environ)
        subject = data.get('subject', 'Support Inquiry')
        category = data.get('category', 'General Support')
        priority = data.get('priority', 'Medium')
        message = data.get('description', '')
        company_id = data.get('company_id')
        order_id = data.get('order_id')
        
        import random
        tnum = f"TICK-2026-{random.randint(1000, 9999)}"
        tid = execute_db("""
            INSERT INTO support_tickets (ticket_number, user_id, order_id, company_id, subject, category, priority, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """, (tnum, user['id'], order_id, company_id, subject, category, priority, 'Open'))
        
        execute_db("""
            INSERT INTO support_messages (ticket_id, sender_id, sender_name, sender_role, message)
            VALUES (?, ?, ?, ?, ?);
        """, (tid, user['id'], user['full_name'], user['role'], message))
        
        log_activity(user, 'SUPPORT_TICKET_CREATED', 'support_tickets', str(tid), f"Created ticket {tnum}")
        return json_response(start_response, {'status': 'success', 'message': 'Support ticket submitted.', 'ticket_id': tid})

    if path.startswith('/api/client/tickets/') and path.endswith('/messages'):
        tid = path.split('/')[4]
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
            
        t_rec = query_db("SELECT * FROM support_tickets WHERE id = ?;", (tid,), one=True)
        if not t_rec:
            return json_response(start_response, {'status': 'error', 'message': 'Ticket not found'}, "404 Not Found")
            
        if user['role'] == 'CLIENT':
            if t_rec['user_id'] != user['id']:
                return json_response(start_response, {'status': 'error', 'message': 'Access denied to target ticket'}, "403 Forbidden")
        elif not is_internal_staff(user):
            return json_response(start_response, {'status': 'error', 'message': 'Access denied to target ticket'}, "403 Forbidden")

        if method == 'GET':
            msgs = query_db("SELECT * FROM support_messages WHERE ticket_id = ? ORDER BY created_at ASC;", (tid,))
            return json_response(start_response, {'status': 'success', 'ticket': dict(t_rec), 'messages': msgs})
        elif method == 'POST':
            data = parse_body(environ)
            msg_text = data.get('message', '').strip()
            if msg_text:
                execute_db("""
                    INSERT INTO support_messages (ticket_id, sender_id, sender_name, sender_role, message)
                    VALUES (?, ?, ?, ?, ?);
                """, (tid, user['id'], user['full_name'], user['role'], msg_text))
                
                # Update ticket status if client replied
                if user['role'] == 'CLIENT':
                    execute_db("UPDATE support_tickets SET status = 'In Progress' WHERE id = ?;", (tid,))
                    last_staff = query_db("""
                        SELECT sender_id FROM support_messages
                        WHERE ticket_id = ? AND sender_role != 'CLIENT'
                        ORDER BY id DESC LIMIT 1;
                    """, (tid,), one=True)
                    if last_staff:
                        execute_db("""
                            INSERT INTO notifications (user_id, title, message, type, link)
                            VALUES (?, ?, ?, ?, ?);
                        """, (last_staff['sender_id'], 'Customer replied', f"Customer replied on ticket {t_rec['ticket_number']}.", 'support', '#admin-orders'))
                else:
                    execute_db("UPDATE support_tickets SET status = 'Waiting for Customer' WHERE id = ?;", (tid,))
            return json_response(start_response, {'status': 'success', 'message': 'Message sent.'})

    if path == '/api/client/notifications' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        notes = query_db("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC;", (user['id'],))
        unread_cnt = query_db("SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0;", (user['id'],), one=True)['c']
        return json_response(start_response, {'status': 'success', 'notifications': notes, 'unread_count': unread_cnt})

    if path == '/api/client/notifications/read' and method == 'POST':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        execute_db("UPDATE notifications SET is_read = 1 WHERE user_id = ?;", (user['id'],))
        return json_response(start_response, {'status': 'success', 'message': 'Notifications marked read'})

    # ----------------------------------------------------
    # API: Admin CMS
    # ----------------------------------------------------
    if path == '/api/admin/stats' and method == 'GET':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        if not can_view_admin_dashboard(user):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
            
        tot_customers = query_db("SELECT COUNT(*) as c FROM users WHERE role = 'CLIENT';", one=True)['c']
        tot_companies = query_db("SELECT COUNT(*) as c FROM companies;", one=True)['c']
        tot_orders = query_db("SELECT COUNT(*) as c FROM orders;", one=True)['c']
        pending_orders = query_db("SELECT COUNT(*) as c FROM orders WHERE status IN ('Pending', 'Processing', 'In Progress');", one=True)['c']
        completed_orders = query_db("SELECT COUNT(*) as c FROM orders WHERE status = 'Completed';", one=True)['c']
        total_revenue = query_db("SELECT COALESCE(SUM(total), 0) as s FROM orders WHERE status != 'Cancelled';", one=True)['s']
        pending_payments = query_db("SELECT COALESCE(SUM(total), 0) as s FROM invoices WHERE status = 'Pending';", one=True)['s']
        open_tickets = query_db("SELECT COUNT(*) as c FROM support_tickets WHERE status IN ('Open', 'In Progress');", one=True)['c']
        
        return json_response(start_response, {
            'status': 'success',
            'stats': {
                'total_customers': tot_customers,
                'total_companies': tot_companies,
                'total_orders': tot_orders,
                'pending_orders': pending_orders,
                'completed_orders': completed_orders,
                'total_revenue': f"£{total_revenue:,.2f}",
                'pending_payments': f"£{pending_payments:,.2f}",
                'open_tickets': open_tickets
            },
            'charts': {
                'monthly': build_monthly_revenue_chart(6)
            }
        })

    if path == '/api/admin/customers' and method == 'GET':
        if not user or not check_permission(user, 'clients.view'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        sql = """
            SELECT u.*, 
            (SELECT COUNT(*) FROM companies WHERE user_id = u.id) as companies_count,
            (SELECT COUNT(*) FROM orders WHERE user_id = u.id) as orders_count
            FROM users u
            WHERE u.role = 'CLIENT'
        """
        params = []
        if user['role'] == 'MANAGER':
            sql += " AND u.id IN (SELECT user_id FROM orders WHERE assigned_staff_id = ? OR assigned_staff_id IS NULL OR assigned_staff_id IN (SELECT id FROM users WHERE role = 'STAFF'))"
            params.append(user['id'])
        sql += " ORDER BY u.created_at DESC;"
        customers = query_db(sql, params)
        public_customers = []
        for row in customers:
            item = public_staff_user(row) or {}
            item['companies_count'] = row.get('companies_count')
            item['orders_count'] = row.get('orders_count')
            public_customers.append(item)
        return json_response(start_response, {'status': 'success', 'customers': public_customers})

    if path == '/api/admin/customers/status' and method == 'POST':
        if not user or not check_permission(user, 'clients.edit'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        data = parse_body(environ)
        cid = data.get('customer_id')
        new_status = data.get('status')
        execute_db("UPDATE users SET status = ? WHERE id = ?;", (new_status, cid))
        log_activity(user, 'CUSTOMER_STATUS_CHANGE', 'users', str(cid), f"Updated status to {new_status}")
        return json_response(start_response, {'status': 'success', 'message': f'Customer status updated to {new_status}'})

    if path == '/api/admin/orders' and method == 'GET':
        if not user or not check_permission(user, 'orders.view'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        qs = urllib.parse.parse_qs(environ.get('QUERY_STRING', ''))
        clauses, params, date_clauses, date_params = build_admin_order_filters(user, qs)
        where_all = clauses + date_clauses
        params_all = params + date_params
        where_sql = (" WHERE " + " AND ".join(where_all)) if where_all else ""
        from_sql = """
            FROM orders o
            JOIN users u ON o.user_id = u.id
            LEFT JOIN companies c ON o.company_id = c.id
            LEFT JOIN users s ON o.assigned_staff_id = s.id
        """
        try:
            page = max(int(_qs_first(qs, 'page', '1') or '1'), 1)
        except ValueError:
            page = 1
        try:
            limit = int(_qs_first(qs, 'limit', '25') or '25')
        except ValueError:
            limit = 25
        limit = min(max(limit, 1), 100)
        offset = (page - 1) * limit

        total_row = query_db("SELECT COUNT(*) as c " + from_sql + where_sql, params_all, one=True)
        total_records = (total_row or {}).get('c') or 0
        stats_row = query_db("""
            SELECT
                COUNT(*) as total_orders,
                SUM(CASE WHEN o.status IN ('Pending', 'Pending Verification') THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN o.status IN ('Processing', 'In Progress') THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN o.status = 'Completed' THEN 1 ELSE 0 END) as completed,
                COALESCE(SUM(CASE WHEN o.status != 'Cancelled' THEN o.total ELSE 0 END), 0) as revenue
        """ + from_sql + where_sql, params_all, one=True) or {}

        today = datetime.date.today()
        month_start = f"{today.year:04d}-{today.month:02d}-01"
        month_where = clauses + ["date(o.created_at) >= date(?)", "date(o.created_at) <= date(?)"]
        month_params = params + [month_start, str(today)]
        month_sql = " WHERE " + " AND ".join(month_where) if month_where else ""
        month_row = query_db("SELECT COUNT(*) as c " + from_sql + month_sql, month_params, one=True)

        orders = query_db("""
            SELECT o.id, o.order_number, o.user_id, o.company_id, o.service_id, o.service_name,
                   o.price, o.vat, o.total, o.status, o.progress_percent, o.payment_mode, o.assigned_staff_id,
                   o.created_at, o.updated_at, o.expected_date, o.delivery_label,
                   u.full_name as client_name, u.email as client_email, c.name as company_name,
                   s.full_name as assigned_staff_name,
                   COALESCE((SELECT GROUP_CONCAT(li.product_name, ', ') FROM order_line_items li WHERE li.order_id = o.id), o.service_name) as products_summary,
                   (SELECT li.category_name FROM order_line_items li WHERE li.order_id = o.id ORDER BY li.sort_order ASC, li.id ASC LIMIT 1) as category_name,
                   (SELECT inv.status FROM invoices inv WHERE inv.order_id = o.id ORDER BY inv.id DESC LIMIT 1) as payment_status
        """ + from_sql + where_sql + " ORDER BY o.created_at DESC LIMIT ? OFFSET ?;", params_all + [limit, offset])

        scope_sql, scope_params = manager_order_scope(user)
        facet_where = (" WHERE " + scope_sql) if scope_sql else ""
        products = query_db("""
            SELECT name FROM (
                SELECT DISTINCT o.service_name AS name FROM orders o
                """ + facet_where + """
                UNION
                SELECT DISTINCT li.product_name AS name
                FROM order_line_items li JOIN orders o ON o.id = li.order_id
                """ + facet_where + """
            ) t WHERE name IS NOT NULL AND TRIM(name) != '' ORDER BY name COLLATE NOCASE;
        """, scope_params + scope_params)
        categories = query_db("""
            SELECT name FROM (
                SELECT DISTINCT li.category_name AS name
                FROM order_line_items li JOIN orders o ON o.id = li.order_id
                """ + facet_where + """
                UNION
                SELECT DISTINCT sv.category AS name
                FROM services sv
                JOIN orders o ON o.service_id = sv.id
                """ + facet_where + """
            ) t WHERE name IS NOT NULL AND TRIM(name) != '' ORDER BY name COLLATE NOCASE;
        """, scope_params + scope_params)
        customers = query_db("""
            SELECT DISTINCT u.id, u.full_name
            FROM orders o JOIN users u ON u.id = o.user_id
            """ + facet_where + """
            ORDER BY u.full_name COLLATE NOCASE;
        """, scope_params)
        years_sql = "SELECT DISTINCT strftime('%Y', o.created_at) AS year FROM orders o"
        if scope_sql:
            years_sql += " WHERE " + scope_sql + " AND o.created_at IS NOT NULL"
        else:
            years_sql += " WHERE o.created_at IS NOT NULL"
        years_sql += " ORDER BY year DESC;"
        years = query_db(years_sql, scope_params)

        stats = {
            'total_orders': int(stats_row.get('total_orders') or 0),
            'pending': int(stats_row.get('pending') or 0),
            'in_progress': int(stats_row.get('in_progress') or 0),
            'completed': int(stats_row.get('completed') or 0),
            'this_month': int((month_row or {}).get('c') or 0)
        }
        if can_view_revenue(user):
            stats['revenue'] = float(stats_row.get('revenue') or 0)

        return json_response(start_response, {
            'status': 'success',
            'orders': orders,
            'pagination': {
                'page': page,
                'limit': limit,
                'total': total_records,
                'total_pages': (total_records + limit - 1) // limit if limit else 1
            },
            'stats': stats,
            'facets': {
                'products': [row['name'] for row in products],
                'categories': [row['name'] for row in categories],
                'customers': customers,
                'years': [row['year'] for row in years if row.get('year')]
            }
        })

    if path.startswith('/api/admin/orders/') and path.endswith('/conversation') and method in ('GET', 'POST'):
        if not user or not is_internal_staff(user):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        oid = path.split('/')[4]
        order = query_db("""
            SELECT o.*, u.full_name as client_name, u.email as client_email, u.id as client_id
            FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?;
        """, (oid,), one=True)
        if not order:
            return json_response(start_response, {'status': 'error', 'message': 'Order not found'}, "404 Not Found")
        ticket = query_db("""
            SELECT * FROM support_tickets WHERE order_id = ? AND user_id = ?
            ORDER BY created_at DESC LIMIT 1;
        """, (oid, order['user_id']), one=True)
        if method == 'GET':
            msgs = query_db("SELECT * FROM support_messages WHERE ticket_id = ? ORDER BY created_at ASC;", (ticket['id'],)) if ticket else []
            return json_response(start_response, {
                'status': 'success',
                'ticket': dict(ticket) if ticket else None,
                'messages': msgs
            })
        data = parse_body(environ)
        msg_text = (data.get('message') or '').strip()
        if not msg_text:
            return json_response(start_response, {'status': 'error', 'message': 'Message is required'}, "400 Bad Request")
        if not ticket:
            tnum = f"TICK-ORD-{oid}-{uuid.uuid4().hex[:6].upper()}"
            tid = execute_db("""
                INSERT INTO support_tickets (ticket_number, user_id, order_id, company_id, subject, category, priority, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?);
            """, (
                tnum, order['user_id'], oid, order.get('company_id'),
                f"Order {order['order_number']}", 'Order Advisory', 'Medium', 'Waiting for Customer'
            ))
        else:
            tid = ticket['id']
            execute_db("UPDATE support_tickets SET status = 'Waiting for Customer' WHERE id = ?;", (tid,))
        execute_db("""
            INSERT INTO support_messages (ticket_id, sender_id, sender_name, sender_role, message)
            VALUES (?, ?, ?, ?, ?);
        """, (tid, user['id'], user['full_name'], user['role'], msg_text))
        execute_db("""
            INSERT INTO notifications (user_id, title, message, type, link)
            VALUES (?, ?, ?, ?, ?);
        """, (
            order['user_id'],
            'New message from Brixen',
            f"You have a new message about order {order['order_number']}.",
            'support',
            '/support'
        ))
        EmailService.send_notification_email(
            order['client_email'],
            f"New message - {order['order_number']}",
            f"Hello {order['client_name']},\n\nYou have a new message in your Brixen Client Portal about order {order['order_number']}.\n\nSign in to read and reply: {portal_page_url()}"
        )
        log_activity(user, 'ORDER_MESSAGE', 'support_tickets', str(tid), f"Messaged client on {order['order_number']}")
        ticket = query_db("SELECT * FROM support_tickets WHERE id = ?;", (tid,), one=True)
        msgs = query_db("SELECT * FROM support_messages WHERE ticket_id = ? ORDER BY created_at ASC;", (tid,))
        return json_response(start_response, {'status': 'success', 'ticket': dict(ticket), 'messages': msgs})

    if path.startswith('/api/admin/orders/') and method == 'PUT':
        if not user or not check_permission(user, 'orders.edit'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        oid = path.split('/')[-1]
        try:
            int(oid)
        except ValueError:
            return json_response(start_response, {'status': 'error', 'message': 'Order not found'}, "404 Not Found")
        existing = query_db("SELECT * FROM orders WHERE id = ?;", (oid,), one=True)
        if not existing:
            return json_response(start_response, {'status': 'error', 'message': 'Order not found'}, "404 Not Found")
        if not staff_can_access_admin_order(user, existing):
            return json_response(start_response, {'status': 'error', 'message': 'Order not found'}, "404 Not Found")
        data = parse_body(environ)
        
        status = data.get('status')
        progress = data.get('progress_percent')
        notes = data.get('notes')
        assign_raw = data.get('assigned_staff_id') if 'assigned_staff_id' in data else None
        assigned_staff_id = None
        if 'assigned_staff_id' in data:
            assigned_staff_id, assign_err = to_optional_int(assign_raw, 'assigned_staff_id')
            if assign_err:
                return json_response(start_response, {'status': 'error', 'message': assign_err}, "400 Bad Request")
            ok, msg = validate_task_assignee(assigned_staff_id)
            if not ok:
                return json_response(start_response, {'status': 'error', 'message': msg}, "400 Bad Request")

        if status is not None:
            if status not in ORDER_STATUSES:
                return json_response(start_response, {'status': 'error', 'message': 'Invalid order status'}, "400 Bad Request")
            execute_db("UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?;", (status, oid))
        if progress is not None:
            try:
                progress_val = max(0, min(100, int(progress)))
            except (TypeError, ValueError):
                return json_response(start_response, {'status': 'error', 'message': 'Invalid progress'}, "400 Bad Request")
            execute_db("UPDATE orders SET progress_percent = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?;", (progress_val, oid))
        if notes is not None:
            execute_db("UPDATE orders SET notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?;", (notes, oid))
        if 'assigned_staff_id' in data:
            execute_db("UPDATE orders SET assigned_staff_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?;", (assigned_staff_id, oid))
        if 'payment_mode' in data:
            payment_mode = (data.get('payment_mode') or '').strip() or None
            if payment_mode and payment_mode not in ORDER_PAYMENT_MODES:
                return json_response(start_response, {'status': 'error', 'message': 'Invalid payment mode'}, "400 Bad Request")
            execute_db("UPDATE orders SET payment_mode = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?;", (payment_mode, oid))

        history_parts = []
        if status is not None:
            history_parts.append(f"Status changed to {status}")
        if progress is not None:
            history_parts.append(f"Progress set to {int(progress)}%")
        if notes is not None:
            history_parts.append("Internal notes updated")
        if 'assigned_staff_id' in data:
            history_parts.append("Assigned staff updated")
        if 'payment_mode' in data:
            history_parts.append("Payment mode updated")
        if history_parts:
            append_order_history(oid, " · ".join(history_parts))
            
        target_order = query_db("SELECT o.*, u.email, u.full_name FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?;", (oid,), one=True)
        if target_order and (status is not None or progress is not None):
            # Auto trigger notification for client
            msg = f"Order {target_order['order_number']} status changed to '{target_order['status']}' ({target_order['progress_percent']}% complete)."
            execute_db("""
                INSERT INTO notifications (user_id, title, message, type, link)
                VALUES (?, ?, ?, ?, ?);
            """, (target_order['user_id'], 'Order Status Updated', msg, 'order_update', '/orders'))
            
            # P4: Email notification trigger
            EmailService.send_notification_email(target_order['email'], f"Order Status Updated - {target_order['order_number']}", f"Hello {target_order['full_name']},\n\nYour order {target_order['order_number']} has been updated to '{target_order['status']}' ({target_order['progress_percent']}% complete).\n\nLog in to your Brixen Portal to track progress: {portal_page_url()}")
            
        log_activity(user, 'ORDER_UPDATE', 'orders', str(oid), f"Updated order #{oid} status to {status}")
        return json_response(start_response, {'status': 'success', 'message': 'Order updated successfully'})

    if path.startswith('/api/admin/orders/') and method == 'DELETE':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        if not can_delete_orders(user):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        oid = path.split('/')[-1]
        try:
            int(oid)
        except ValueError:
            return json_response(start_response, {'status': 'error', 'message': 'Order not found'}, "404 Not Found")
        existing = query_db("SELECT * FROM orders WHERE id = ?;", (oid,), one=True)
        if not existing:
            return json_response(start_response, {'status': 'error', 'message': 'Order not found'}, "404 Not Found")
        doc_rows = query_db("SELECT file_path FROM documents WHERE order_id = ?;", (oid,))
        file_paths = [row.get('file_path') for row in doc_rows]
        execute_db("DELETE FROM orders WHERE id = ?;", (oid,))
        remove_stored_document_files(file_paths)
        log_activity(user, 'ORDER_DELETE', 'orders', str(oid), f"Deleted order {existing.get('order_number')}")
        return json_response(start_response, {'status': 'success', 'message': 'Order deleted'})

    if path == '/api/admin/services' and method == 'GET':
        denied = require_permission(start_response, user, 'orders.view')
        if denied:
            return denied
        svcs = query_db("SELECT * FROM services ORDER BY created_at DESC;")
        return json_response(start_response, {'status': 'success', 'services': svcs})

    if path == '/api/admin/services' and method == 'POST':
        denied = require_permission(start_response, user, 'settings.manage')
        if denied:
            return denied
        data = parse_body(environ)
        name = (data.get('name') or '').strip()
        description = (data.get('description') or '').strip()
        category = (data.get('category') or '').strip() or 'Corporate'
        if not name:
            return json_response(start_response, {'status': 'error', 'message': 'Service name is required'}, "400 Bad Request")
        try:
            price = float(data.get('price'))
        except (TypeError, ValueError):
            return json_response(start_response, {'status': 'error', 'message': 'Price must be a number'}, "400 Bad Request")
        sid = execute_db("""
            INSERT INTO services (name, description, category, price, duration, status, featured, vat_rate, renewal_period)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            name, description or name, category, price,
            data.get('duration') or '12 Months', 'Active',
            1 if data.get('featured') else 0,
            float(data.get('vat_rate', 0.20) or 0.20),
            data.get('renewal_period') or 'Annual'
        ))
        created = query_db("SELECT * FROM services WHERE id = ?;", (sid,), one=True)
        log_activity(user, 'SERVICE_CREATED', 'services', str(sid), f"Created service {name}")
        return json_response(start_response, {'status': 'success', 'message': 'Service created.', 'service': created})

    if path == '/api/admin/invoices' and method == 'GET':
        denied = require_permission(start_response, user, 'invoices.view')
        if denied:
            return denied
        invoices = query_db("""
            SELECT i.id, i.invoice_number, i.order_id, i.user_id, i.amount, i.tax, i.total,
                   i.status, i.due_date, i.paid_at, i.payment_method, i.created_at,
                   o.order_number, o.service_name, u.full_name as client_name, u.email as client_email
            FROM invoices i
            LEFT JOIN orders o ON i.order_id = o.id
            LEFT JOIN users u ON i.user_id = u.id
            ORDER BY i.created_at DESC;
        """)
        return json_response(start_response, {'status': 'success', 'invoices': invoices})

    if path == '/api/admin/documents' and method == 'GET':
        denied = require_permission(start_response, user, 'documents.view')
        if denied:
            return denied
        docs = query_db("""
            SELECT d.*, u.full_name as client_name, u.email as client_email, c.name as company_name, o.order_number
            FROM documents d
            LEFT JOIN users u ON d.user_id = u.id
            LEFT JOIN companies c ON d.company_id = c.id
            LEFT JOIN orders o ON d.order_id = o.id
            ORDER BY d.created_at DESC;
        """)
        listed = [public_document(d) for d in docs if d]
        return json_response(start_response, {'status': 'success', 'documents': listed})

    if path == '/api/admin/documents' and method == 'POST':
        denied = require_permission(start_response, user, 'documents.upload')
        if denied:
            return denied
        data = parse_body(environ)
        client_id = optional_record_id(data.get('client_id'))
        company_id = optional_record_id(data.get('company_id'))
        order_id = optional_record_id(data.get('order_id'))
        doc_name = (data.get('name') or '').strip() or 'Staff_Document.pdf'
        category = (data.get('category') or 'Order Documents').strip() or 'Order Documents'
        client_message = (data.get('client_message') or data.get('description') or '').strip()
        b64_content = data.get('file_content_base64', '')

        if client_id:
            links, link_err = resolve_client_document_links(client_id, company_id, order_id)
            if link_err:
                status_code = "404 Not Found" if link_err == 'Client not found' else "400 Bad Request"
                return json_response(start_response, {'status': 'error', 'message': link_err}, status_code)
            target_client = links['client']
            target_order = links['order']
            resolved_company_id = company_id
            if not resolved_company_id and target_order:
                resolved_company_id = optional_record_id(target_order.get('company_id'))
            file_bytes, decode_err = decode_document_base64(b64_content)
            if decode_err:
                return json_response(start_response, {'status': 'error', 'message': decode_err}, "400 Bad Request")
            ext, upload_err = validate_uploaded_document(doc_name, file_bytes, require_bytes=True)
            if upload_err:
                return json_response(start_response, {'status': 'error', 'message': upload_err}, "400 Bad Request")
            target_path, store_err = store_client_document_file(target_client['id'], order_id, ext, file_bytes)
            if store_err:
                return json_response(start_response, {'status': 'error', 'message': store_err}, "400 Bad Request")
            file_size_str = format_document_size(len(file_bytes))
            review_notes = (data.get('review_notes') or '').strip() or 'Delivered to client portal'
            doc_id = execute_db("""
                INSERT INTO documents (user_id, company_id, order_id, name, category, file_path, file_type, file_size, status, uploaded_by, review_notes, client_visible, shared_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Approved', ?, ?, 1, CURRENT_TIMESTAMP);
            """, (
                target_client['id'], resolved_company_id, order_id, doc_name, category, target_path,
                DOCUMENT_TYPE_LABELS.get(ext, 'Document'), file_size_str, user['full_name'], review_notes
            ))
            log_activity(user, 'DOCUMENT_UPLOAD', 'documents', str(doc_id), f"Delivered document {doc_name} to client #{target_client['id']}")
            delivery = notify_client_document_uploaded(target_client, doc_name, client_message)
            created = query_db("""
                SELECT d.*, c.name as company_name, o.order_number
                FROM documents d
                LEFT JOIN companies c ON d.company_id = c.id
                LEFT JOIN orders o ON d.order_id = o.id
                WHERE d.id = ?;
            """, (doc_id,), one=True)
            return json_response(start_response, {
                'status': 'success',
                'message': 'Document uploaded successfully.',
                'document': public_document(created),
                'notification_created': delivery['notification_created'],
                'email_sent': delivery['email_sent'],
                'email_status': delivery['email_status'],
            })

        if not order_id:
            return json_response(start_response, {'status': 'error', 'message': 'order_id is required'}, "400 Bad Request")
        order = query_db("SELECT * FROM orders WHERE id = ?;", (order_id,), one=True)
        if not order:
            return json_response(start_response, {'status': 'error', 'message': 'Order not found'}, "404 Not Found")
        file_bytes, decode_err = decode_document_base64(b64_content, default_bytes=b'Brixen internal document')
        if decode_err:
            return json_response(start_response, {'status': 'error', 'message': decode_err}, "400 Bad Request")
        ext, upload_err = validate_uploaded_document(doc_name, file_bytes)
        if upload_err:
            return json_response(start_response, {'status': 'error', 'message': upload_err}, "400 Bad Request")
        target_path, store_err = store_client_document_file(order['user_id'], order_id, ext, file_bytes)
        if store_err:
            return json_response(start_response, {'status': 'error', 'message': store_err}, "400 Bad Request")
        file_size_str = format_document_size(len(file_bytes))
        doc_id = execute_db("""
            INSERT INTO documents (user_id, company_id, order_id, name, category, file_path, file_type, file_size, status, uploaded_by, review_notes, client_visible)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Approved', ?, ?, 0);
        """, (
            order['user_id'], order.get('company_id'), order_id, doc_name, category, target_path,
            DOCUMENT_TYPE_LABELS.get(ext, 'Document'), file_size_str, user['full_name'],
            data.get('review_notes') or 'Internal staff upload'
        ))
        log_activity(user, 'DOCUMENT_UPLOAD', 'documents', str(doc_id), f"Staff uploaded {doc_name} for order {order['order_number']}")
        created = query_db("SELECT * FROM documents WHERE id = ?;", (doc_id,), one=True)
        return json_response(start_response, {
            'status': 'success',
            'message': 'Document stored. It is not visible to the customer until you send it.',
            'document': public_document(created)
        })

    if path.startswith('/api/admin/documents/') and path.endswith('/send') and method == 'POST':
        denied = require_permission(start_response, user, 'documents.send')
        if denied:
            return denied
        doc_id = path.split('/')[4]
        doc = query_db("SELECT d.*, u.email, u.full_name, o.order_number FROM documents d JOIN users u ON d.user_id = u.id LEFT JOIN orders o ON d.order_id = o.id WHERE d.id = ?;", (doc_id,), one=True)
        if not doc:
            return json_response(start_response, {'status': 'error', 'message': 'Document not found'}, "404 Not Found")
        execute_db("""
            UPDATE documents SET client_visible = 1, shared_at = CURRENT_TIMESTAMP, status = 'Approved' WHERE id = ?;
        """, (doc_id,))
        order_label = doc.get('order_number') or 'your account'
        execute_db("""
            INSERT INTO notifications (user_id, title, message, type, link)
            VALUES (?, ?, ?, ?, ?);
        """, (
            doc['user_id'],
            'Document ready',
            f"A document ({doc['name']}) is available in your portal for {order_label}.",
            'document_review',
            '/documents'
        ))
        EmailService.send_notification_email(
            doc['email'],
            'Document ready - Brixen Consultants Portal',
            f"Hello {doc['full_name']},\n\nA document is ready in your Brixen Client Portal.\n\nSign in to Documents to view it: {portal_page_url()}\n\nThis message does not contain a file attachment or storage path."
        )
        log_activity(user, 'DOCUMENT_SENT', 'documents', str(doc_id), f"Sent {doc['name']} to customer")
        updated = query_db("SELECT * FROM documents WHERE id = ?;", (doc_id,), one=True)
        return json_response(start_response, {
            'status': 'success',
            'message': 'Document sent to the customer portal.',
            'document': public_document(updated)
        })

    if path.startswith('/api/admin/documents/') and method == 'PUT':
        denied = require_permission(start_response, user, 'documents.view')
        if denied:
            return denied
        doc_id = path.split('/')[-1]
        data = parse_body(environ)
        status = data.get('status')
        if 'review_notes' in data:
            execute_db("UPDATE documents SET status = ?, review_notes = ? WHERE id = ?;", (status, data.get('review_notes', ''), doc_id))
        else:
            execute_db("UPDATE documents SET status = ? WHERE id = ?;", (status, doc_id))
        
        target_doc = query_db("SELECT * FROM documents WHERE id = ?;", (doc_id,), one=True)
        if target_doc:
            msg = f"Document '{target_doc['name']}' review status: {status}."
            execute_db("""
                INSERT INTO notifications (user_id, title, message, type, link)
                VALUES (?, ?, ?, ?, ?);
            """, (target_doc['user_id'], 'Document Reviewed', msg, 'document_review', '/documents'))
            
        log_activity(user, 'DOCUMENT_REVIEW', 'documents', str(doc_id), f"Reviewed document status to {status}")
        return json_response(start_response, {'status': 'success', 'message': f'Document status updated to {status}'})

    if path == '/api/admin/activity-logs' and method == 'GET':
        denied = require_permission(start_response, user, 'settings.manage')
        if denied:
            return denied
        logs = query_db("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 100;")
        return json_response(start_response, {'status': 'success', 'logs': logs})

    # ----------------------------------------------------
    # API: Staff Task Management
    # ----------------------------------------------------
    if path == '/api/admin/staff' and method == 'GET':
        denied = task_auth_error(start_response, user, 'tasks.view')
        if denied:
            return denied
        qs = urllib.parse.parse_qs(environ.get('QUERY_STRING', ''))
        include_inactive = (qs.get('include_inactive', ['0'])[0] or '').lower() in ('1', 'true', 'yes')
        sql = """
            SELECT id, wordpress_user_id, email, full_name, phone, country, role, department, status, avatar_url, created_at
            FROM users
            WHERE role IN ('STAFF', 'MANAGER', 'ADMIN', 'SUPER_ADMIN')
        """
        if not (include_inactive and check_permission(user, 'staff.manage')):
            sql += " AND status = 'Active'"
        sql += " ORDER BY full_name ASC;"
        staff_rows = query_db(sql)
        return json_response(start_response, {'status': 'success', 'staff': [public_staff_user(row) for row in staff_rows]})

    if path == '/api/admin/staff' and method == 'POST':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        allowed_roles = creatable_roles_for(user)
        if not allowed_roles:
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        data = parse_body(environ)
        full_name = (data.get('full_name') or '').strip()
        email = (data.get('email') or '').strip().lower()
        password = data.get('password') or ''
        confirm_password = data.get('confirm_password')
        phone = (data.get('phone') or '').strip() or None
        country = (data.get('country') or '').strip() or 'United Kingdom'
        role = (data.get('role') or 'STAFF').strip().upper()
        status_val = (data.get('status') or 'Active').strip()
        raw_depts = data.get('departments') if 'departments' in data else data.get('department')
        departments, dept_err = parse_departments(raw_depts)
        if dept_err:
            return json_response(start_response, {'status': 'error', 'message': dept_err}, "400 Bad Request")
        if role == 'CLIENT':
            departments = []
        department = store_departments(departments)
        if not full_name:
            return json_response(start_response, {'status': 'error', 'message': 'Full name is required'}, "400 Bad Request")
        if not email or not STAFF_EMAIL_RE.match(email):
            return json_response(start_response, {'status': 'error', 'message': 'A valid email is required'}, "400 Bad Request")
        if not isinstance(password, str) or len(password) < STAFF_MIN_PASSWORD_LEN:
            return json_response(start_response, {
                'status': 'error',
                'message': f'Password must be at least {STAFF_MIN_PASSWORD_LEN} characters'
            }, "400 Bad Request")
        if confirm_password is not None and confirm_password != password:
            return json_response(start_response, {'status': 'error', 'message': 'Passwords do not match'}, "400 Bad Request")
        if status_val not in USER_STATUSES:
            return json_response(start_response, {'status': 'error', 'message': 'Invalid status'}, "400 Bad Request")
        if role not in USER_ROLES:
            return json_response(start_response, {
                'status': 'error',
                'message': 'Role must be one of: ' + ', '.join(USER_ROLES)
            }, "400 Bad Request")
        if role not in allowed_roles:
            return json_response(start_response, {
                'status': 'error',
                'message': 'You cannot assign that role'
            }, "403 Forbidden")
        existing = query_db("SELECT id FROM users WHERE LOWER(email) = ?;", (email,), one=True)
        if existing:
            return json_response(start_response, {'status': 'error', 'message': 'Email is already in use'}, "409 Conflict")
        local_id = f"local_user_{uuid.uuid4().hex[:16]}"
        user_id = execute_db("""
            INSERT INTO users (wordpress_user_id, email, password_hash, full_name, phone, country, role, status, department)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (local_id, email, hash_password(password), full_name, phone, country, role, status_val, department))
        created = query_db("""
            SELECT id, wordpress_user_id, email, full_name, phone, country, role, department, status, avatar_url, created_at
            FROM users WHERE id = ?;
        """, (user_id,), one=True)
        log_activity(user, 'USER_CREATED', 'users', str(user_id), f"Created user {email} ({role})")
        public_user = public_staff_user(created)
        return json_response(start_response, {
            'status': 'success',
            'message': 'User created. They can sign in with this email and password.',
            'user': public_user
        })

    if path.startswith('/api/admin/staff/') and method == 'PUT':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        if not check_permission(user, 'staff.manage'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        sid = path.rstrip('/').split('/')[-1]
        staff_id, err = to_optional_int(sid, 'staff_id')
        if err or not staff_id:
            return json_response(start_response, {'status': 'error', 'message': 'Invalid staff id'}, "400 Bad Request")
        target = query_db("SELECT * FROM users WHERE id = ?;", (staff_id,), one=True)
        if not target or target['role'] not in TASK_ASSIGNABLE_ROLES:
            return json_response(start_response, {'status': 'error', 'message': 'Staff user not found'}, "404 Not Found")
        data = parse_body(environ)
        raw_depts = data.get('departments') if 'departments' in data else data.get('department')
        departments, dept_err = parse_departments(raw_depts)
        if dept_err:
            return json_response(start_response, {'status': 'error', 'message': dept_err}, "400 Bad Request")
        execute_db("UPDATE users SET department = ? WHERE id = ?;", (store_departments(departments), staff_id))
        updated = query_db("""
            SELECT id, wordpress_user_id, email, full_name, phone, country, role, department, status, avatar_url, created_at
            FROM users WHERE id = ?;
        """, (staff_id,), one=True)
        log_activity(user, 'USER_DEPARTMENT', 'users', str(staff_id), f"Set departments to {', '.join(departments) or 'none'}")
        return json_response(start_response, {'status': 'success', 'user': public_staff_user(updated)})

    if path == '/api/admin/impersonate' and method == 'POST':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        if not check_permission(user, 'staff.manage'):
            return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
        data = parse_body(environ)
        target_id, err = to_optional_int(data.get('user_id'), 'user_id')
        if err or not target_id:
            return json_response(start_response, {'status': 'error', 'message': 'user_id is required'}, "400 Bad Request")
        target = query_db("SELECT * FROM users WHERE id = ?;", (target_id,), one=True)
        if not target:
            return json_response(start_response, {'status': 'error', 'message': 'User not found'}, "404 Not Found")
        if not can_impersonate_user(user, target):
            return json_response(start_response, {'status': 'error', 'message': 'You cannot switch to that user'}, "403 Forbidden")
        current_token = cookie_value(environ, 'session_token')
        origin_token = cookie_value(environ, 'origin_session')
        origin_rec = session_user_from_token(origin_token)
        if not origin_rec:
            origin_token = current_token
        new_token = create_db_session(target['id'])
        log_activity(user, 'USER_IMPERSONATE', 'users', str(target['id']), f"Switched session to {target['email']} ({target['role']})")
        return json_response(start_response, {
            'status': 'success',
            'message': 'Switched user.',
            'user': public_me_user(target, impersonated=True)
        }, extra_headers=[
            ('Set-Cookie', origin_cookie_header(origin_token, environ=environ)),
            ('Set-Cookie', session_cookie_header(new_token, environ=environ)),
        ])

    if path == '/api/admin/impersonate/stop' and method == 'POST':
        if not user:
            return json_response(start_response, {'status': 'error', 'message': 'Not authenticated'}, "401 Unauthorized")
        origin_token = cookie_value(environ, 'origin_session')
        origin_rec = session_user_from_token(origin_token)
        if not origin_rec:
            return json_response(start_response, {'status': 'error', 'message': 'No original session to restore'}, "400 Bad Request")
        current_token = cookie_value(environ, 'session_token')
        if current_token and current_token != origin_token:
            revoke_db_session(current_token)
        log_activity(user, 'USER_IMPERSONATE_STOP', 'users', str(origin_rec['id']), 'Returned to original account')
        return json_response(start_response, {
            'status': 'success',
            'message': 'Returned to original account.',
            'user': public_me_user(origin_rec, impersonated=False)
        }, extra_headers=[
            ('Set-Cookie', origin_cookie_header(clear=True, environ=environ)),
            ('Set-Cookie', session_cookie_header(origin_token, environ=environ)),
        ])

    if path == '/api/admin/tasks' and method == 'GET':
        denied = task_auth_error(start_response, user, 'tasks.view')
        if denied:
            return denied
        qs = urllib.parse.parse_qs(environ.get('QUERY_STRING', ''))
        sql = TASK_DETAIL_SQL + " WHERE 1=1"
        params = []

        if user['role'] == 'STAFF':
            staff_depts = departments_from_user(user)
            if staff_depts:
                placeholders = ','.join('?' for _ in staff_depts)
                sql += f" AND (t.assigned_staff_id = ? OR (t.assigned_staff_id IS NULL AND t.department IN ({placeholders})))"
                params.extend([user['id'], *staff_depts])
            else:
                sql += " AND t.assigned_staff_id = ?"
                params.append(user['id'])
        else:
            assigned_filter = qs.get('assigned_staff_id', [None])[0]
            if assigned_filter:
                assigned_id, err = to_optional_int(assigned_filter, 'assigned_staff_id')
                if err:
                    return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")
                sql += " AND t.assigned_staff_id = ?"
                params.append(assigned_id)

        status_filter = qs.get('status', [None])[0]
        if status_filter:
            if status_filter not in TASK_STATUSES:
                return json_response(start_response, {'status': 'error', 'message': 'Invalid status'}, "400 Bad Request")
            sql += " AND t.status = ?"
            params.append(status_filter)

        priority_filter = qs.get('priority', [None])[0]
        if priority_filter:
            if priority_filter not in TASK_PRIORITIES:
                return json_response(start_response, {'status': 'error', 'message': 'Invalid priority'}, "400 Bad Request")
            sql += " AND t.priority = ?"
            params.append(priority_filter)

        client_filter = qs.get('client_id', [None])[0]
        if client_filter:
            client_id, err = to_optional_int(client_filter, 'client_id')
            if err:
                return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")
            sql += " AND t.client_id = ?"
            params.append(client_id)

        order_filter = qs.get('order_id', [None])[0]
        if order_filter:
            order_id, err = to_optional_int(order_filter, 'order_id')
            if err:
                return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")
            sql += " AND t.order_id = ?"
            params.append(order_id)

        department_filter, dept_err = normalize_department(qs.get('department', [None])[0])
        if dept_err:
            return json_response(start_response, {'status': 'error', 'message': dept_err}, "400 Bad Request")
        if department_filter:
            sql += " AND t.department = ?"
            params.append(department_filter)

        due_filter = qs.get('due', [None])[0]
        if due_filter == 'overdue':
            sql += " AND t.due_date IS NOT NULL AND date(t.due_date) < date('now') AND t.status NOT IN ('Completed', 'Cancelled')"
        elif due_filter == 'today':
            sql += " AND t.due_date IS NOT NULL AND date(t.due_date) = date('now')"
        elif due_filter:
            return json_response(start_response, {'status': 'error', 'message': 'Invalid due filter'}, "400 Bad Request")

        sql += " ORDER BY t.created_at DESC;"
        tasks = query_db(sql, params)
        return json_response(start_response, {'status': 'success', 'tasks': tasks})

    if path == '/api/admin/tasks' and method == 'POST':
        denied = task_auth_error(start_response, user, 'tasks.create')
        if denied:
            return denied
        data = parse_body(environ)
        title = (data.get('title') or '').strip()
        if not title:
            return json_response(start_response, {'status': 'error', 'message': 'Title is required'}, "400 Bad Request")

        description = data.get('description')
        internal_notes = data.get('internal_notes')
        due_date = data.get('due_date') or None
        priority = data.get('priority') or 'Medium'
        if priority not in TASK_PRIORITIES:
            return json_response(start_response, {'status': 'error', 'message': 'Invalid priority'}, "400 Bad Request")

        assigned_staff_id, err = to_optional_int(data.get('assigned_staff_id'), 'assigned_staff_id')
        if err:
            return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")
        department, dept_err = normalize_department(data.get('department'))
        if dept_err:
            return json_response(start_response, {'status': 'error', 'message': dept_err}, "400 Bad Request")
        client_id, err = to_optional_int(data.get('client_id'), 'client_id')
        if err:
            return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")
        company_id, err = to_optional_int(data.get('company_id'), 'company_id')
        if err:
            return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")
        order_id, err = to_optional_int(data.get('order_id'), 'order_id')
        if err:
            return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")

        ok, msg = validate_task_assignee(assigned_staff_id)
        if not ok:
            return json_response(start_response, {'status': 'error', 'message': msg}, "400 Bad Request")
        ok, msg, client_id, company_id, order_id = validate_task_links(client_id, company_id, order_id)
        if not ok:
            return json_response(start_response, {'status': 'error', 'message': msg}, "400 Bad Request")

        task_id = execute_db("""
            INSERT INTO tasks (
                title, description, priority, status, due_date, department,
                assigned_staff_id, created_by_id, client_id, company_id, order_id,
                internal_notes, updated_at
            ) VALUES (?, ?, ?, 'Open', ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'));
        """, (title, description, priority, due_date, department, assigned_staff_id, user['id'], client_id, company_id, order_id, internal_notes))

        log_activity(user, 'TASK_CREATED', 'tasks', str(task_id), f"Created task '{title}'")
        notify_staff_task(
            assigned_staff_id, user['id'],
            'Task Assigned',
            f"You have been assigned task '{title}'.",
            'task_assigned'
        )
        created = fetch_task(task_id)
        return json_response(start_response, {'status': 'success', 'message': 'Task created.', 'task': dict(created)})

    if path.startswith('/api/admin/tasks/') and path.endswith('/complete') and method == 'POST':
        denied = task_auth_error(start_response, user, 'tasks.complete')
        if denied:
            return denied
        parts = path.strip('/').split('/')
        if len(parts) != 5 or not parts[3].isdigit():
            return json_response(start_response, {'status': 'error', 'message': 'Invalid task id'}, "400 Bad Request")
        task_id = int(parts[3])
        task = fetch_task(task_id)
        if not task:
            return json_response(start_response, {'status': 'error', 'message': 'Task not found'}, "404 Not Found")
        if not staff_can_access_task(user, task):
            return json_response(start_response, {'status': 'error', 'message': 'Access denied to target task'}, "403 Forbidden")

        execute_db("""
            UPDATE tasks
            SET status = 'Completed', completed_at = datetime('now'), updated_at = datetime('now')
            WHERE id = ?;
        """, (task_id,))
        log_activity(user, 'TASK_COMPLETED', 'tasks', str(task_id), f"Completed task '{task['title']}'")
        notify_staff_task(
            task.get('assigned_staff_id'), user['id'],
            'Task Completed',
            f"Task '{task['title']}' has been marked completed.",
            'task_completed'
        )
        notify_staff_task(
            task.get('created_by_id'), user['id'],
            'Task Completed',
            f"Task '{task['title']}' has been marked completed.",
            'task_completed'
        )
        updated = fetch_task(task_id)
        return json_response(start_response, {'status': 'success', 'message': 'Task completed.', 'task': dict(updated)})

    if path.startswith('/api/admin/tasks/') and method == 'GET':
        denied = task_auth_error(start_response, user, 'tasks.view')
        if denied:
            return denied
        tid = path.rstrip('/').split('/')[-1]
        if not tid.isdigit():
            return json_response(start_response, {'status': 'error', 'message': 'Invalid task id'}, "400 Bad Request")
        task = fetch_task(int(tid))
        if not task:
            return json_response(start_response, {'status': 'error', 'message': 'Task not found'}, "404 Not Found")
        if not staff_can_access_task(user, task):
            return json_response(start_response, {'status': 'error', 'message': 'Access denied to target task'}, "403 Forbidden")
        return json_response(start_response, {'status': 'success', 'task': dict(task)})

    if path.startswith('/api/admin/tasks/') and method == 'PUT':
        denied = task_auth_error(start_response, user, 'tasks.edit')
        if denied:
            return denied
        tid = path.rstrip('/').split('/')[-1]
        if not tid.isdigit():
            return json_response(start_response, {'status': 'error', 'message': 'Invalid task id'}, "400 Bad Request")
        task_id = int(tid)
        task = fetch_task(task_id)
        if not task:
            return json_response(start_response, {'status': 'error', 'message': 'Task not found'}, "404 Not Found")
        if not staff_can_access_task(user, task):
            return json_response(start_response, {'status': 'error', 'message': 'Access denied to target task'}, "403 Forbidden")

        data = parse_body(environ)
        title = task['title'] if data.get('title') is None else str(data.get('title')).strip()
        if not title:
            return json_response(start_response, {'status': 'error', 'message': 'Title is required'}, "400 Bad Request")
        description = task['description'] if data.get('description') is None else data.get('description')
        internal_notes = task['internal_notes'] if data.get('internal_notes') is None else data.get('internal_notes')
        due_date = task['due_date'] if data.get('due_date') is None else (data.get('due_date') or None)
        priority = task['priority'] if data.get('priority') is None else data.get('priority')
        status_val = task['status'] if data.get('status') is None else data.get('status')
        if priority not in TASK_PRIORITIES:
            return json_response(start_response, {'status': 'error', 'message': 'Invalid priority'}, "400 Bad Request")
        if status_val not in TASK_STATUSES:
            return json_response(start_response, {'status': 'error', 'message': 'Invalid status'}, "400 Bad Request")

        assigned_staff_id = task['assigned_staff_id']
        department = task.get('department')
        client_id = task['client_id']
        company_id = task['company_id']
        order_id = task['order_id']

        if 'department' in data:
            new_dept, dept_err = normalize_department(data.get('department'))
            if dept_err:
                return json_response(start_response, {'status': 'error', 'message': dept_err}, "400 Bad Request")
            if new_dept != task.get('department') and not check_permission(user, 'tasks.assign'):
                return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
            department = new_dept

        if 'assigned_staff_id' in data:
            new_assignee, err = to_optional_int(data.get('assigned_staff_id'), 'assigned_staff_id')
            if err:
                return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")
            if new_assignee != task['assigned_staff_id'] and not check_permission(user, 'tasks.assign'):
                return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
            assigned_staff_id = new_assignee

        relink_requested = any(k in data for k in ('client_id', 'company_id', 'order_id'))
        if relink_requested:
            if not check_permission(user, 'tasks.assign'):
                return json_response(start_response, {'status': 'error', 'message': 'Insufficient permissions'}, "403 Forbidden")
            if 'client_id' in data:
                client_id, err = to_optional_int(data.get('client_id'), 'client_id')
                if err:
                    return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")
            if 'company_id' in data:
                company_id, err = to_optional_int(data.get('company_id'), 'company_id')
                if err:
                    return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")
            if 'order_id' in data:
                order_id, err = to_optional_int(data.get('order_id'), 'order_id')
                if err:
                    return json_response(start_response, {'status': 'error', 'message': err}, "400 Bad Request")

        ok, msg = validate_task_assignee(assigned_staff_id)
        if not ok:
            return json_response(start_response, {'status': 'error', 'message': msg}, "400 Bad Request")
        ok, msg, client_id, company_id, order_id = validate_task_links(client_id, company_id, order_id)
        if not ok:
            return json_response(start_response, {'status': 'error', 'message': msg}, "400 Bad Request")

        completed_at = task['completed_at']
        if status_val == 'Completed' and task['status'] != 'Completed':
            completed_at_sql = "datetime('now')"
        elif status_val != 'Completed':
            completed_at_sql = "NULL"
        else:
            completed_at_sql = "?"

        if completed_at_sql == "?":
            execute_db("""
                UPDATE tasks SET
                    title = ?, description = ?, priority = ?, status = ?, due_date = ?,
                    department = ?, assigned_staff_id = ?, client_id = ?, company_id = ?, order_id = ?,
                    internal_notes = ?, completed_at = ?, updated_at = datetime('now')
                WHERE id = ?;
            """, (title, description, priority, status_val, due_date, department, assigned_staff_id, client_id, company_id, order_id, internal_notes, completed_at, task_id))
        else:
            execute_db(f"""
                UPDATE tasks SET
                    title = ?, description = ?, priority = ?, status = ?, due_date = ?,
                    department = ?, assigned_staff_id = ?, client_id = ?, company_id = ?, order_id = ?,
                    internal_notes = ?, completed_at = {completed_at_sql}, updated_at = datetime('now')
                WHERE id = ?;
            """, (title, description, priority, status_val, due_date, department, assigned_staff_id, client_id, company_id, order_id, internal_notes, task_id))

        log_activity(user, 'TASK_UPDATED', 'tasks', str(task_id), f"Updated task '{title}'")
        if assigned_staff_id and assigned_staff_id != task['assigned_staff_id']:
            notify_staff_task(
                assigned_staff_id, user['id'],
                'Task Assigned',
                f"You have been assigned task '{title}'.",
                'task_assigned'
            )
        updated = fetch_task(task_id)
        return json_response(start_response, {'status': 'success', 'message': 'Task updated successfully', 'task': dict(updated)})

    if path == '/api/admin/settings' and method == 'POST':
        denied = require_permission(start_response, user, 'settings.manage')
        if denied:
            return denied
        data = parse_body(environ)
        for k, v in data.items():
            execute_db("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?);", (k, str(v)))
        log_activity(user, 'SETTINGS_UPDATE', 'settings', '1', 'Updated admin system settings')
        return json_response(start_response, {'status': 'success', 'message': 'System settings saved.'})

    start_response("404 Not Found", [('Content-Type', 'application/json')])
    return [json.dumps({'status': 'error', 'message': f'Route {path} not found'}).encode('utf-8')]

def run():
    global PORT
    port_to_try = PORT
    for attempt in range(5):
        try:
            print(f"Hypetex Limited Server starting on http://{HOST}:{port_to_try}")
            httpd = make_server(HOST, port_to_try, application)
            httpd.serve_forever()
            break
        except OSError as e:
            if getattr(e, 'errno', None) == 48 or 'Address already in use' in str(e):
                print(f"Port {port_to_try} busy, trying port {port_to_try + 1}...")
                port_to_try += 1
            else:
                raise e

if __name__ == '__main__':
    run()
