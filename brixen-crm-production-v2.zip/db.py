import sqlite3
import os
import json
import hashlib
import hmac
import secrets
import re
from argon2 import PasswordHasher, Type
from argon2.exceptions import VerifyMismatchError, VerificationError

try:
    from argon2.exceptions import InvalidHashError
except ImportError:
    from argon2.exceptions import InvalidHash as InvalidHashError

DB_PATH = os.environ.get('DATABASE_URL') or os.path.join(os.path.dirname(__file__), 'hypetex.db')
SCHEMA_PATH = os.path.join(os.path.dirname(__file__), 'schema.sql')

_ARGON2_HASHER = PasswordHasher(type=Type.ID)
_LEGACY_SHA256_RE = re.compile(r'^[0-9a-f]{64}$')
_DUMMY_ARGON2_HASH = None


def _is_legacy_sha256(stored_hash):
    return isinstance(stored_hash, str) and bool(_LEGACY_SHA256_RE.fullmatch(stored_hash))


def _is_argon2id(stored_hash):
    return isinstance(stored_hash, str) and stored_hash.startswith('$argon2id$')


def _dummy_argon2_verify(password):
    global _DUMMY_ARGON2_HASH
    if _DUMMY_ARGON2_HASH is None:
        _DUMMY_ARGON2_HASH = hash_password(secrets.token_urlsafe(32))
    verify_password(password if password is not None else '', _DUMMY_ARGON2_HASH)


def hash_password(password):
    if password is None:
        password = ''
    if not isinstance(password, str):
        password = str(password)
    return _ARGON2_HASHER.hash(password)


def verify_password(password, stored_hash):
    if stored_hash is None:
        _dummy_argon2_verify(password)
        return False
    if password is None:
        password = ''
    if not isinstance(password, str):
        password = str(password)
    if not isinstance(stored_hash, str) or not stored_hash:
        return False
    if _is_argon2id(stored_hash):
        try:
            return _ARGON2_HASHER.verify(stored_hash, password)
        except (VerifyMismatchError, VerificationError, InvalidHashError, TypeError, ValueError):
            return False
    if _is_legacy_sha256(stored_hash):
        digest = hashlib.sha256(password.encode('utf-8')).hexdigest()
        return hmac.compare_digest(digest, stored_hash)
    return False


def needs_rehash(stored_hash):
    if _is_legacy_sha256(stored_hash):
        return True
    if _is_argon2id(stored_hash):
        try:
            return _ARGON2_HASHER.check_needs_rehash(stored_hash)
        except (InvalidHashError, TypeError, ValueError):
            return False
    return False


def unusable_password_hash():
    return hash_password(secrets.token_urlsafe(32))


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    return conn

def init_db():
    conn = get_db()
    with open(SCHEMA_PATH, 'r') as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()
    ensure_schema()


def ensure_schema():
    """Additive, non-destructive columns/tables for existing local databases."""
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS order_line_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            woocommerce_product_id TEXT,
            woocommerce_variation_id TEXT,
            sku TEXT,
            product_name TEXT NOT NULL,
            category_name TEXT,
            category_id TEXT,
            quantity INTEGER NOT NULL DEFAULT 1,
            unit_price REAL NOT NULL DEFAULT 0,
            line_total REAL NOT NULL DEFAULT 0,
            sort_order INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
        );
    """)
    doc_cols = {row[1] for row in conn.execute("PRAGMA table_info(documents)").fetchall()}
    if 'client_visible' not in doc_cols:
        conn.execute("ALTER TABLE documents ADD COLUMN client_visible INTEGER NOT NULL DEFAULT 1")
    if 'shared_at' not in doc_cols:
        conn.execute("ALTER TABLE documents ADD COLUMN shared_at TIMESTAMP")
    order_cols = {row[1] for row in conn.execute("PRAGMA table_info(orders)").fetchall()}
    if 'woocommerce_order_id' not in order_cols:
        conn.execute("ALTER TABLE orders ADD COLUMN woocommerce_order_id TEXT")
    if 'payment_mode' not in order_cols:
        conn.execute("ALTER TABLE orders ADD COLUMN payment_mode TEXT")
    user_cols = {row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
    if 'department' not in user_cols:
        conn.execute("ALTER TABLE users ADD COLUMN department TEXT")
    task_cols = {row[1] for row in conn.execute("PRAGMA table_info(tasks)").fetchall()}
    if 'department' not in task_cols:
        conn.execute("ALTER TABLE tasks ADD COLUMN department TEXT")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT
        );
        CREATE TABLE IF NOT EXISTS permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT
        );
        CREATE TABLE IF NOT EXISTS role_permissions (
            role_id INTEGER NOT NULL,
            permission_id INTEGER NOT NULL,
            PRIMARY KEY (role_id, permission_id),
            FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
            FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
        );
    """)
    conn.commit()
    conn.close()
    ensure_rbac()


def ensure_rbac():
    """Insert missing roles and permission links. Never deletes existing rows."""
    roles = (
        ('SUPER_ADMIN', 'Full unrestricted system & technical administration access'),
        ('ADMIN', 'Manage clients, orders, staff, documents, and financial records'),
        ('MANAGER', 'Oversee team assignments, assigned clients, and order workflows'),
        ('STAFF', 'Access assigned clients and orders to process documentation'),
        ('CLIENT', 'Portal user accessing owned companies, orders, and documents'),
    )
    permissions = (
        ('clients.view', 'View client records'),
        ('clients.create', 'Create new client profiles'),
        ('clients.edit', 'Modify client profiles'),
        ('clients.delete', 'Remove client profiles'),
        ('orders.view', 'View orders'),
        ('orders.create', 'Create orders'),
        ('orders.edit', 'Update order statuses and progress'),
        ('orders.assign', 'Assign staff to orders'),
        ('documents.view', 'View documents'),
        ('documents.upload', 'Upload new documents'),
        ('documents.send', 'Send document notifications to client'),
        ('documents.delete', 'Delete documents'),
        ('invoices.view', 'View invoices'),
        ('invoices.create', 'Create invoices'),
        ('notifications.send', 'Send notifications'),
        ('staff.manage', 'Manage internal staff accounts'),
        ('settings.manage', 'Modify system & integration settings'),
        ('tasks.view', 'View staff tasks'),
        ('tasks.create', 'Create staff tasks'),
        ('tasks.edit', 'Edit staff tasks'),
        ('tasks.assign', 'Assign staff to tasks'),
        ('tasks.complete', 'Mark staff tasks complete'),
    )
    for name, desc in roles:
        execute_db("INSERT OR IGNORE INTO roles (name, description) VALUES (?, ?);", (name, desc))
    for name, desc in permissions:
        execute_db("INSERT OR IGNORE INTO permissions (name, description) VALUES (?, ?);", (name, desc))

    role_map = {row['name']: row['id'] for row in query_db("SELECT id, name FROM roles;")}
    perm_map = {row['name']: row['id'] for row in query_db("SELECT id, name FROM permissions;")}
    links = []
    for pname in perm_map:
        links.append(('SUPER_ADMIN', pname))
        links.append(('ADMIN', pname))
    for pname in (
        'clients.view', 'orders.view', 'orders.edit', 'documents.view',
        'documents.upload', 'documents.send', 'invoices.view',
    ):
        links.append(('MANAGER', pname))
        links.append(('STAFF', pname))
    for pname in ('tasks.view', 'tasks.create', 'tasks.edit', 'tasks.assign', 'tasks.complete'):
        links.append(('MANAGER', pname))
    for pname in ('tasks.view', 'tasks.edit', 'tasks.complete'):
        links.append(('STAFF', pname))
    for role_name, perm_name in links:
        role_id = role_map.get(role_name)
        perm_id = perm_map.get(perm_name)
        if role_id and perm_id:
            execute_db(
                "INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?);",
                (role_id, perm_id),
            )

def query_db(query, args=(), one=False):
    conn = get_db()
    cur = conn.cursor()
    cur.execute(query, args)
    rv = [dict(row) for row in cur.fetchall()]
    conn.close()
    return (rv[0] if rv else None) if one else rv

def execute_db(query, args=()):
    conn = get_db()
    cur = conn.cursor()
    cur.execute(query, args)
    conn.commit()
    last_id = cur.lastrowid
    conn.close()
    return last_id

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully.")
