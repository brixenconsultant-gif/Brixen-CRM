import sqlite3, os

def fix_b2b_labels(db_path='hypetex.db'):
    if not os.path.exists(db_path):
        return
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    # Reset all users to Normal Customer except Tanis and Free Unicorn
    c.execute("""
        UPDATE users 
        SET is_b2b = 0, client_type = 'NORMAL', b2b_id = NULL
        WHERE LOWER(COALESCE(full_name, '')) NOT LIKE '%tanis%' 
          AND LOWER(COALESCE(full_name, '')) NOT LIKE '%unicorn%'
          AND LOWER(COALESCE(email, '')) NOT LIKE '%tanis%'
          AND LOWER(COALESCE(email, '')) NOT LIKE '%unicorn%'
          AND LOWER(COALESCE(email, '')) NOT LIKE '%tanish%';
    """)

    # Set Tanis as B2B Customer B2B-000001
    c.execute("""
        UPDATE users 
        SET is_b2b = 1, client_type = 'B2B', b2b_id = 'B2B-000001'
        WHERE LOWER(COALESCE(full_name, '')) LIKE '%tanis%' 
           OR LOWER(COALESCE(email, '')) LIKE '%tanis%' 
           OR LOWER(COALESCE(email, '')) LIKE '%tanish%';
    """)

    # Set Free Unicorn as B2B Customer B2B-000002
    c.execute("""
        UPDATE users 
        SET is_b2b = 1, client_type = 'B2B', b2b_id = 'B2B-000002'
        WHERE LOWER(COALESCE(full_name, '')) LIKE '%unicorn%' 
           OR LOWER(COALESCE(email, '')) LIKE '%unicorn%';
    """)

    conn.commit()
    conn.close()
    print('✓ B2B Labels updated successfully: Only Tanis & Free Unicorn are B2B Account!')

if __name__ == '__main__':
    fix_b2b_labels()
