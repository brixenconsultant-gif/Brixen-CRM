/* ====================================================
   HYPETEX LIMITED - SAAS PORTAL FRONTEND LOGIC
   ==================================================== */

let currentUser = null;
let activeView = 'login';
let activeTicketId = null;
let adminChart = null;
let lastNotifications = [];
let notificationsOpen = false;
let accountMenuOpen = false;

const ALL_USER_ROLES = ['SUPER_ADMIN', 'ADMIN', 'MANAGER', 'STAFF', 'CLIENT'];
const ROLE_RANK = { CLIENT: 0, STAFF: 1, MANAGER: 2, ADMIN: 3, SUPER_ADMIN: 4 };
const STAFF_DEPARTMENTS = [
    'New Signups',
    'Orders',
    'Documents',
    'Support',
    'Compliance',
    'Accounts',
    'General'
];

function isAdminShellUser(user) {
    if (!user) return false;
    return ['SUPER_ADMIN', 'ADMIN', 'MANAGER', 'STAFF'].includes(user.role);
}

function canViewAdminDashboard() {
    return currentUser && ['SUPER_ADMIN', 'ADMIN', 'MANAGER'].includes(currentUser.role);
}

function canViewRevenue() {
    return currentUser && ['SUPER_ADMIN', 'ADMIN'].includes(currentUser.role);
}

function hasFullModuleAccess() {
    return currentUser && ['SUPER_ADMIN', 'ADMIN', 'MANAGER'].includes(currentUser.role);
}

const VIEW_ACCESS = {
    'admin-customers': ['New Signups'],
    'admin-orders': ['Orders', 'Support'],
    'admin-services': ['Orders'],
    'admin-documents': ['Documents', 'Compliance'],
    'admin-invoices': ['Accounts']
};

function hasModuleAccess(areas) {
    if (hasFullModuleAccess()) return true;
    if (!currentUser || currentUser.role !== 'STAFF') return false;
    const granted = staffDepartments(currentUser);
    return (areas || []).some((area) => granted.includes(area));
}

function canOpenView(viewName) {
    if (!viewName || viewName === 'login' || viewName === 'client-profile') return true;
    if (viewName === 'admin-dashboard') return canViewAdminDashboard();
    if (viewName === 'admin-team' || viewName === 'admin-logs' || viewName === 'admin-settings') {
        return canManageUsers();
    }
    if (viewName === 'admin-tasks') return isAdminShellUser(currentUser);
    const needed = VIEW_ACCESS[viewName];
    if (needed) return hasModuleAccess(needed);
    if (String(viewName).startsWith('client-')) {
        return currentUser && !isAdminShellUser(currentUser);
    }
    return isAdminShellUser(currentUser);
}

function defaultPortalView() {
    if (!isAdminShellUser(currentUser)) return 'client-dashboard';
    if (canViewAdminDashboard()) return 'admin-dashboard';
    const preferred = ['admin-orders', 'admin-customers', 'admin-documents', 'admin-invoices', 'admin-tasks', 'client-profile'];
    return preferred.find(canOpenView) || 'client-profile';
}

function applyPortalAccessNav() {
    document.querySelectorAll('#admin-sidebar .nav-item, #top-menu-list-admin .top-menu-item').forEach((el) => {
        const view = el.getAttribute('data-view');
        el.style.display = canOpenView(view) ? '' : 'none';
    });
    applyAdminRevenueCards();
}

let detachedRevenueCards = [];

function applyAdminRevenueCards() {
    if (canViewRevenue()) {
        detachedRevenueCards.forEach(({ parent, html, next }) => {
            if (!parent || parent.querySelector('[data-admin-revenue]')) return;
            const wrap = document.createElement('div');
            wrap.innerHTML = html.trim();
            const node = wrap.firstElementChild;
            if (!node) return;
            node.hidden = false;
            if (next && next.parentNode === parent) parent.insertBefore(node, next);
            else parent.appendChild(node);
        });
        detachedRevenueCards = [];
        document.querySelectorAll('[data-admin-revenue]').forEach((el) => {
            el.hidden = false;
        });
        return;
    }
    document.querySelectorAll('[data-admin-revenue]').forEach((el) => {
        detachedRevenueCards.push({
            parent: el.parentElement,
            html: el.outerHTML,
            next: el.nextElementSibling
        });
        el.remove();
    });
}

function creatableRolesFor(user) {
    if (!user) return [];
    const hasStaffManage = ['SUPER_ADMIN', 'ADMIN'].includes(user.role);
    const hasClientsCreate = ['SUPER_ADMIN', 'ADMIN'].includes(user.role);
    if (!hasStaffManage && !hasClientsCreate) return [];
    const actorRank = ROLE_RANK[user.role];
    if (actorRank == null) return [];
    return ALL_USER_ROLES.filter((role) => {
        if (role === 'CLIENT' && !hasClientsCreate) return false;
        if (role !== 'CLIENT' && !hasStaffManage) return false;
        if (user.role === 'SUPER_ADMIN') return true;
        return ROLE_RANK[role] < actorRank;
    });
}

function canManageServiceCatalog() {
    return currentUser && ['SUPER_ADMIN', 'ADMIN'].includes(currentUser.role);
}

function canManageUsers() {
    return creatableRolesFor(currentUser).length > 0;
}

function canManageStaff() {
    return canManageUsers();
}

function setAuthShellState(pending, authenticated) {
    const root = document.documentElement;
    const app = document.getElementById('app-container');
    if (pending) {
        root.classList.add('auth-pending');
        root.classList.remove('authenticated', 'auth-ready');
        if (app) app.setAttribute('hidden', '');
        return;
    }
    root.classList.remove('auth-pending');
    root.classList.add('auth-ready');
    if (authenticated) root.classList.add('authenticated');
    else root.classList.remove('authenticated');
    if (app) app.removeAttribute('hidden');
}

function setActiveViewPanel(viewName) {
    document.querySelectorAll('.view-panel').forEach((panel) => {
        panel.classList.remove('is-active');
        panel.style.display = 'none';
    });
    const targetPanel = document.getElementById(viewName ? `view-${viewName}` : '');
    if (targetPanel) {
        targetPanel.classList.add('is-active');
        targetPanel.style.display = viewName === 'login' ? 'block' : 'flex';
    }
}

function setOpenSidebar(which) {
    const clientSide = document.getElementById('client-sidebar');
    const adminSide = document.getElementById('admin-sidebar');
    if (clientSide) {
        const open = which === 'client';
        clientSide.classList.toggle('is-open', open);
        clientSide.style.display = open ? 'flex' : 'none';
        if (open) clientSide.removeAttribute('hidden');
        else clientSide.setAttribute('hidden', '');
    }
    if (adminSide) {
        const open = which === 'admin';
        adminSide.classList.toggle('is-open', open);
        adminSide.style.display = open ? 'flex' : 'none';
        if (open) adminSide.removeAttribute('hidden');
        else adminSide.setAttribute('hidden', '');
    }
    if (!which) closeMobileNav();
}

function isMobileNav() {
    return window.matchMedia('(max-width: 900px)').matches;
}

function syncMobileNavUi() {
    const open = document.body.classList.contains('mobile-nav-open');
    const btn = document.getElementById('mobile-nav-toggle');
    const backdrop = document.getElementById('mobile-nav-backdrop');
    if (btn) {
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    }
    if (backdrop) {
        if (open) backdrop.removeAttribute('hidden');
        else backdrop.setAttribute('hidden', '');
    }
    safeCreateIcons();
}

function toggleMobileNav() {
    if (!isMobileNav()) return;
    const opening = !document.body.classList.contains('mobile-nav-open');
    document.body.classList.toggle('mobile-nav-open', opening);
    document.querySelectorAll('.sidebar.is-open').forEach((side) => {
        side.classList.toggle('mobile-open', opening);
    });
    syncMobileNavUi();
}

function closeMobileNav() {
    document.body.classList.remove('mobile-nav-open');
    document.querySelectorAll('.sidebar').forEach((side) => side.classList.remove('mobile-open'));
    syncMobileNavUi();
}

function syncCreateUserButtons() {
    const show = canManageUsers();
    document.querySelectorAll('#btn-create-user, #btn-tasks-open-team, .btn-create-user').forEach((btn) => {
        btn.style.display = show ? 'inline-flex' : 'none';
    });
}

function safeCreateIcons() {
    try {
        if (window.lucide && typeof lucide.createIcons === 'function') lucide.createIcons();
    } catch (err) {
        console.warn('Icon render skipped', err);
    }
}

// Immediately lock shell state on script load
setAuthShellState(true, false);

// Initialize Application on Page Load
document.addEventListener('DOMContentLoaded', async () => {
    safeCreateIcons();
    try {
        await checkAuth();
    } catch (err) {
        console.error('Auth check error:', err);
        currentUser = null;
        showLoginView();
    }
    setupEventListeners();
    window.addEventListener('resize', () => {
        if (!isMobileNav()) closeMobileNav();
    });
});

window.addEventListener('pageshow', (event) => {
    if (!event.persisted) return;
    currentUser = null;
    setAuthShellState(true, false);
    checkAuth();
});

function setupEventListeners() {
    // Nav Click Listeners
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const view = item.getAttribute('data-view');
            if (view) switchView(view);
        });
    });
    document.addEventListener('click', (e) => {
        const wrap = document.getElementById('notification-bell-wrap');
        if (notificationsOpen && wrap && !wrap.contains(e.target)) {
            closeNotificationsDropdown();
        }
        const accountWrap = document.getElementById('header-account-wrap');
        if (accountMenuOpen && accountWrap && !accountWrap.contains(e.target)) {
            closeAccountMenu();
        }
        const orderAction = e.target.closest('[data-order-action]');
        if (orderAction) {
            const action = orderAction.getAttribute('data-order-action');
            if (action === 'status' || action === 'payment_mode') return;
            e.preventDefault();
            e.stopPropagation();
            const orderId = Number(orderAction.getAttribute('data-order-id'));
            if (!orderId) return;
            if (action === 'open') openStaffOrderWorkspace(orderId);
            if (action === 'progress') advanceOrderProgress(orderId, Number(orderAction.getAttribute('data-progress') || 0));
            if (action === 'delete') openDeleteOrderModal(orderId, orderAction.getAttribute('data-order-number'));
            return;
        }
        const orderRow = e.target.closest('#adm-orders-table-body tr[data-order-id]');
        if (orderRow && !e.target.closest('select, a, button, input, textarea')) {
            const orderId = Number(orderRow.getAttribute('data-order-id'));
            if (orderId) openStaffOrderWorkspace(orderId);
        }
    });
    const ordersBody = document.getElementById('adm-orders-table-body');
    if (ordersBody) {
        ordersBody.addEventListener('change', (e) => {
            const statusSel = e.target.closest('select[data-order-action="status"]');
            if (statusSel) {
                const orderId = Number(statusSel.getAttribute('data-order-id'));
                if (orderId) updateAdminOrderStatus(orderId, statusSel.value);
                return;
            }
            const modeSel = e.target.closest('select[data-order-action="payment_mode"]');
            if (modeSel) {
                const orderId = Number(modeSel.getAttribute('data-order-id'));
                if (orderId) updateAdminOrderPaymentMode(orderId, modeSel.value);
            }
        });
    }
}

// ----------------------------------------------------
// Authentication & Production Login Flow
// ----------------------------------------------------
async function checkAuth() {
    setAuthShellState(true, false);
    try {
        const res = await fetch('/api/auth/me', { credentials: 'same-origin' });
        const data = await res.json();
        if (data.status === 'success' && data.user) {
            currentUser = data.user;
            updateUserUI();
            switchView(defaultPortalView());
            setAuthShellState(false, true);
        } else {
            currentUser = null;
            showLoginView();
        }
    } catch (err) {
        console.error('Auth check error:', err);
        currentUser = null;
        showLoginView();
    }
}

function setHeaderAuthVisible(visible) {
    const searchBox = document.getElementById('header-search-box');
    const accountWrap = document.getElementById('header-account-wrap');
    const bellWrap = document.getElementById('notification-bell-wrap');
    if (searchBox) searchBox.style.display = visible ? '' : 'none';
    if (accountWrap) accountWrap.style.display = visible ? 'block' : 'none';
    if (bellWrap) bellWrap.style.display = visible ? 'block' : 'none';
    if (!visible) closeAccountMenu();
}

function clearLoggedInChrome() {
    const emptyIds = [
        'current-user-avatar', 'current-user-name', 'current-user-role',
        'admin-user-avatar', 'admin-user-name', 'admin-user-role',
        'header-user-avatar', 'header-user-name', 'header-user-role'
    ];
    emptyIds.forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.textContent = '';
    });
    const unread = document.getElementById('header-unread-count');
    if (unread) {
        unread.textContent = '0';
        unread.style.display = 'none';
    }
    const notesList = document.getElementById('notifications-list');
    if (notesList) notesList.innerHTML = '';
    lastNotifications = [];
}

function showLoginView() {
    currentUser = null;
    closeAccountMenu();
    closeNotificationsDropdown();
    if (typeof closeCrmClientModal === 'function') {
        closeCrmClientModal();
    }
    if (typeof closeCreateUserModal === 'function') {
        closeCreateUserModal();
    }

    setOpenSidebar(null);
    setHeaderAuthVisible(false);
    clearLoggedInChrome();
    syncCreateUserButtons();
    const topMenuBar = document.getElementById('top-horizontal-menu-bar');
    if (topMenuBar) topMenuBar.style.display = 'none';
    setActiveViewPanel('login');
    setTeamMessage('', '');

    const passInput = document.getElementById('login-password');
    if (passInput) passInput.value = '';
    setAuthShellState(false, false);
}

async function handleFormLogin(e) {
    if (e) e.preventDefault();
    const emailInput = document.getElementById('login-email');
    const passInput = document.getElementById('login-password');
    const errDiv = document.getElementById('login-error-msg');
    
    if (!emailInput || !passInput) return;
    const email = emailInput.value;
    const password = passInput.value;
    if (errDiv) errDiv.style.display = 'none';

    try {
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (data.status === 'success') {
            currentUser = data.user;
            updateUserUI();
            switchView(defaultPortalView());
            setAuthShellState(false, true);
        } else {
            if (errDiv) {
                errDiv.textContent = data.message || 'Login failed.';
                errDiv.style.display = 'block';
            }
        }
    } catch (err) {
        if (errDiv) {
            errDiv.textContent = 'Server communication error.';
            errDiv.style.display = 'block';
        }
    }
}

async function handleLogout() {
    currentUser = null;
    closeAccountMenu();
    closeNotificationsDropdown();
    showLoginView();
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
}

function closeAccountMenu() {
    accountMenuOpen = false;
    const menu = document.getElementById('account-dropdown');
    if (menu) menu.style.display = 'none';
}

async function toggleAccountMenu(event) {
    if (event) event.stopPropagation();
    if (!currentUser) return;
    closeNotificationsDropdown();
    const menu = document.getElementById('account-dropdown');
    if (!menu) return;
    if (accountMenuOpen) {
        closeAccountMenu();
        return;
    }
    await refreshAccountSwitcher();
    accountMenuOpen = true;
    menu.style.display = 'block';
}

function canImpersonateTarget(target) {
    if (!currentUser || !target || currentUser.impersonated) return false;
    if (!canManageUsers()) return false;
    if (!isAdminShellUser(target)) return false;
    if (currentUser.id != null && String(currentUser.id) === String(target.id)) return false;
    if (target.status && target.status !== 'Active') return false;
    if (currentUser.role === 'SUPER_ADMIN') return true;
    return (ROLE_RANK[target.role] || 99) < (ROLE_RANK[currentUser.role] || 0);
}

async function refreshAccountSwitcher() {
    const returnBtn = document.getElementById('account-menu-return');
    if (returnBtn) {
        returnBtn.style.display = currentUser && currentUser.impersonated ? 'flex' : 'none';
    }
    const wrap = document.getElementById('account-user-switcher');
    const list = document.getElementById('account-user-switch-list');
    if (!wrap || !list) return;
    if (!canManageUsers() || (currentUser && currentUser.impersonated)) {
        wrap.style.display = 'none';
        list.innerHTML = '';
        return;
    }
    wrap.style.display = 'block';
    list.innerHTML = '<p style="padding:8px 12px; font-size:0.75rem; color:#94a3b8;">Loading users…</p>';
    try {
        const staffRes = await fetch('/api/admin/staff?include_inactive=1', { credentials: 'same-origin' });
        const staffData = await staffRes.json();
        const merged = [];
        const seen = new Set();
        (staffData.staff || []).forEach((u) => {
            if (!u || u.id == null || seen.has(u.id)) return;
            seen.add(u.id);
            merged.push(u);
        });
        const switchable = merged.filter(canImpersonateTarget)
            .sort((a, b) => String(a.full_name || '').localeCompare(String(b.full_name || '')));
        if (!switchable.length) {
            list.innerHTML = '<p style="padding:8px 12px; font-size:0.75rem; color:#94a3b8;">No other users available.</p>';
            return;
        }
        list.innerHTML = switchable.map((u) => `
            <button type="button" class="account-user-option" onclick="switchToUser(${u.id}, event)">
                <span class="account-user-name">${escapeHtml(u.full_name)}</span>
                <span class="account-user-meta">${escapeHtml(u.role)} · ${escapeHtml(u.email)}</span>
            </button>
        `).join('');
    } catch (err) {
        list.innerHTML = '<p style="padding:8px 12px; font-size:0.75rem; color:#dc2626;">Unable to load users.</p>';
    }
}

async function switchToUser(userId, event) {
    if (event) event.stopPropagation();
    if (!canManageUsers()) return;
    try {
        const res = await fetch('/api/admin/impersonate', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({ user_id: userId })
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success' || !data.user) {
            throw new Error(data.message || 'Unable to switch user.');
        }
        currentUser = data.user;
        closeAccountMenu();
        updateUserUI();
        switchView(defaultPortalView());
        setAuthShellState(false, true);
    } catch (err) {
        alert(err.message || 'Unable to switch user.');
    }
}

async function stopImpersonation(event) {
    if (event) event.stopPropagation();
    try {
        const res = await fetch('/api/admin/impersonate/stop', {
            method: 'POST',
            credentials: 'same-origin'
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success' || !data.user) {
            throw new Error(data.message || 'Unable to return to original account.');
        }
        currentUser = data.user;
        closeAccountMenu();
        updateUserUI();
        switchView(defaultPortalView());
        setAuthShellState(false, true);
    } catch (err) {
        alert(err.message || 'Unable to return to original account.');
    }
}

function openAccountProfile(event) {
    if (event) event.stopPropagation();
    closeAccountMenu();
    if (!currentUser) return;
    switchView('client-profile');
}

function setProfileNotice(kind, message) {
    const err = document.getElementById('profile-error');
    const ok = document.getElementById('profile-success');
    if (err) {
        err.style.display = kind === 'error' && message ? 'block' : 'none';
        err.textContent = kind === 'error' ? (message || '') : '';
    }
    if (ok) {
        ok.style.display = kind === 'success' && message ? 'block' : 'none';
        ok.textContent = kind === 'success' ? (message || '') : '';
    }
}

function loadUserProfile() {
    if (!currentUser) return;
    setProfileNotice('', '');
    const email = document.getElementById('prof-email');
    const role = document.getElementById('prof-role');
    const name = document.getElementById('prof-fullname');
    const phone = document.getElementById('prof-phone');
    const country = document.getElementById('prof-country');
    const address = document.getElementById('prof-address');
    if (email) email.value = currentUser.email || '';
    if (role) role.value = currentUser.role || '';
    if (name) name.value = currentUser.full_name || '';
    if (phone) phone.value = currentUser.phone || '';
    if (country) country.value = currentUser.country || '';
    if (address) address.value = currentUser.address || '';
    ['prof-current-password', 'prof-new-password', 'prof-confirm-password'].forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    const pwBlock = document.getElementById('profile-password-block');
    if (pwBlock) pwBlock.style.display = currentUser.impersonated ? 'none' : 'block';
}

async function saveProfile(event) {
    event.preventDefault();
    if (!currentUser) return;
    setProfileNotice('', '');
    const currentPassword = document.getElementById('prof-current-password')?.value || '';
    const newPassword = document.getElementById('prof-new-password')?.value || '';
    const confirmPassword = document.getElementById('prof-confirm-password')?.value || '';
    if (newPassword || confirmPassword || currentPassword) {
        if (currentUser.impersonated) {
            setProfileNotice('error', 'Return to your own account to change the password.');
            return;
        }
        if (!currentPassword) {
            setProfileNotice('error', 'Enter your current password to change it.');
            return;
        }
        if (newPassword.length < 10) {
            setProfileNotice('error', 'New password must be at least 10 characters.');
            return;
        }
        if (newPassword !== confirmPassword) {
            setProfileNotice('error', 'New passwords do not match.');
            return;
        }
    }
    const payload = {
        full_name: document.getElementById('prof-fullname')?.value.trim() || '',
        phone: document.getElementById('prof-phone')?.value.trim() || '',
        country: document.getElementById('prof-country')?.value.trim() || '',
        address: document.getElementById('prof-address')?.value.trim() || ''
    };
    if (newPassword) {
        payload.current_password = currentPassword;
        payload.new_password = newPassword;
        payload.confirm_password = confirmPassword;
    }
    const btn = document.getElementById('profile-save-btn');
    if (btn) btn.disabled = true;
    try {
        const res = await fetch('/api/auth/profile', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to save profile.');
        }
        if (data.user) {
            currentUser = { ...currentUser, ...data.user };
            updateUserUI();
        }
        loadUserProfile();
        setProfileNotice('success', data.message || 'Profile updated.');
    } catch (err) {
        setProfileNotice('error', err.message || 'Unable to save profile.');
    } finally {
        if (btn) btn.disabled = false;
    }
}

function updateUserUI() {
    if (!currentUser) return;
    
    // Update Sidebar User Info
    const avatar = document.getElementById('current-user-avatar');
    const nameEl = document.getElementById('current-user-name');
    const roleEl = document.getElementById('current-user-role');
    const dashWelcome = document.getElementById('dash-welcome-text');
    
    if (nameEl) nameEl.textContent = currentUser.full_name;
    if (roleEl) roleEl.textContent = `${currentUser.role} • Active`;
    if (dashWelcome) dashWelcome.textContent = `Welcome back, ${currentUser.full_name}`;
    
    if (avatar) {
        const initials = currentUser.full_name.split(' ').map(n => n[0]).join('').substring(0,2);
        avatar.textContent = initials;
    }
    
    // Update Glass Header Account Info
    const headerAvatar = document.getElementById('header-user-avatar');
    const headerName = document.getElementById('header-user-name');
    const headerRole = document.getElementById('header-user-role');
    
    if (headerName) headerName.textContent = currentUser.full_name;
    if (headerRole) headerRole.textContent = isAdminShellUser(currentUser) ? 'Admin CMS View' : 'Client Account';
    if (headerAvatar) {
        const initials = currentUser.full_name.split(' ').map(n => n[0]).join('').substring(0,2);
        headerAvatar.textContent = initials;
    }

    setHeaderAuthVisible(true);

    const adminName = document.getElementById('admin-user-name');
    const adminRole = document.getElementById('admin-user-role');
    const adminAvatar = document.getElementById('admin-user-avatar');
    if (adminName) adminName.textContent = currentUser.full_name;
    if (adminRole) adminRole.textContent = currentUser.role;
    if (adminAvatar) {
        adminAvatar.textContent = currentUser.full_name.split(' ').map(n => n[0]).join('').substring(0,2);
    }
    
    if (isAdminShellUser(currentUser)) {
        setOpenSidebar('admin');
    } else {
        setOpenSidebar('client');
    }
    const profileItem = document.getElementById('account-menu-profile');
    if (profileItem) {
        profileItem.style.display = 'flex';
        profileItem.textContent = 'Profile & Password';
    }
    const returnBtn = document.getElementById('account-menu-return');
    if (returnBtn) {
        returnBtn.style.display = currentUser.impersonated ? 'flex' : 'none';
    }
    const switcher = document.getElementById('account-user-switcher');
    if (switcher && currentUser.impersonated) switcher.style.display = 'none';
    applyPortalAccessNav();
    syncCreateUserButtons();
    
    // Sync top horizontal menu bar
    const topMenuBar = document.getElementById('top-horizontal-menu-bar');
    const topClientList = document.getElementById('top-menu-list-client');
    const topAdminList = document.getElementById('top-menu-list-admin');
    if (topMenuBar) {
        topMenuBar.style.display = currentUser ? 'block' : 'none';
    }
    if (topClientList) {
        topClientList.style.display = (currentUser && !isAdminShellUser(currentUser)) ? 'flex' : 'none';
    }
    if (topAdminList) {
        topAdminList.style.display = (currentUser && isAdminShellUser(currentUser)) ? 'flex' : 'none';
    }

    // Refresh notifications count
    loadNotificationsCount();
}

// ----------------------------------------------------
// View Router & Page Switching
// ----------------------------------------------------
function switchView(viewName) {
    closeAccountMenu();
    closeMobileNav();
    if (currentUser && viewName !== 'login' && !canOpenView(viewName)) {
        viewName = defaultPortalView();
    }
    if (!currentUser && viewName !== 'login') {
        showLoginView();
        return;
    }
    activeView = viewName;
    setActiveViewPanel(viewName);
    
    // Deactivate nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Activate nav item
    const targetNavItem = document.querySelector(`.nav-item[data-view="${viewName}"]`);
    if (targetNavItem) {
        targetNavItem.classList.add('active');
    }

    // Sync top horizontal menu items
    document.querySelectorAll('.top-menu-item').forEach(item => {
        item.classList.toggle('active', item.getAttribute('data-view') === viewName);
    });
    
    // Execute view data loader
    switch(viewName) {
        case 'client-orders': loadClientOrders(); break;
        case 'client-dashboard': loadClientDashboard(); break;
        case 'client-companies': loadClientCompanies(); break;
        case 'client-addresses': loadClientAddresses(); break;
        case 'client-invoices': loadClientInvoices(); break;
        case 'client-payments': loadClientPayments(); break;
        case 'client-documents': loadClientDocuments(); break;
        case 'client-services': loadClientServices(); break;
        case 'client-support': loadClientTickets(); break;
        case 'client-messages': loadClientMessages(); break;
        case 'client-profile': loadUserProfile(); break;
        
        case 'admin-dashboard': loadAdminDashboard(); break;
        case 'admin-orders': loadAdminOrders(); break;
        case 'admin-tasks': loadAdminTasks(); break;
        case 'admin-team': loadAdminTeam(); break;
        case 'admin-customers': loadAdminCustomers(); break;
        case 'admin-companies': loadAdminCompanies(); break;
        case 'admin-services': loadAdminServices(); break;
        case 'admin-invoices': loadAdminInvoices(); break;
        case 'admin-documents': loadAdminDocuments(); break;
        case 'admin-logs': loadAdminLogs(); break;
        case 'admin-settings': loadAdminSettings(); break;
    }
    
    lucide.createIcons();
}

// ----------------------------------------------------
// CLIENT ORDERS VIEW (Matching Reference Screenshot)
// ----------------------------------------------------
let clientOrdersPage = 1;

function resetClientOrdersPage() {
    clientOrdersPage = 1;
}

function showClientOrdersError(message) {
    const box = document.getElementById('client-orders-error');
    if (!box) return;
    if (!message) {
        box.style.display = 'none';
        box.textContent = '';
        return;
    }
    box.textContent = message;
    box.style.display = 'block';
}

function renderClientOrdersSkeleton() {
    const container = document.getElementById('orders-cards-container');
    if (!container) return;
    container.innerHTML = [0, 1, 2].map(() => `
        <div class="history-order-card" aria-hidden="true" style="pointer-events:none; opacity:0.65;">
            <div class="history-order-top">
                <div class="history-order-id">
                    <div class="history-order-icon" style="background:#e2e8f0;"></div>
                    <div>
                        <div style="width:140px;height:16px;background:#e2e8f0;border-radius:4px;"></div>
                        <div style="width:88px;height:12px;background:#e2e8f0;border-radius:4px;margin-top:8px;"></div>
                    </div>
                </div>
                <div style="width:72px;height:16px;background:#e2e8f0;border-radius:4px;"></div>
            </div>
            <div style="height:18px;background:#e2e8f0;border-radius:6px;"></div>
            <div style="width:92px;height:22px;background:#e2e8f0;border-radius:20px;"></div>
            <div style="height:8px;background:#e2e8f0;border-radius:999px;"></div>
        </div>
    `).join('');
}

function orderHistoryVisual(order) {
    const raw = order.status || '';
    const status = raw.toLowerCase();
    const pct = Math.max(0, Math.min(100, Number(order.progress_percent) || 0));

    if (status === 'completed') {
        return {
            tone: 'is-complete',
            processLabel: 'Completed',
            processClass: 'completed',
            lifecycleLabel: 'Delivered',
            lifecycleClass: 'completed',
            icon: 'package-check',
            progress: 100
        };
    }
    if (status.includes('hold') || status === 'paused') {
        return {
            tone: 'is-hold',
            processLabel: raw || 'On Hold',
            processClass: 'on-hold',
            lifecycleLabel: 'On Hold',
            lifecycleClass: 'on-hold',
            icon: 'pause-circle',
            progress: pct
        };
    }
    if (status === 'cancelled') {
        return {
            tone: 'is-hold',
            processLabel: 'Cancelled',
            processClass: 'cancelled',
            lifecycleLabel: 'Cancelled',
            lifecycleClass: 'cancelled',
            icon: 'x-circle',
            progress: pct
        };
    }
    return {
        tone: 'is-active',
        processLabel: (raw === 'Pending' || raw === 'Pending Verification') ? raw : 'Processing',
        processClass: 'processing',
        lifecycleLabel: 'In Progress',
        lifecycleClass: 'in-progress',
        icon: 'package',
        progress: pct
    };
}

function renderClientOrdersPagination(pagination) {
    const box = document.getElementById('client-orders-pagination');
    if (!box) return;
    const totalPages = Number(pagination?.total_pages || 1);
    const page = Number(pagination?.page || 1);
    if (totalPages <= 1) {
        box.style.display = 'none';
        box.innerHTML = '';
        return;
    }
    box.style.display = 'flex';
    box.innerHTML = `
        <button type="button" class="btn-secondary" ${page <= 1 ? 'disabled' : ''} onclick="loadClientOrders(${page - 1})">Previous</button>
        <span style="font-size:0.8rem;font-weight:700;color:#64748b;">Page ${page} of ${totalPages}</span>
        <button type="button" class="btn-secondary" ${page >= totalPages ? 'disabled' : ''} onclick="loadClientOrders(${page + 1})">Next</button>
    `;
}

async function loadClientOrders(page) {
    if (page) clientOrdersPage = page;
    const search = document.getElementById('global-search-input')?.value || '';
    const status = document.getElementById('filter-order-status')?.value || '';
    const sort = document.getElementById('filter-order-sort')?.value || 'date_desc';

    showClientOrdersError('');
    renderClientOrdersSkeleton();

    try {
        const url = `/api/client/orders?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status)}&sort=${encodeURIComponent(sort)}&page=${clientOrdersPage}&limit=12`;
        const res = await fetch(url);
        const data = await res.json().catch(() => ({}));

        if (!res.ok || data.status !== 'success') {
            showClientOrdersError('Unable to load your orders. Please try again.');
            const container = document.getElementById('orders-cards-container');
            if (container) container.innerHTML = '';
            renderClientOrdersPagination(null);
            return;
        }

        if (data.stats) {
            const totalEl = document.getElementById('stat-total-orders');
            const completedEl = document.getElementById('stat-completed-orders');
            const progressEl = document.getElementById('stat-in-progress-orders');
            const spentEl = document.getElementById('stat-total-spent');
            if (totalEl) totalEl.textContent = data.stats.total_orders;
            if (completedEl) completedEl.textContent = data.stats.completed;
            if (progressEl) progressEl.textContent = data.stats.in_progress;
            if (spentEl) spentEl.textContent = data.stats.total_spent;
        }

        const filteredTotal = Number(data.pagination?.total ?? data.orders.length);
        const countEl = document.getElementById('orders-count-label');
        if (countEl) countEl.textContent = `${filteredTotal} ${filteredTotal === 1 ? 'Order' : 'Orders'}`;

        renderOrderCardsGrid(data.orders || []);
        renderClientOrdersPagination(data.pagination);
    } catch (err) {
        console.error('Error loading orders:', err);
        showClientOrdersError('Unable to load your orders. Please try again.');
        const container = document.getElementById('orders-cards-container');
        if (container) container.innerHTML = '';
        renderClientOrdersPagination(null);
    }
}

function renderOrderCardsGrid(orders) {
    const container = document.getElementById('orders-cards-container');
    if (!container) return;

    if (!orders.length) {
        container.innerHTML = `
            <div style="grid-column: 1 / -1; text-align:center; padding:48px; background:#fff; border-radius:16px; border:1px solid #e2e8f0;">
                <i data-lucide="inbox" style="width:48px; height:48px; color:#94a3b8;"></i>
                <h3 style="font-size:1.1rem; font-weight:700; margin-top:12px;">No orders found</h3>
                <p style="color:#64748b; font-size:0.85rem;">Try adjusting your filter or search terms.</p>
            </div>
        `;
        lucide.createIcons();
        return;
    }

    container.innerHTML = orders.map(order => {
        const visual = orderHistoryVisual(order);
        const price = parseFloat(order.total ?? order.price ?? 0).toFixed(2);
        return `
            <article class="history-order-card ${visual.tone}" role="button" tabindex="0" onclick="openOrderDetailsModal(${order.id})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openOrderDetailsModal(${order.id});}">
                <div class="history-order-top">
                    <div class="history-order-id">
                        <div class="history-order-icon"><i data-lucide="${visual.icon}"></i></div>
                        <div>
                            <div class="history-order-number">${escapeHtml(order.order_number)}</div>
                            <div class="history-order-date">${escapeHtml(formatDate(order.created_at))}</div>
                        </div>
                    </div>
                    <div class="history-order-aside">
                        <div class="history-order-price">£${price}</div>
                        <span class="status-badge ${visual.processClass}">${escapeHtml(visual.processLabel)}</span>
                    </div>
                </div>
                <div class="history-order-service">${escapeHtml(order.service_name || '')}</div>
                <span class="status-badge ${visual.lifecycleClass}">${escapeHtml(visual.lifecycleLabel)}</span>
                <div class="history-order-progress">
                    <div class="progress-track">
                        <div class="progress-bar" style="width:${visual.progress}%;"></div>
                    </div>
                    <span>${visual.progress}%</span>
                </div>
                <button type="button" class="history-order-details" onclick="event.stopPropagation(); openOrderDetailsModal(${order.id})">
                    <i data-lucide="chevron-down"></i> View details
                </button>
            </article>
        `;
    }).join('');

    lucide.createIcons();
}

// ----------------------------------------------------
// ORDER DETAILS & TIMELINE MODAL
// ----------------------------------------------------
async function openOrderDetailsModal(orderId) {
    try {
        const res = await fetch(`/api/client/orders/${orderId}`);
        const data = await res.json();
        
        if (data.status === 'success') {
            const order = data.order;
            const timeline = data.timeline || [];
            const invoice = data.invoice;
            const lines = data.line_items || [];
            
            // Header elements
            const numEl = document.getElementById('modal-order-number');
            if (numEl) numEl.textContent = `Order ${order.order_number}`;
            
            const badgeEl = document.getElementById('modal-order-status-badge');
            if (badgeEl) {
                badgeEl.textContent = order.status;
                badgeEl.className = `status-badge ${order.status.toLowerCase().replace(/\s+/g, '-')}`;
            }
            
            const dateEl = document.getElementById('modal-order-date');
            if (dateEl) dateEl.textContent = `Placed on ${formatDate(order.created_at)}`;
            
            const serviceEl = document.getElementById('modal-service-name');
            if (serviceEl) serviceEl.textContent = order.service_name;
            
            const payStatusEl = document.getElementById('modal-payment-status');
            if (payStatusEl) {
                const isPaid = order.status === 'Completed' || (invoice && invoice.status === 'Paid');
                payStatusEl.textContent = isPaid ? 'Paid' : (order.status === 'Cancelled' ? 'Cancelled' : 'Processing');
                payStatusEl.style.color = isPaid ? '#059669' : (order.status === 'Cancelled' ? '#dc2626' : '#d97706');
            }
            
            const totalEl = document.getElementById('modal-order-total');
            const formattedTotal = `£${parseFloat(order.total || order.price).toFixed(2)}`;
            if (totalEl) totalEl.textContent = formattedTotal;
            const currencyNote = document.getElementById('modal-order-currency');
            if (currencyNote) currencyNote.textContent = 'GBP';

            const setText = (id, value) => {
                const el = document.getElementById(id);
                if (el) el.textContent = value;
            };
            setText('modal-summary-number', order.order_number || '—');
            setText('modal-summary-date', formatDate(order.created_at) || '—');
            setText('modal-summary-status', order.status || '—');
            setText('modal-summary-progress', `${order.progress_percent || 0}%`);
            setText('modal-summary-payment', document.getElementById('modal-payment-status')?.textContent || '—');
            setText('modal-summary-total', formattedTotal);
            
            // Company & Client Box
            const compNameEl = document.getElementById('modal-company-name');
            if (compNameEl) compNameEl.textContent = order.company_name || 'Individual Client Order';
            
            const compMetaEl = document.getElementById('modal-company-meta');
            if (compMetaEl) {
                const regStr = order.company_number ? `Reg #${order.company_number} · ` : '';
                const addrStr = order.company_address || order.client_address || 'UK Address File';
                compMetaEl.textContent = `${regStr}${addrStr}`;
            }
            
            const clientNameEl = document.getElementById('modal-client-name');
            if (clientNameEl) clientNameEl.textContent = order.client_name || currentUser?.full_name || 'Client Account';
            
            const clientEmailEl = document.getElementById('modal-client-email');
            if (clientEmailEl) clientEmailEl.textContent = order.client_email || currentUser?.email || '—';
            const clientPhoneEl = document.getElementById('modal-client-phone');
            if (clientPhoneEl) clientPhoneEl.textContent = order.client_phone || '—';
            
            // Line Items
            const linesBox = document.getElementById('modal-order-line-items');
            if (linesBox) {
                const itemVisual = orderHistoryVisual(order);
                if (lines.length > 0) {
                    linesBox.innerHTML = lines.map(item => {
                        const cat = item.category_name ? `<span class="status-badge pending" style="font-size:0.7rem; padding:2px 6px; margin-right:6px;">${escapeHtml(item.category_name)}</span>` : '';
                        const qty = item.quantity || 1;
                        const lineTotal = parseFloat(item.line_total || item.price || 0).toFixed(2);
                        return `
                            <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; padding:10px 0; border-bottom:1px solid #f1f5f9;">
                                <div>
                                    ${cat}<strong style="color:#0f172a;">${escapeHtml(item.product_name)}</strong>
                                    <div style="font-size:0.78rem; color:#64748b; margin-top:4px;">Quantity: ${qty} · ${escapeHtml(itemVisual.lifecycleLabel)} · ${itemVisual.progress}%</div>
                                </div>
                                <div style="text-align:right;">
                                    <div style="font-weight:700; color:#0f172a;">£${lineTotal}</div>
                                    <span class="status-badge ${itemVisual.processClass}" style="margin-top:6px;">${escapeHtml(itemVisual.processLabel)}</span>
                                </div>
                            </div>
                        `;
                    }).join('');
                } else {
                    linesBox.innerHTML = `
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; padding:8px 0;">
                            <div>
                                <strong style="color:#0f172a;">${escapeHtml(order.service_name)}</strong>
                                <div style="font-size:0.78rem; color:#64748b; margin-top:4px;">Quantity: 1 · ${escapeHtml(itemVisual.lifecycleLabel)} · ${itemVisual.progress}%</div>
                            </div>
                            <div style="text-align:right;">
                                <div style="font-weight:700; color:#0f172a;">£${parseFloat(order.total || order.price).toFixed(2)}</div>
                                <span class="status-badge ${itemVisual.processClass}" style="margin-top:6px;">${escapeHtml(itemVisual.processLabel)}</span>
                            </div>
                        </div>
                    `;
                }
            }
            
            // Progress Bar & Text
            const progTextEl = document.getElementById('modal-order-progress-text');
            if (progTextEl) progTextEl.textContent = `${order.progress_percent || 0}% Complete`;
            
            const progBarEl = document.getElementById('modal-order-progress-bar');
            if (progBarEl) {
                progBarEl.style.width = `${order.progress_percent || 0}%`;
                progBarEl.classList.toggle('completed', order.progress_percent === 100);
            }
            
            // Render Timeline
            const timelineBox = document.getElementById('modal-order-timeline');
            if (timelineBox) {
                timelineBox.innerHTML = timeline.map(step => {
                    const stepClass = step.status.toLowerCase();
                    const icon = step.status === 'Completed' ? '✓' : (step.status === 'Current' ? '•' : '');
                    return `
                        <div class="timeline-step ${stepClass}">
                            <div class="timeline-dot">${icon}</div>
                            <div class="timeline-content">
                                <h5>${escapeHtml(step.title)}</h5>
                                <p>${escapeHtml(step.status)} • ${step.step_date ? formatDate(step.step_date) : 'Pending'}</p>
                            </div>
                        </div>
                    `;
                }).join('');
            }
            
            const docsBox = document.getElementById('modal-order-documents');
            if (docsBox) {
                const docs = data.documents || [];
                docsBox.innerHTML = docs.length ? docs.map((doc) => `
                    <div style="display:flex; justify-content:space-between; gap:8px; align-items:center; padding:8px 0; border-bottom:1px solid #f1f5f9;">
                        <div>
                            <strong>${escapeHtml(doc.name)}</strong>
                            <div style="font-size:0.75rem; color:#64748b;">${escapeHtml(doc.category || doc.file_type || 'Document')} · ${escapeHtml(formatDate(doc.created_at))} · ${escapeHtml(doc.status || '')}</div>
                        </div>
                        <a href="/api/documents/${doc.id}/download" class="btn-secondary" style="padding:4px 10px; font-size:0.75rem; text-decoration:none;" onclick="event.stopPropagation();">Download</a>
                    </div>
                `).join('') : '<p style="color:#64748b; margin:0;">No documents are available for this order yet.</p>';
            }

            const supportBox = document.getElementById('modal-order-support');
            if (supportBox) {
                const tickets = data.tickets || [];
                if (tickets.length) {
                    supportBox.innerHTML = tickets.map((t) => `
                        <div style="display:flex; justify-content:space-between; gap:8px; align-items:center; padding:8px 0; border-bottom:1px solid #f1f5f9;">
                            <div>
                                <strong>${escapeHtml(t.ticket_number)}</strong>
                                <div style="font-size:0.75rem; color:#64748b;">${escapeHtml(t.subject || '')} · ${escapeHtml(t.status || '')}</div>
                            </div>
                            <button type="button" class="btn-secondary" style="padding:4px 10px; font-size:0.75rem;" onclick="event.stopPropagation(); closeOrderModal(); switchView('client-support');">Open Support</button>
                        </div>
                    `).join('');
                } else {
                    supportBox.innerHTML = `
                        <div style="display:flex; justify-content:space-between; gap:8px; align-items:center;">
                            <p style="color:#64748b; margin:0;">No support tickets on this order.</p>
                            <button type="button" class="btn-secondary" style="padding:4px 10px; font-size:0.75rem;" onclick="event.stopPropagation(); closeOrderModal(); switchView('client-support');">Order Support</button>
                        </div>
                    `;
                }
            }

            const modal = document.getElementById('order-details-modal');
            if (modal) modal.classList.add('active');
            lucide.createIcons();
        } else {
            alert(data.message || 'Unable to open this order.');
        }
    } catch (err) {
        console.error('Error fetching order details:', err);
        alert('Unable to load order details. Please try again.');
    }
}

function closeOrderModal() {
    const modal = document.getElementById('order-details-modal');
    if (modal) modal.classList.remove('active');
}

function onOrderModalBackdrop(event) {
    if (event.target && event.target.id === 'order-details-modal') {
        closeOrderModal();
    }
}

document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    const deleteModal = document.getElementById('modal-delete-order');
    if (deleteModal && deleteModal.classList.contains('active')) {
        closeDeleteOrderModal();
        return;
    }
    const orderModal = document.getElementById('order-details-modal');
    if (orderModal && orderModal.classList.contains('active')) {
        closeOrderModal();
    }
});

// ----------------------------------------------------
// CLIENT DASHBOARD (Brixen Consultants Layout)
// ----------------------------------------------------
async function loadClientDashboard() {
    const grid = document.getElementById('dash-active-orders-grid');
    const companiesGrid = document.getElementById('dash-companies-grid');
    const errorBox = document.getElementById('dash-error');
    if (errorBox) {
        errorBox.style.display = 'none';
        errorBox.textContent = '';
    }
    if (grid) {
        grid.innerHTML = `
            <div class="order-card skeleton-card" aria-label="Loading order" style="opacity: 0.6;">
                <div class="order-card-header"><div style="width:100px; height:18px; background:#e2e8f0; border-radius:4px;"></div></div>
                <div style="height:24px; background:#e2e8f0; border-radius:4px; margin:12px 0;"></div>
                <div style="height:8px; background:#e2e8f0; border-radius:4px;"></div>
            </div>
            <div class="order-card skeleton-card" aria-label="Loading order" style="opacity: 0.6;">
                <div class="order-card-header"><div style="width:100px; height:18px; background:#e2e8f0; border-radius:4px;"></div></div>
                <div style="height:24px; background:#e2e8f0; border-radius:4px; margin:12px 0;"></div>
                <div style="height:8px; background:#e2e8f0; border-radius:4px;"></div>
            </div>
        `;
    }
    if (companiesGrid) {
        companiesGrid.innerHTML = `
            <div class="company-card skeleton-card" aria-label="Loading companies" style="opacity:0.6; min-height:88px;"></div>
            <div class="company-card skeleton-card" aria-label="Loading companies" style="opacity:0.6; min-height:88px;"></div>
        `;
    }

    try {
        const res = await fetch('/api/client/dashboard');
        if (!res.ok) throw new Error('Unable to load dashboard data. Please try again.');
        const data = await res.json();
        
        if (data.status === 'success') {
            const heroDate = document.getElementById('hero-current-date');
            const heroName = document.getElementById('hero-user-name');
            const heroComps = document.getElementById('hero-companies-count');
            const displayName = (data.user_name || currentUser?.full_name || currentUser?.email || 'there').trim();
            const todayLabel = new Date().toLocaleDateString('en-GB', {
                weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
            });
            
            if (heroDate) heroDate.textContent = todayLabel;
            if (heroName) heroName.textContent = displayName;
            if (heroComps) heroComps.textContent = `${data.total_companies ?? 0}`;
            const companiesPill = document.getElementById('dash-companies-count-pill');
            const companyCount = Number(data.total_companies ?? 0);
            if (companiesPill) companiesPill.textContent = `${companyCount} ${companyCount === 1 ? 'Company' : 'Companies'}`;
            
            document.getElementById('dash-card-portfolio-count').textContent = data.total_companies ?? 0;
            document.getElementById('dash-uk-count').textContent = `${data.uk_companies ?? 0} UK`;
            const intlEl = document.getElementById('dash-intl-count');
            if (intlEl) intlEl.textContent = `${data.intl_companies ?? 0} International`;
            
            document.getElementById('dash-card-overdue-count').textContent = data.overdue_deadlines ?? 0;
            const overdueBadge = document.getElementById('dash-overdue-badge');
            if (overdueBadge) {
                if (!data.overdue_deadlines) {
                    overdueBadge.className = 'health-badge success';
                    overdueBadge.innerHTML = `<i data-lucide="check-circle-2"></i> All on track`;
                } else {
                    overdueBadge.className = 'health-badge warning';
                    overdueBadge.innerHTML = `<i data-lucide="alert-triangle"></i> ${data.overdue_deadlines} Overdue`;
                }
            }
            
            document.getElementById('dash-card-upcoming-count').textContent = data.upcoming_deadlines ?? 0;
            const upcomingBadge = document.getElementById('dash-upcoming-badge');
            if (upcomingBadge) {
                if (!data.upcoming_deadlines) {
                    upcomingBadge.className = 'health-badge info';
                    upcomingBadge.innerHTML = `<i data-lucide="calendar"></i> No deadlines soon`;
                } else {
                    upcomingBadge.className = 'health-badge info';
                    upcomingBadge.innerHTML = `<i data-lucide="clock"></i> ${data.upcoming_deadlines} Due Soon`;
                }
            }
            
            document.getElementById('dash-active-orders-num').textContent = data.active_orders_count ?? 0;
            renderActiveOrdersGrid(data.active_orders || []);
            renderDashboardCompanies(data.companies || []);
            lucide.createIcons();
        } else {
            throw new Error('Unable to load dashboard data. Please try again.');
        }
    } catch (err) {
        console.error('Error loading dashboard:', err);
        if (errorBox) {
            errorBox.style.display = 'block';
            errorBox.textContent = 'Unable to load dashboard data. Please try again.';
        }
        if (grid) {
            grid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align:center; padding:40px; background:#fff; border-radius:16px; border:1px solid #fee2e2;" role="alert">
                    <i data-lucide="alert-circle" style="width:40px; height:40px; color:#ef4444;"></i>
                    <h3 style="font-size:1.05rem; font-weight:700; color:#0f172a; margin-top:10px;">Unable to load dashboard data. Please try again.</h3>
                    <button class="btn-primary" style="margin-top:16px;" onclick="loadClientDashboard()">
                        <i data-lucide="refresh-cw"></i> Retry
                    </button>
                </div>
            `;
        }
        if (companiesGrid) {
            companiesGrid.innerHTML = `<div style="grid-column:1/-1; color:#64748b; padding:24px; text-align:center;">Unable to load companies.</div>`;
        }
        lucide.createIcons();
    }
}

function renderActiveOrdersGrid(orders) {
    const grid = document.getElementById('dash-active-orders-grid');
    if (!grid) return;
    
    if (orders.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align:center; padding:48px; background:#fff; border-radius:16px; border:1px solid #e2e8f0;" role="status">
                <i data-lucide="check-circle-2" style="width:48px; height:48px; color:#10b981;"></i>
                <h3 style="font-size:1.1rem; font-weight:700; color:#0f172a; margin-top:12px;">No active orders</h3>
                <p style="color:#64748b; font-size:0.85rem; margin-top:4px;">Completed orders can be viewed in your order history.</p>
                <button class="btn-secondary" style="margin-top:16px;" onclick="switchView('client-orders')">View Order History</button>
            </div>
        `;
        lucide.createIcons();
        return;
    }
    
    grid.innerHTML = orders.map(order => {
        const isCompleted = order.status === 'Completed';
        const statusClass = String(order.status || '').toLowerCase().replace(/\s+/g, '-');
        const serviceCount = Number(order.total_items_count || (order.service_items || []).length || 1);
        const servicesLabel = `${serviceCount} service${serviceCount === 1 ? '' : 's'}`;
        const stages = Array.isArray(order.stages) ? order.stages : [];
        const items = Array.isArray(order.service_items) ? order.service_items : [];
        
        const stagesHtml = stages.map((stg, i) => {
            const iconSymbol = stg.status === 'completed' ? '✓' : (i + 1).toString();
            return `
                <div class="timeline-stage-item ${escapeHtml(stg.status || 'pending')}">
                    <div class="stage-icon-circle">${iconSymbol}</div>
                    <div class="stage-label-text">${escapeHtml(stg.name || '')}</div>
                </div>
            `;
        }).join('');
        
        const servicesRowsHtml = items.map(s => {
            const badgeClass = s.status === 'Done' || s.status === 'Completed' ? 'completed' : (s.status === 'In Progress' || s.status === 'Processing' ? 'processing' : 'pending');
            const label = s.category ? `${s.category} · ${s.name}` : s.name;
            return `
                <tr>
                    <td>${escapeHtml(label || '')}</td>
                    <td style="text-align:right;"><span class="status-badge ${badgeClass}">${escapeHtml(s.status || '')}</span></td>
                </tr>
            `;
        }).join('');
        
        return `
            <div class="order-card order-card-clickable tracker-order-card" role="button" tabindex="0" onclick="openOrderDetailsModal(${order.id})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openOrderDetailsModal(${order.id});}">
                <div class="order-card-header">
                    <div>
                        <div class="order-number">${escapeHtml(order.order_number)}</div>
                        <div class="order-date">${servicesLabel}</div>
                    </div>
                    <span class="status-badge ${statusClass}">${escapeHtml(order.status || '')}</span>
                </div>

                <div class="order-progress-section">
                    <div class="progress-labels">
                        <span>${escapeHtml(order.service_name || '')}</span>
                        <span>${Number(order.progress_percent || 0)}%</span>
                    </div>
                    <div class="progress-track">
                        <div class="progress-bar ${isCompleted ? 'completed' : ''}" style="width: ${Number(order.progress_percent || 0)}%;"></div>
                    </div>
                </div>

                <div class="card-horizontal-timeline">
                    ${stagesHtml}
                </div>

                <table class="card-services-table">
                    <thead>
                        <tr>
                            <th>SERVICE</th>
                            <th style="text-align:right;">STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${servicesRowsHtml}
                    </tbody>
                </table>
            </div>
        `;
    }).join('');
}

function companyCountryLabel(company) {
    if (company && company.country) return company.country;
    const office = String(company && company.reg_office ? company.reg_office : '');
    if (/united kingdom|london|uk\b/i.test(office)) return 'United Kingdom';
    if (office) return office.split(',').pop().trim() || '—';
    return '—';
}

function isUkCompany(company) {
    return /united kingdom|\buk\b/i.test(companyCountryLabel(company));
}

function companyStatusLabel(company) {
    return company && (company.status || company.account_status || 'Active');
}

function isCompanyActive(company) {
    const status = String(companyStatusLabel(company) || '');
    return /active|good standing/i.test(status);
}

function formatUkNumericDate(dateStr) {
    const raw = String(dateStr || '').trim();
    const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) return `${iso[3]}/${iso[2]}/${iso[1]}`;
    return raw || '—';
}

function portfolioDeadlineText(company) {
    const items = Array.isArray(company && company.deadlines) ? company.deadlines : [];
    if (!items.length) return 'No upcoming deadlines';
    return items.map((item) => `${item.label}: ${formatUkNumericDate(item.date)}`).join(' · ');
}

function countryBadgeHtml(company) {
    if (isUkCompany(company)) {
        return `<span class="portfolio-badge-uk"><span aria-hidden="true">🇬🇧</span> UK</span>`;
    }
    const label = companyCountryLabel(company);
    return `<span class="portfolio-badge-intl">${escapeHtml(label === '—' ? 'INTL' : label)}</span>`;
}

let clientCompaniesCache = [];
let portfolioDetailCache = null;

function portfolioSkeletonHtml() {
    return Array.from({ length: 3 }).map(() => `
        <div class="portfolio-card portfolio-skeleton" aria-hidden="true">
            <div class="portfolio-card-head">
                <div class="portfolio-skeleton-icon"></div>
                <div class="portfolio-card-titles" style="display:flex; flex-direction:column; gap:8px;">
                    <div class="portfolio-skeleton-line" style="width:70%;"></div>
                    <div class="portfolio-skeleton-line" style="width:40%;"></div>
                </div>
            </div>
            <div class="portfolio-card-body">
                <div class="portfolio-skeleton-line" style="width:55%;"></div>
            </div>
        </div>
    `).join('');
}

function renderPortfolioCompanies(companies, targetGridId = 'portfolio-companies-grid', targetCountId = 'portfolio-company-count') {
    const grid = document.getElementById(targetGridId);
    const countPill = document.getElementById(targetCountId);
    const list = Array.isArray(companies) ? companies : [];
    if (countPill) countPill.textContent = `${list.length} UK`;
    if (!grid) return;
    if (!list.length) {
        grid.innerHTML = `
            <div class="portfolio-empty" role="status">
                <i data-lucide="building-2" style="width:40px; height:40px; color:#c4b5fd;"></i>
                <h3>No companies in your Business Portfolio yet.</h3>
            </div>
        `;
        if (window.lucide) lucide.createIcons();
        return;
    }
    grid.innerHTML = list.map((company) => {
        const active = isCompanyActive(company);
        const companyId = Number(company.id);
        return `
            <article class="portfolio-card" role="button" tabindex="0" onclick="openCompanyPortfolioDetail(${companyId})" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openCompanyPortfolioDetail(${companyId});}">
                <div class="portfolio-card-head">
                    <div class="portfolio-card-icon" aria-hidden="true"><i data-lucide="building-2"></i></div>
                    <div class="portfolio-card-titles">
                        <h3>${escapeHtml(company.name || 'Company')}</h3>
                        <p>${escapeHtml(company.company_number || '—')}</p>
                    </div>
                    <div class="portfolio-card-badges">
                        ${countryBadgeHtml(company)}
                        <span class="portfolio-badge-status${active ? '' : ' is-pending'}">${escapeHtml(companyStatusLabel(company))}</span>
                    </div>
                </div>
                <div class="portfolio-card-body">${escapeHtml(portfolioDeadlineText(company))}</div>
                <div class="portfolio-card-foot">
                    <span onclick="event.stopPropagation(); openCompanyPortfolioDetail(${companyId})">View details</span>
                    <i data-lucide="arrow-right"></i>
                </div>
            </article>
        `;
    }).join('');
    if (window.lucide) lucide.createIcons();
}

function switchPortfolioDetailTab(tabName) {
    document.querySelectorAll('#modal-company-portfolio .portfolio-tab').forEach((btn) => {
        btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
    });
    document.querySelectorAll('#modal-company-portfolio .portfolio-tab-panel').forEach((panel) => {
        panel.hidden = panel.getAttribute('data-panel') !== tabName;
    });
}

function setPortfolioText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value || '—';
}

function fillCompanyPortfolioModal(payload) {
    portfolioDetailCache = payload || {};
    const company = payload.company || {};
    const office = payload.registered_office || {};
    const uk = isUkCompany(company);
    setPortfolioText('portfolio-detail-name', company.name || 'Company');
    setPortfolioText('portfolio-detail-number', company.company_number || '');
    setPortfolioText('portfolio-detail-name-field', company.name || '—');
    setPortfolioText('portfolio-detail-number-field', company.company_number || '—');
    setPortfolioText('portfolio-detail-status', companyStatusLabel(company));
    setPortfolioText('portfolio-detail-country', companyCountryLabel(company));
    setPortfolioText('portfolio-detail-inc', formatUkNumericDate(company.inc_date));
    setPortfolioText('portfolio-detail-director', company.director || '—');
    setPortfolioText('portfolio-detail-office', office.address || company.reg_office || '—');
    setPortfolioText('portfolio-detail-postcode', office.postcode || '—');
    const countryBadge = document.getElementById('portfolio-detail-country-badge');
    if (countryBadge) {
        countryBadge.className = uk ? 'portfolio-badge-uk' : 'portfolio-badge-intl';
        countryBadge.textContent = uk ? '🇬🇧 UK' : (companyCountryLabel(company) || 'INTL');
    }
    const statusBadge = document.getElementById('portfolio-detail-status-badge');
    if (statusBadge) {
        statusBadge.className = `portfolio-badge-status${isCompanyActive(company) ? '' : ' is-pending'}`;
        statusBadge.textContent = companyStatusLabel(company);
    }
    const activity = document.getElementById('portfolio-detail-activity');
    if (activity) activity.textContent = 'No SIC or business activity details on file.';

    const deadlines = Array.isArray(company.deadlines) ? company.deadlines : [];
    const complianceEl = document.getElementById('portfolio-detail-compliance');
    if (complianceEl) {
        const rows = [];
        if (company.account_status) {
            rows.push(`<div class="portfolio-related-row"><div><span>Standing</span><strong>${escapeHtml(company.account_status)}</strong></div></div>`);
        }
        deadlines.forEach((item) => {
            rows.push(`<div class="portfolio-related-row"><div><span>${escapeHtml(item.label)}</span><strong>${escapeHtml(formatUkNumericDate(item.date))}</strong></div></div>`);
        });
        complianceEl.innerHTML = rows.length
            ? `<div class="portfolio-related-list">${rows.join('')}</div>`
            : `<p class="portfolio-related-empty">No upcoming deadlines</p>`;
    }

    const orders = Array.isArray(payload.orders) ? payload.orders : [];
    const ordersEl = document.getElementById('portfolio-detail-orders');
    if (ordersEl) {
        if (!orders.length) {
            ordersEl.innerHTML = `<p class="portfolio-related-empty">No orders linked to this company.</p>`;
        } else {
            ordersEl.innerHTML = `<div class="portfolio-related-list">${orders.map((order) => `
                <div class="portfolio-related-row">
                    <div>
                        <strong>${escapeHtml(order.order_number || 'Order')}</strong>
                        <span>${escapeHtml(order.service_name || '')} · ${escapeHtml(order.status || '')}</span>
                    </div>
                    <button type="button" class="btn-secondary" style="padding:4px 10px; font-size:0.75rem;" onclick="openPortfolioCompanyOrder(${Number(order.id)})">View</button>
                </div>
            `).join('')}</div>`;
        }
    }

    const documents = Array.isArray(payload.documents) ? payload.documents : [];
    const docsEl = document.getElementById('portfolio-detail-documents');
    if (docsEl) {
        if (!documents.length) {
            docsEl.innerHTML = `<p class="portfolio-related-empty">No documents available for this company.</p>`;
        } else {
            docsEl.innerHTML = `<div class="portfolio-related-list">${documents.map((doc) => `
                <div class="portfolio-related-row">
                    <div>
                        <strong>${escapeHtml(doc.name || 'Document')}</strong>
                        <span>${escapeHtml(doc.category || doc.file_type || '')}</span>
                    </div>
                    <a href="/api/documents/${Number(doc.id)}/download" class="btn-secondary" style="padding:4px 10px; font-size:0.75rem; text-decoration:none;">Download</a>
                </div>
            `).join('')}</div>`;
        }
    }

    const tickets = Array.isArray(payload.tickets) ? payload.tickets : [];
    const supportEl = document.getElementById('portfolio-detail-support');
    if (supportEl) {
        const ticketRows = tickets.length ? tickets.map((ticket) => `
            <div class="portfolio-related-row">
                <div>
                    <strong>${escapeHtml(ticket.ticket_number || 'Ticket')}</strong>
                    <span>${escapeHtml(ticket.subject || '')} · ${escapeHtml(ticket.status || '')}</span>
                </div>
                <button type="button" class="btn-secondary" style="padding:4px 10px; font-size:0.75rem;" onclick="openPortfolioSupportTicket(${Number(ticket.id)})">Open</button>
            </div>
        `).join('') : `<p class="portfolio-related-empty">No support tickets for this company.</p>`;
        supportEl.innerHTML = `
            <div class="portfolio-related-list">${ticketRows}</div>
            <div style="margin-top:12px;">
                <button type="button" class="btn-primary" onclick="openPortfolioCompanySupport()">Contact Support</button>
            </div>
        `;
    }
}

async function openCompanyPortfolioDetail(companyId) {
    const requestedId = Number(companyId);
    if (!requestedId) return;
    const modal = document.getElementById('modal-company-portfolio');
    const cached = clientCompaniesCache.find((item) => Number(item.id) === requestedId);
    if (cached) fillCompanyPortfolioModal({ company: cached, registered_office: { address: cached.reg_office, postcode: '' }, orders: [], documents: [], tickets: [] });
    if (modal) modal.classList.add('active');
    switchPortfolioDetailTab('overview');
    try {
        const res = await fetch(`/api/client/companies/${requestedId}`, { credentials: 'same-origin' });
        const data = await res.json();
        if (!res.ok || data.status !== 'success' || !data.company) {
            throw new Error('not-found');
        }
        fillCompanyPortfolioModal(data);
        if (window.lucide) lucide.createIcons();
    } catch (err) {
        if (modal) modal.classList.remove('active');
    }
}

function closeCompanyPortfolioDetail() {
    const modal = document.getElementById('modal-company-portfolio');
    if (modal) modal.classList.remove('active');
}

function openPortfolioCompanyOrder(orderId) {
    closeCompanyPortfolioDetail();
    openOrderDetailsModal(orderId);
}

function openPortfolioSupportTicket(ticketId) {
    const tickets = (portfolioDetailCache && portfolioDetailCache.tickets) || [];
    const ticket = tickets.find((item) => Number(item.id) === Number(ticketId)) || {};
    closeCompanyPortfolioDetail();
    openChatModal(ticketId, ticket.subject || 'Support', ticket.ticket_number || '');
}

function openPortfolioCompanySupport() {
    closeCompanyPortfolioDetail();
    switchView('client-support');
}

function renderDashboardCompanies(companies) {
    const grid = document.getElementById('dash-companies-grid');
    if (!grid) return;
    const list = Array.isArray(companies) ? companies : [];
    if (!list.length) {
        grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align:center; padding:36px; background:#fff; border-radius:16px; border:1px solid #e2e8f0;" role="status">
                <i data-lucide="building-2" style="width:40px; height:40px; color:#94a3b8;"></i>
                <h3 style="font-size:1.05rem; font-weight:700; color:#0f172a; margin-top:10px;">No companies found</h3>
                <p style="color:#64748b; font-size:0.85rem; margin-top:4px;">Registered companies linked to your account will appear here.</p>
            </div>
        `;
        return;
    }
    grid.innerHTML = list.map((company) => `
        <button type="button" class="company-card" onclick="switchView('client-companies')">
            <div class="company-card-name">${escapeHtml(company.name || 'Company')}</div>
            <div class="company-card-meta">${escapeHtml(company.company_number || '—')}</div>
            <div class="company-card-footer">
                <span>${escapeHtml(companyCountryLabel(company))}</span>
                <span class="status-badge ${(company.status || company.account_status) === 'Active' || (company.account_status === 'Good Standing') ? 'completed' : 'pending'}">${escapeHtml(company.status || company.account_status || '—')}</span>
            </div>
        </button>
    `).join('');
}

async function loadClientCompanies() {
    const grid = document.getElementById('portfolio-companies-grid');
    const countPill = document.getElementById('portfolio-company-count');
    try {
        if (countPill) countPill.textContent = '0 UK';
        if (grid) grid.innerHTML = portfolioSkeletonHtml();
        const res = await fetch('/api/client/companies', { credentials: 'same-origin' });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error('load-failed');
        }
        clientCompaniesCache = data.companies || [];
        renderPortfolioCompanies(clientCompaniesCache, 'portfolio-companies-grid', 'portfolio-company-count');
    } catch (err) {
        clientCompaniesCache = [];
        if (countPill) countPill.textContent = '0 UK';
        if (grid) {
            grid.innerHTML = `
                <div class="portfolio-error" role="alert">
                    <h3>Unable to load your Business Portfolio. Please try again.</h3>
                </div>
            `;
        }
    }
}

async function loadAdminCompanies() {
    const grid = document.getElementById('admin-portfolio-companies-grid');
    const countPill = document.getElementById('admin-portfolio-company-count');
    try {
        if (countPill) countPill.textContent = '0 UK';
        if (grid) grid.innerHTML = portfolioSkeletonHtml();
        let res = await fetch('/api/admin/companies', { credentials: 'same-origin' });
        let data = await res.json().catch(() => ({}));
        if (!res.ok || data.status !== 'success') {
            res = await fetch('/api/client/companies', { credentials: 'same-origin' });
            data = await res.json().catch(() => ({}));
        }
        const list = data.companies || [];
        if (countPill) countPill.textContent = `${data.total_uk || list.length} UK`;
        renderPortfolioCompanies(list, 'admin-portfolio-companies-grid', 'admin-portfolio-company-count');
    } catch (err) {
        if (countPill) countPill.textContent = '0 UK';
        if (grid) {
            grid.innerHTML = `
                <div class="portfolio-empty" role="status">
                    <i data-lucide="building-2" style="width:40px; height:40px; color:#c4b5fd;"></i>
                    <h3>No companies found.</h3>
                </div>
            `;
            if (window.lucide) lucide.createIcons();
        }
    }
}

async function loadClientAddresses() {
    try {
        const res = await fetch('/api/client/addresses');
        const data = await res.json();
        const tbody = document.getElementById('addresses-table-body');
        if (tbody && data.status === 'success') {
            tbody.innerHTML = data.addresses.map(a => `
                <tr>
                    <td style="font-weight:700; color:#7c3aed;">${a.type}</td>
                    <td>${a.line1}, ${a.city}, ${a.postal_code}</td>
                    <td>${a.company_name || 'Personal'}</td>
                    <td>${a.start_date}</td>
                    <td>${a.expiry_date}</td>
                    <td><span class="status-badge completed">${a.status}</span></td>
                </tr>
            `).join('');
        }
    } catch (err) { console.error(err); }
}

async function loadClientInvoices() {
    try {
        const res = await fetch('/api/client/invoices');
        const data = await res.json();
        const tbody = document.getElementById('invoices-table-body');
        if (tbody && data.status === 'success') {
            tbody.innerHTML = data.invoices.map(i => `
                <tr>
                    <td style="font-weight:700;">${i.invoice_number}</td>
                    <td>${i.service_name}</td>
                    <td style="font-weight:800;">£${parseFloat(i.total).toFixed(2)}</td>
                    <td>${i.due_date}</td>
                    <td><span class="status-badge ${i.status.toLowerCase()}">${i.status}</span></td>
                    <td><button class="btn-secondary" style="padding:4px 10px; font-size:0.75rem;">Download PDF</button></td>
                </tr>
            `).join('');
        }
    } catch (err) { console.error(err); }
}

async function loadClientPayments() {
    try {
        const res = await fetch('/api/client/payments');
        const data = await res.json();
        const tbody = document.getElementById('payments-table-body');
        if (tbody && data.status === 'success') {
            tbody.innerHTML = data.payments.map(p => `
                <tr>
                    <td style="font-weight:700; color:#006cff;">#PAY-${p.id}</td>
                    <td style="font-weight:600;">${p.service_name}</td>
                    <td>${p.order_number}</td>
                    <td style="font-weight:800; color:#0f172a;">£${parseFloat(p.total).toFixed(2)}</td>
                    <td><span class="badge" style="background:#f1f5f9; color:#475569; padding:4px 8px; border-radius:6px; font-weight:600;">${p.payment_method || 'Credit Card (Stripe)'}</span></td>
                    <td><span class="status-badge completed">${p.status === 'Paid' ? 'Completed' : p.status}</span></td>
                    <td><button class="btn-secondary" style="padding:4px 10px; font-size:0.75rem;">Receipt</button></td>
                </tr>
            `).join('');
        }
    } catch (err) { console.error(err); }
}

async function loadClientServices() {
    try {
        const res = await fetch('/api/client/services');
        const data = await res.json();
        const grid = document.getElementById('services-cards-grid');
        if (grid && data.status === 'success') {
            grid.innerHTML = data.services.map(s => `
                <div class="modal-card" style="margin:0; display:flex; flex-direction:column; justify-space-between;">
                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span class="badge" style="background:#e0f2fe; color:#0369a1; font-weight:700; font-size:0.75rem;">${s.category}</span>
                            <span style="font-size:1.25rem; font-weight:800; color:#003971;">£${parseFloat(s.price).toFixed(2)}</span>
                        </div>
                        <h3 style="font-size:1.1rem; font-weight:700; margin:12px 0 6px 0; color:#0f172a;">${s.name}</h3>
                        <p style="font-size:0.85rem; color:#64748b; margin-bottom:16px;">${s.description}</p>
                    </div>
                    <button class="btn-primary" style="width:100%; justify-content:center;">Order Service</button>
                </div>
            `).join('');
        }
    } catch (err) { console.error(err); }
}

async function loadClientMessages() {
    try {
        const res = await fetch('/api/client/messages');
        const data = await res.json();
        const threadsList = document.getElementById('threads-list');
        const messagesBody = document.getElementById('chat-messages-body');
        
        if (threadsList && data.status === 'success') {
            if (data.messages.length === 0) {
                threadsList.innerHTML = '<p style="font-size:0.85rem; color:#64748b;">No messages yet.</p>';
            } else {
                threadsList.innerHTML = data.messages.map(m => `
                    <div style="padding:10px; border-bottom:1px solid #f1f5f9; cursor:pointer; background:#f8fafc; border-radius:6px; margin-bottom:6px;">
                        <div style="font-size:0.8rem; font-weight:700; color:#006cff;">${m.ticket_number}</div>
                        <div style="font-size:0.85rem; font-weight:600; color:#0f172a;">${m.subject}</div>
                        <div style="font-size:0.75rem; color:#64748b;">${m.sender_name} • ${formatDate(m.created_at)}</div>
                    </div>
                `).join('');
                
                messagesBody.innerHTML = data.messages.map(m => `
                    <div class="chat-bubble ${m.sender_role.toLowerCase() === 'client' ? 'client' : 'staff'}" style="padding:10px 14px; border-radius:8px; background:${m.sender_role.toLowerCase() === 'client' ? '#003971' : '#f1f5f9'}; color:${m.sender_role.toLowerCase() === 'client' ? '#fff' : '#0f172a'}; max-width:80%; align-self:${m.sender_role.toLowerCase() === 'client' ? 'flex-end' : 'flex-start'};">
                        <div style="font-size:0.75rem; opacity:0.8; margin-bottom:4px;">${m.sender_name} (${m.sender_role}) • ${formatDate(m.created_at)}</div>
                        <div style="font-size:0.9rem;">${m.message}</div>
                    </div>
                `).join('');
            }
        }
    } catch (err) { console.error(err); }
}

async function loadClientDocuments() {
    try {
        const res = await fetch('/api/client/documents');
        const data = await res.json();
        const tbody = document.getElementById('documents-table-body');
        if (tbody && data.status === 'success') {
            tbody.innerHTML = data.documents.map(d => `
                <tr>
                    <td style="font-weight:700;">${escapeHtml(d.name)}</td>
                    <td>${escapeHtml(d.category || d.file_type || '—')}</td>
                    <td>${escapeHtml(formatDate(d.created_at))}</td>
                    <td>${escapeHtml(d.uploaded_by || '—')}</td>
                    <td><span class="status-badge ${documentStatusClass(d.status)}">${escapeHtml(d.status || '—')}</span></td>
                    <td>
                        <a href="/api/documents/${d.id}/download" target="_blank" class="btn-secondary" style="padding:4px 10px; font-size:0.75rem; text-decoration:none; margin-right:6px;">View</a>
                        <a href="/api/documents/${d.id}/download" class="btn-primary" style="padding:4px 10px; font-size:0.75rem; text-decoration:none;">Download</a>
                    </td>
                </tr>
            `).join('');
        }
    } catch (err) { console.error(err); }
}

async function loadClientTickets() {
    try {
        const res = await fetch('/api/client/tickets');
        const data = await res.json();
        const tbody = document.getElementById('tickets-table-body');
        if (tbody && data.status === 'success') {
            tbody.innerHTML = data.tickets.map(t => `
                <tr>
                    <td style="font-weight:700;">${t.ticket_number}</td>
                    <td>${t.subject}</td>
                    <td>${t.category}</td>
                    <td><span class="status-badge ${t.priority === 'Urgent' ? 'cancelled' : 'pending'}">${t.priority}</span></td>
                    <td><span class="status-badge ${t.status === 'Closed' ? 'completed' : 'processing'}">${t.status}</span></td>
                    <td><button class="btn-primary" style="padding:4px 10px; font-size:0.75rem;" onclick="openChatModal(${t.id}, '${t.subject}', '${t.ticket_number}')">Open Chat</button></td>
                </tr>
            `).join('');
        }
    } catch (err) { console.error(err); }
}

// ----------------------------------------------------
// SUPPORT TICKET LIVE CHAT THREAD
// ----------------------------------------------------
async function openChatModal(ticketId, subject, ticketNum) {
    activeTicketId = ticketId;
    document.getElementById('chat-ticket-subject').textContent = subject;
    document.getElementById('chat-ticket-num').textContent = ticketNum;
    
    await refreshChatMessages();
    document.getElementById('ticket-chat-modal').classList.add('active');
}

async function refreshChatMessages() {
    if (!activeTicketId) return;
    try {
        const res = await fetch(`/api/client/tickets/${activeTicketId}/messages`);
        const data = await res.json();
        const box = document.getElementById('chat-messages-box');
        if (box && data.status === 'success') {
            box.innerHTML = data.messages.map(m => `
                <div class="chat-bubble ${m.sender_role.toLowerCase() === 'client' ? 'client' : 'staff'}">
                    <div class="meta">${m.sender_name} (${m.sender_role}) • ${formatDate(m.created_at)}</div>
                    <div>${m.message}</div>
                </div>
            `).join('');
            box.scrollTop = box.scrollHeight;
        }
    } catch (err) { console.error(err); }
}

async function sendChatMessage() {
    const input = document.getElementById('chat-input');
    const msg = input.value.strip ? input.value.trim() : input.value;
    if (!msg || !activeTicketId) return;
    
    try {
        await fetch(`/api/client/tickets/${activeTicketId}/messages`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ message: msg })
        });
        input.value = '';
        await refreshChatMessages();
    } catch (err) { console.error(err); }
}

function closeChatModal() {
    document.getElementById('ticket-chat-modal').classList.remove('active');
    activeTicketId = null;
}

function openNewTicketModal() {
    document.getElementById('modal-new-ticket').classList.add('active');
}

function closeNewTicketModal() {
    document.getElementById('modal-new-ticket').classList.remove('active');
    document.getElementById('new-ticket-form').reset();
}

async function submitNewTicketForm(e) {
    e.preventDefault();
    const subject = document.getElementById('ticket-subject').value.trim();
    const category = document.getElementById('ticket-category').value;
    const priority = document.getElementById('ticket-priority').value;
    const description = document.getElementById('ticket-message').value.trim();

    if (!subject || !description) return;

    try {
        const res = await fetch('/api/client/tickets', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ subject, category, priority, description })
        });
        const data = await res.json();
        if (data.status === 'success') {
            closeNewTicketModal();
            await loadClientTickets();
        } else {
            alert(data.message || 'Error submitting support ticket.');
        }
    } catch (err) {
        console.error('Error submitting ticket:', err);
    }
}

// ----------------------------------------------------
// ADMIN CMS LOADERS
// ----------------------------------------------------
async function loadAdminDashboard() {
    if (!canViewAdminDashboard()) return;
    try {
        const res = await fetch('/api/admin/stats', { credentials: 'same-origin' });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load dashboard.');
        }
        const setText = (id, value) => {
            const el = document.getElementById(id);
            if (el) el.textContent = value;
        };
        setText('adm-tot-cust', data.stats.total_customers);
        setText('adm-tot-ord', data.stats.total_orders);
        setText('adm-tot-rev', data.stats.total_revenue);
        setText('adm-tot-tix', data.stats.open_tickets);
        renderAdminChart((data.charts && data.charts.monthly) || []);
    } catch (err) {
        console.error(err);
    }
}

function drawRevenueFallback(canvas, labels, values) {
    const wrap = canvas.parentElement;
    const width = Math.max(wrap ? wrap.clientWidth : 0, 260);
    const height = Math.max(wrap ? wrap.clientHeight : 0, 200);
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);
    const pad = { top: 16, right: 12, bottom: 36, left: 48 };
    const plotW = Math.max(width - pad.left - pad.right, 10);
    const plotH = Math.max(height - pad.top - pad.bottom, 10);
    const max = Math.max(...values, 1);
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad.left, pad.top);
    ctx.lineTo(pad.left, pad.top + plotH);
    ctx.lineTo(pad.left + plotW, pad.top + plotH);
    ctx.stroke();
    ctx.fillStyle = '#94a3b8';
    ctx.font = '11px Inter, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(`£${Math.round(max)}`, pad.left - 8, pad.top + 4);
    ctx.fillText('£0', pad.left - 8, pad.top + plotH);
    const points = values.map((value, idx) => {
        const x = pad.left + (values.length === 1 ? plotW / 2 : (plotW * idx) / (values.length - 1));
        const y = pad.top + plotH - (value / max) * plotH;
        return { x, y, label: labels[idx] || '' };
    });
    ctx.beginPath();
    points.forEach((pt, idx) => {
        if (idx === 0) ctx.moveTo(pt.x, pt.y);
        else ctx.lineTo(pt.x, pt.y);
    });
    ctx.strokeStyle = '#003971';
    ctx.lineWidth = 2;
    ctx.stroke();
    if (points.length) {
        ctx.lineTo(points[points.length - 1].x, pad.top + plotH);
        ctx.lineTo(points[0].x, pad.top + plotH);
        ctx.closePath();
        ctx.fillStyle = 'rgba(0, 108, 255, 0.12)';
        ctx.fill();
    }
    points.forEach((pt) => {
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#006cff';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.fillStyle = '#64748b';
        ctx.font = '10px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(pt.label, pt.x, height - 10);
    });
}

function renderAdminChart(monthlyData) {
    const canvas = document.getElementById('admin-chart-canvas');
    const empty = document.getElementById('admin-chart-empty');
    if (!canvas) return;
    const rows = Array.isArray(monthlyData) ? monthlyData : [];
    const labels = rows.map((m) => m.label || m.month || '');
    const values = rows.map((m) => {
        const n = Number(m.rev);
        return Number.isFinite(n) ? n : 0;
    });
    if (empty) empty.hidden = values.some((v) => v > 0);
    const draw = () => {
        if (typeof Chart === 'function') {
            if (adminChart && typeof adminChart.destroy === 'function') {
                adminChart.destroy();
                adminChart = null;
            }
            adminChart = new Chart(canvas, {
                type: 'line',
                data: {
                    labels,
                    datasets: [{
                        label: 'Revenue (£)',
                        data: values,
                        borderColor: '#003971',
                        backgroundColor: 'rgba(0, 108, 255, 0.12)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.35,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        pointBackgroundColor: '#006cff',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    resizeDelay: 0,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label(ctx) {
                                    const amount = Number(ctx.parsed.y || 0);
                                    return `£${amount.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback(value) {
                                    return `£${value}`;
                                }
                            }
                        }
                    }
                }
            });
            return;
        }
        drawRevenueFallback(canvas, labels, values);
    };
    requestAnimationFrame(() => requestAnimationFrame(draw));
}

let adminOrdersPage = 1;
let adminOrdersTimer = null;

function resetAdminOrdersPage() {
    adminOrdersPage = 1;
}

function scheduleLoadAdminOrders() {
    resetAdminOrdersPage();
    clearTimeout(adminOrdersTimer);
    adminOrdersTimer = setTimeout(loadAdminOrders, 250);
}

function onAdminOrderDatePresetChange() {
    const preset = document.getElementById('filter-admin-order-preset')?.value || '';
    const showCustom = preset === 'custom';
    const fromEl = document.getElementById('filter-admin-order-from');
    const toEl = document.getElementById('filter-admin-order-to');
    if (fromEl) fromEl.classList.toggle('is-visible', showCustom);
    if (toEl) toEl.classList.toggle('is-visible', showCustom);
    if (!showCustom) {
        if (fromEl) fromEl.value = '';
        if (toEl) toEl.value = '';
    }
}

function adminOrderProgressRange() {
    const raw = document.getElementById('filter-admin-order-progress')?.value || '';
    if (!raw || !raw.includes('-')) return { min: '', max: '' };
    const [min, max] = raw.split('-');
    return { min, max };
}

function buildAdminOrderQuery(page) {
    const qs = new URLSearchParams();
    const search = document.getElementById('filter-admin-order-search')?.value.trim() || '';
    const product = document.getElementById('filter-admin-order-product')?.value || '';
    const category = document.getElementById('filter-admin-order-category')?.value || '';
    const statusGroup = document.getElementById('filter-admin-order-status-group')?.value || '';
    const status = document.getElementById('filter-admin-order-status')?.value || '';
    const payment = document.getElementById('filter-admin-order-payment')?.value || '';
    const customer = document.getElementById('filter-admin-order-customer')?.value || '';
    const preset = document.getElementById('filter-admin-order-preset')?.value || '';
    const month = document.getElementById('filter-admin-order-month')?.value || '';
    const year = document.getElementById('filter-admin-order-year')?.value || '';
    const dateFrom = document.getElementById('filter-admin-order-from')?.value || '';
    const dateTo = document.getElementById('filter-admin-order-to')?.value || '';
    const progress = adminOrderProgressRange();
    if (search) qs.set('search', search);
    if (product) qs.set('product', product);
    if (category) qs.set('category', category);
    if (statusGroup) qs.set('status_group', statusGroup);
    if (status) qs.set('status', status);
    if (payment) qs.set('payment_status', payment);
    if (customer) qs.set('customer_id', customer);
    if (preset && preset !== 'custom') qs.set('date_preset', preset);
    if (preset === 'custom' && dateFrom) qs.set('date_from', dateFrom);
    if (preset === 'custom' && dateTo) qs.set('date_to', dateTo);
    if (!preset && month) qs.set('month', month);
    if (!preset && year) qs.set('year', year);
    if (progress.min !== '') qs.set('progress_min', progress.min);
    if (progress.max !== '') qs.set('progress_max', progress.max);
    qs.set('page', String(page || 1));
    qs.set('limit', '25');
    return qs;
}

function fillAdminOrderFacet(id, values, labelKey, valueKey) {
    const sel = document.getElementById(id);
    if (!sel) return;
    const current = sel.value;
    const first = sel.options[0] ? sel.options[0].outerHTML : '<option value="">All</option>';
    const items = values || [];
    sel.innerHTML = first + items.map((item) => {
        const value = valueKey ? String(item[valueKey]) : String(item);
        const label = labelKey ? item[labelKey] : item;
        return `<option value="${escapeHtml(value)}"${value === current ? ' selected' : ''}>${escapeHtml(label)}</option>`;
    }).join('');
    if (current && ![...sel.options].some((opt) => opt.value === current)) {
        sel.insertAdjacentHTML('beforeend', `<option value="${escapeHtml(current)}" selected>${escapeHtml(current)}</option>`);
    }
}

function renderAdminOrderStats(stats) {
    const s = stats || {};
    const set = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    };
    set('adm-ord-stat-total', s.total_orders ?? 0);
    set('adm-ord-stat-pending', s.pending ?? 0);
    set('adm-ord-stat-progress', s.in_progress ?? 0);
    set('adm-ord-stat-completed', s.completed ?? 0);
    if (canViewRevenue() && s.revenue != null) {
        set('adm-ord-stat-revenue', `£${parseFloat(s.revenue || 0).toFixed(2)}`);
    } else {
        set('adm-ord-stat-revenue', '—');
    }
    set('adm-ord-stat-month', s.this_month ?? 0);
}

function renderAdminOrderPagination(pagination) {
    const box = document.getElementById('adm-orders-pagination');
    if (!box) return;
    const totalPages = pagination?.total_pages || 1;
    const page = pagination?.page || 1;
    const total = pagination?.total || 0;
    if (total === 0) {
        box.innerHTML = '';
        return;
    }
    box.innerHTML = `
        <span style="font-size:0.8rem; color:#64748b;">${total} orders · page ${page} of ${totalPages}</span>
        <div style="display:flex; gap:8px;">
            <button type="button" class="btn-secondary" ${page <= 1 ? 'disabled' : ''} onclick="goAdminOrdersPage(${page - 1})">Previous</button>
            <button type="button" class="btn-secondary" ${page >= totalPages ? 'disabled' : ''} onclick="goAdminOrdersPage(${page + 1})">Next</button>
        </div>
    `;
}

function goAdminOrdersPage(page) {
    adminOrdersPage = Math.max(1, page);
    loadAdminOrders();
}

function clearAdminOrderFilters() {
    ['filter-admin-order-search', 'filter-admin-order-product', 'filter-admin-order-category',
     'filter-admin-order-status-group', 'filter-admin-order-status', 'filter-admin-order-payment',
     'filter-admin-order-customer', 'filter-admin-order-progress', 'filter-admin-order-preset',
     'filter-admin-order-month', 'filter-admin-order-year', 'filter-admin-order-from', 'filter-admin-order-to'
    ].forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    onAdminOrderDatePresetChange();
    resetAdminOrdersPage();
    loadAdminOrders();
}

function showAdminOrdersError(message) {
    const box = document.getElementById('adm-orders-error');
    if (!box) return;
    box.style.display = message ? 'block' : 'none';
    box.textContent = message || '';
}

async function loadAdminOrders() {
    const tbody = document.getElementById('adm-orders-table-body');
    showAdminOrdersError('');
    try {
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#64748b; padding:28px;">Loading orders…</td></tr>`;
        }
        const qs = buildAdminOrderQuery(adminOrdersPage);
        const res = await fetch(`/api/admin/orders?${qs.toString()}`, { credentials: 'same-origin' });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load orders.');
        }
        fillAdminOrderFacet('filter-admin-order-product', data.facets?.products || []);
        fillAdminOrderFacet('filter-admin-order-category', data.facets?.categories || []);
        fillAdminOrderFacet('filter-admin-order-year', data.facets?.years || []);
        fillAdminOrderFacet('filter-admin-order-customer', data.facets?.customers || [], 'full_name', 'id');
        renderAdminOrderStats(data.stats);
        renderAdminOrderPagination(data.pagination);
        if (!tbody) return;
        if (!data.orders.length) {
            tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#64748b; padding:28px;">No orders match the current filters.</td></tr>`;
            return;
        }
        tbody.innerHTML = data.orders.map(o => {
            const product = o.products_summary || o.service_name || '—';
            const category = o.category_name ? `${escapeHtml(o.category_name)} · ` : '';
            return `
                <tr class="order-row" data-order-id="${o.id}">
                    <td><button type="button" class="order-number-link" data-order-action="open" data-order-id="${o.id}">${escapeHtml(o.order_number)}</button></td>
                    <td class="cell-date">${escapeHtml(formatDateTime(o.created_at) || formatDate(o.created_at))}</td>
                    <td class="cell-client">${escapeHtml(o.client_name || '')}<div class="cell-subtext">${escapeHtml(o.client_email || '')}</div></td>
                    <td class="cell-company">${escapeHtml(o.company_name || '—')}</td>
                    <td class="cell-product">${category}${escapeHtml(product)}</td>
                    <td class="cell-price">£${parseFloat(o.total || 0).toFixed(2)}</td>
                    <td>
                        <select class="table-select" data-order-action="payment_mode" data-order-id="${o.id}">
                            <option value="" ${!o.payment_mode ? 'selected' : ''}>Select mode</option>
                            <option value="PKR(Bank Transfer)" ${o.payment_mode === 'PKR(Bank Transfer)' ? 'selected' : ''}>PKR(Bank Transfer)</option>
                            <option value="GBP(Bank Transfer)" ${o.payment_mode === 'GBP(Bank Transfer)' ? 'selected' : ''}>GBP(Bank Transfer)</option>
                            <option value="Website Charge" ${o.payment_mode === 'Website Charge' ? 'selected' : ''}>Website Charge</option>
                        </select>
                    </td>
                    <td>
                        <select class="table-select" data-order-action="status" data-order-id="${o.id}">
                            <option value="Pending Verification" ${o.status === 'Pending Verification' ? 'selected' : ''}>Pending Verification</option>
                            <option value="Pending" ${o.status === 'Pending' ? 'selected' : ''}>Pending</option>
                            <option value="Processing" ${o.status === 'Processing' ? 'selected' : ''}>Processing</option>
                            <option value="In Progress" ${o.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                            <option value="Completed" ${o.status === 'Completed' ? 'selected' : ''}>Completed</option>
                            <option value="Cancelled" ${o.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                            <option value="Refunded" ${o.status === 'Refunded' ? 'selected' : ''}>Refunded</option>
                        </select>
                    </td>
                    <td class="cell-actions">
                        <div class="order-row-actions">
                            <button type="button" class="btn-primary btn-table" data-order-action="open" data-order-id="${o.id}">Manage</button>
                            ${canAdvanceOrderProgress(o) ? `<button type="button" class="btn-secondary btn-table" data-order-action="progress" data-order-id="${o.id}" data-progress="${o.progress_percent || 0}" title="Increase this order's work progress by 15%">+15%</button>` : ''}
                            ${canDeleteOrders() ? `<button type="button" class="btn-danger btn-table" data-order-action="delete" data-order-id="${o.id}" data-order-number="${escapeHtml(o.order_number)}">Delete</button>` : ''}
                        </div>
                    </td>
                </tr>`;
        }).join('');
    } catch (err) {
        showAdminOrdersError(err.message || 'Unable to load orders.');
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#dc2626; padding:28px;">Unable to load orders.</td></tr>`;
        }
    }
}

async function updateAdminOrderPaymentMode(orderId, paymentMode) {
    try {
        const res = await fetch(`/api/admin/orders/${orderId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({ payment_mode: paymentMode || null })
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') throw new Error(data.message || 'Unable to update payment mode.');
        loadAdminOrders();
        if (staffOrderId === orderId) await openStaffOrderWorkspace(orderId);
    } catch (err) {
        alert(err.message || 'Unable to update payment mode.');
    }
}

async function updateAdminOrderStatus(orderId, newStatus) {
    let progress = newStatus === 'Completed' ? 100 : (newStatus === 'Cancelled' ? 0 : undefined);
    const body = { status: newStatus };
    if (progress !== undefined) body.progress_percent = progress;
    try {
        const res = await fetch(`/api/admin/orders/${orderId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify(body)
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') throw new Error(data.message || 'Unable to update order.');
        loadAdminOrders();
        if (staffOrderId === orderId) await openStaffOrderWorkspace(orderId);
    } catch (err) {
        alert(err.message || 'Unable to update order.');
    }
}

async function advanceOrderProgress(orderId, currentProgress) {
    let newProgress = Math.min(100, Number(currentProgress || 0) + 15);
    let newStatus = newProgress === 100 ? 'Completed' : 'In Progress';
    try {
        const res = await fetch(`/api/admin/orders/${orderId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({ progress_percent: newProgress, status: newStatus })
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') throw new Error(data.message || 'Unable to update progress.');
        loadAdminOrders();
        if (staffOrderId === orderId) await openStaffOrderWorkspace(orderId);
    } catch (err) {
        alert(err.message || 'Unable to update progress.');
    }
}

async function advanceStaffOrderProgress() {
    if (!staffOrderId) return;
    const label = document.getElementById('staff-order-progress')?.textContent || '0';
    const current = parseInt(label, 10) || 0;
    await advanceOrderProgress(staffOrderId, current);
}

async function saveStaffOrderNotes() {
    if (!staffOrderId || !canOperateOrderDocuments()) return;
    const notes = document.getElementById('staff-order-notes')?.value || '';
    try {
        const res = await fetch(`/api/admin/orders/${staffOrderId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({ notes })
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') throw new Error(data.message || 'Unable to save notes.');
        setStaffOrderNotice('success', 'Internal notes saved.');
        await openStaffOrderWorkspace(staffOrderId);
    } catch (err) {
        setStaffOrderNotice('error', err.message || 'Unable to save notes.');
    }
}

let staffOrderId = null;
let staffOrderClientId = null;
let staffOrderCompanyId = null;

function canOperateOrderDocuments() {
    return currentUser && ['SUPER_ADMIN', 'ADMIN', 'MANAGER', 'STAFF'].includes(currentUser.role);
}

function canManageOrders() {
    return canOperateOrderDocuments();
}

function canDeleteOrders() {
    return currentUser && ['SUPER_ADMIN', 'ADMIN'].includes(currentUser.role);
}

function canAdvanceOrderProgress(order) {
    const status = String(order && order.status ? order.status : '');
    const pct = Number(order && order.progress_percent ? order.progress_percent : 0);
    if (['Completed', 'Cancelled', 'Refunded'].includes(status)) return false;
    return pct < 100;
}

let pendingDeleteOrderId = null;
let pendingDeleteOrderNumber = '';

function openDeleteOrderModal(orderId, orderNumber) {
    if (!canDeleteOrders() || !orderId) return;
    pendingDeleteOrderId = orderId;
    pendingDeleteOrderNumber = (orderNumber || document.getElementById('staff-order-number')?.textContent || '').trim();
    const numEl = document.getElementById('delete-order-number');
    if (numEl) numEl.textContent = pendingDeleteOrderNumber;
    const input = document.getElementById('delete-order-confirm');
    if (input) input.value = '';
    const err = document.getElementById('delete-order-error');
    if (err) {
        err.style.display = 'none';
        err.textContent = '';
    }
    const modal = document.getElementById('modal-delete-order');
    if (modal) modal.classList.add('active');
    safeCreateIcons();
}

function closeDeleteOrderModal() {
    const modal = document.getElementById('modal-delete-order');
    if (modal) modal.classList.remove('active');
    pendingDeleteOrderId = null;
    pendingDeleteOrderNumber = '';
}

async function confirmDeleteOrder() {
    if (!canDeleteOrders() || !pendingDeleteOrderId) return;
    const typed = (document.getElementById('delete-order-confirm')?.value || '').trim();
    const expected = (pendingDeleteOrderNumber || '').trim();
    const err = document.getElementById('delete-order-error');
    if (expected && typed !== expected) {
        if (err) {
            err.style.display = 'block';
            err.textContent = 'Order number does not match.';
        }
        return;
    }
    try {
        const res = await fetch(`/api/admin/orders/${pendingDeleteOrderId}`, {
            method: 'DELETE',
            credentials: 'same-origin'
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to delete this order.');
        }
        const deletedId = pendingDeleteOrderId;
        closeDeleteOrderModal();
        if (staffOrderId === deletedId) {
            closeStaffOrderModal();
            staffOrderId = null;
        }
        if (typeof loadAdminOrders === 'function') loadAdminOrders();
    } catch (ex) {
        if (err) {
            err.style.display = 'block';
            err.textContent = ex.message || 'Unable to delete this order.';
        }
    }
}

async function updateStaffOrderAssignee(staffId) {
    if (!staffOrderId || !canManageOrders()) return;
    try {
        const res = await fetch(`/api/admin/orders/${staffOrderId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({ assigned_staff_id: staffId || null })
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') throw new Error(data.message || 'Unable to assign staff.');
        setStaffOrderNotice('success', 'Assigned staff updated.');
        await openStaffOrderWorkspace(staffOrderId);
        if (typeof loadAdminOrders === 'function') loadAdminOrders();
    } catch (err) {
        setStaffOrderNotice('error', err.message || 'Unable to assign staff.');
    }
}

function canUploadClientDocuments() {
    return canOperateOrderDocuments();
}

function documentStatusClass(status) {
    if (status === 'Approved') return 'completed';
    if (status === 'Rejected') return 'cancelled';
    return 'pending';
}

function setStaffOrderNotice(kind, message) {
    const err = document.getElementById('staff-order-error');
    const ok = document.getElementById('staff-order-success');
    if (err) {
        err.style.display = kind === 'error' && message ? 'block' : 'none';
        err.textContent = kind === 'error' ? (message || '') : '';
    }
    if (ok) {
        ok.style.display = kind === 'success' && message ? 'block' : 'none';
        ok.textContent = kind === 'success' ? (message || '') : '';
    }
}

async function openStaffOrderWorkspace(orderId) {
    if (!currentUser || currentUser.role === 'CLIENT') {
        alert('Staff sign-in is required to process an order.');
        return;
    }
    setStaffOrderNotice('', '');
    try {
        const requests = [
            fetch(`/api/client/orders/${orderId}`, { credentials: 'same-origin' }),
            fetch(`/api/admin/orders/${orderId}/conversation`, { credentials: 'same-origin' }),
            fetch(`/api/admin/tasks?order_id=${orderId}`, { credentials: 'same-origin' })
        ];
        const [orderRes, convRes, taskRes] = await Promise.all(requests);
        const data = await orderRes.json();
        const conv = await convRes.json();
        const taskData = taskRes.ok ? await taskRes.json() : { tasks: [] };
        if (!orderRes.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load order.');
        }
        const order = data.order;
        staffOrderId = order.id;
        staffOrderClientId = order.user_id;
        staffOrderCompanyId = order.company_id;
        document.getElementById('staff-order-number').textContent = order.order_number;
        document.getElementById('staff-order-meta').textContent = `${formatDateTime(order.created_at) || formatDate(order.created_at)} · £${parseFloat(order.total).toFixed(2)}`;
        document.getElementById('staff-order-customer').textContent = order.client_name || '';
        document.getElementById('staff-order-company').textContent = order.company_name || '—';
        const emailEl = document.getElementById('staff-order-email');
        if (emailEl) emailEl.textContent = order.client_email || '—';
        const phoneEl = document.getElementById('staff-order-phone');
        if (phoneEl) phoneEl.textContent = order.client_phone || '—';
        document.getElementById('staff-order-status').textContent = order.status;
        document.getElementById('staff-order-staff').textContent = order.assigned_staff_name || 'Unassigned';
        const payEl = document.getElementById('staff-order-payment');
        if (payEl) {
            const inv = data.invoice;
            payEl.textContent = inv ? `${inv.status}${inv.invoice_number ? ' · ' + inv.invoice_number : ''}` : 'No invoice';
        }
        const progEl = document.getElementById('staff-order-progress');
        if (progEl) progEl.textContent = `${order.progress_percent || 0}%`;
        const notesEl = document.getElementById('staff-order-notes');
        if (notesEl) notesEl.value = order.notes || '';
        const statusSel = document.getElementById('staff-order-status-select');
        if (statusSel) {
            statusSel.innerHTML = ['Pending Verification', 'Pending', 'Processing', 'In Progress', 'Completed', 'Cancelled', 'Refunded'].map((st) =>
                `<option value="${st}"${st === order.status ? ' selected' : ''}>${st}</option>`
            ).join('');
        }
        const assigneeSel = document.getElementById('staff-order-assignee-select');
        if (assigneeSel) {
            try {
                if (!taskStaffCache.length) await fetchTaskStaff();
            } catch (staffErr) {
                taskStaffCache = taskStaffCache || [];
            }
            fillStaffSelect('staff-order-assignee-select', order.assigned_staff_id, 'Unassigned');
        }
        const manage = document.getElementById('staff-order-manage');
        if (manage) manage.style.display = canManageOrders() ? 'flex' : 'none';
        const deleteBtn = document.getElementById('staff-order-delete-btn');
        if (deleteBtn) deleteBtn.style.display = canDeleteOrders() ? 'inline-flex' : 'none';
        const progressBtn = document.getElementById('staff-order-progress-btn');
        if (progressBtn) progressBtn.style.display = canAdvanceOrderProgress(order) ? 'inline-flex' : 'none';
        const addrBox = document.getElementById('staff-order-address');
        if (addrBox) {
            const bits = [];
            if (order.client_address) bits.push(`<div><strong>Billing</strong><div>${escapeHtml(order.client_address)}${order.client_country ? ', ' + escapeHtml(order.client_country) : ''}</div></div>`);
            if (order.company_address) bits.push(`<div><strong>Registered office</strong><div>${escapeHtml(order.company_address)}</div></div>`);
            (data.addresses || []).forEach((a) => {
                bits.push(`<div><strong>${escapeHtml(a.type)}</strong><div>${escapeHtml([a.line1, a.line2, a.city, a.postal_code, a.country].filter(Boolean).join(', '))}</div></div>`);
            });
            addrBox.innerHTML = bits.length ? bits.join('') : '<p style="color:#64748b; font-size:0.85rem;">No billing or shipping address stored for this order.</p>';
        }
        const lines = data.line_items || [];
        document.getElementById('staff-order-products').innerHTML = lines.length ? `<table class="data-table"><thead><tr><th>Category</th><th>Product</th><th>SKU</th><th>Qty</th><th>Unit</th><th>Total</th></tr></thead><tbody>${lines.map((item) => `
            <tr>
                <td>${escapeHtml(item.category_name || '—')}</td>
                <td>${escapeHtml(item.product_name)}</td>
                <td>${escapeHtml(item.sku || '—')}</td>
                <td>${item.quantity}</td>
                <td>£${parseFloat(item.unit_price || 0).toFixed(2)}</td>
                <td>£${parseFloat(item.line_total || 0).toFixed(2)}</td>
            </tr>`).join('')}</tbody></table>` : `<p style="color:#64748b; font-size:0.85rem;">${escapeHtml(order.service_name)} · £${parseFloat(order.price || 0).toFixed(2)}</p>`;
        const timeline = data.timeline || [];
        const timelineBox = document.getElementById('staff-order-timeline');
        if (timelineBox) {
            timelineBox.innerHTML = timeline.length ? timeline.map((step) => `
                <div style="display:flex; gap:10px; padding:6px 0; border-bottom:1px solid #e2e8f0; font-size:0.82rem;">
                    <span class="status-badge ${step.status === 'Completed' ? 'completed' : (step.status === 'Current' ? 'processing' : 'pending')}">${escapeHtml(step.status)}</span>
                    <div><strong>${escapeHtml(step.title)}</strong><div style="color:#64748b;">${step.step_date ? (formatDateTime(step.step_date) || formatDate(step.step_date)) : 'Pending'}</div></div>
                </div>
            `).join('') : '<p style="color:#64748b; font-size:0.85rem;">No history recorded yet.</p>';
        }
        const orderTasks = taskData.tasks || [];
        const tasksBox = document.getElementById('staff-order-tasks');
        if (tasksBox) {
            tasksBox.innerHTML = orderTasks.length ? orderTasks.map((t) => `
                <div style="display:flex; justify-content:space-between; gap:8px; align-items:center; padding:8px 0; border-bottom:1px solid #e2e8f0; font-size:0.82rem;">
                    <div><strong>${escapeHtml(t.title)}</strong><div style="color:#64748b;">${escapeHtml(t.assigned_staff_name || 'Unassigned')} · ${escapeHtml(t.status)}</div></div>
                    <button type="button" class="btn-secondary" style="padding:4px 8px; font-size:0.75rem;" onclick="openEditTaskModal(${t.id})">Open Task</button>
                </div>
            `).join('') : '<p style="color:#64748b; font-size:0.85rem;">No staff tasks on this order yet.</p>';
        }
        const docs = data.documents || [];
        document.getElementById('staff-order-documents').innerHTML = docs.length ? docs.map((d) => `
            <div style="display:flex; justify-content:space-between; gap:8px; align-items:center; padding:8px 0; border-bottom:1px solid #e2e8f0; font-size:0.82rem;">
                <div><strong>${escapeHtml(d.name)}</strong><div style="color:#64748b;">${d.client_visible ? 'Visible to customer' : 'Internal until sent'} · ${escapeHtml(d.uploaded_by || '')}</div></div>
                <div style="display:flex; gap:6px;">
                    <a class="btn-secondary" style="padding:4px 8px; font-size:0.75rem; text-decoration:none;" href="/api/documents/${d.id}/download">View</a>
                    ${canOperateOrderDocuments() && !d.client_visible ? `<button type="button" class="btn-primary" style="padding:4px 8px; font-size:0.75rem;" onclick="sendOrderDocumentToCustomer(${d.id})">Send to Customer</button>` : ''}
                </div>
            </div>`).join('') : '<p style="color:#64748b; font-size:0.85rem;">No files uploaded to this order yet. Use Upload Document to attach a PDF or image. Order products are not files.</p>';
        const msgs = (conv && conv.messages) || [];
        document.getElementById('staff-order-messages').innerHTML = msgs.length ? msgs.map((m) => `
            <div style="margin-bottom:8px; font-size:0.82rem;"><strong>${escapeHtml(m.sender_name)}</strong> <span style="color:#94a3b8;">${escapeHtml(m.sender_role)}</span><div>${escapeHtml(m.message)}</div></div>
        `).join('') : '<p style="color:#64748b; font-size:0.82rem;">No conversation yet.</p>';
        const docActions = document.getElementById('staff-order-doc-actions');
        const msgActions = document.getElementById('staff-order-msg-actions');
        const taskActions = document.getElementById('staff-order-task-actions');
        if (docActions) docActions.style.display = canOperateOrderDocuments() ? 'flex' : 'none';
        if (msgActions) msgActions.style.display = canOperateOrderDocuments() ? 'block' : 'none';
        if (taskActions) taskActions.style.display = canAssignStaffTasks() ? 'block' : 'none';
        const modal = document.getElementById('modal-staff-order');
        if (modal) modal.classList.add('active');
        safeCreateIcons();
    } catch (err) {
        alert(err.message || 'Unable to open order.');
    }
}

function closeStaffOrderModal() {
    const modal = document.getElementById('modal-staff-order');
    if (modal) modal.classList.remove('active');
}

async function uploadStaffOrderDocument() {
    openDeliverDocumentModalFromOrder();
}

async function sendOrderDocumentToCustomer(docId) {
    if (!canOperateOrderDocuments()) return;
    if (!confirm('Send this document to the customer portal?')) return;
    try {
        const res = await fetch(`/api/admin/documents/${docId}/send`, {
            method: 'POST',
            credentials: 'same-origin'
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') throw new Error(data.message || 'Unable to send document.');
        setStaffOrderNotice('success', data.message);
        if (staffOrderId) await openStaffOrderWorkspace(staffOrderId);
    } catch (err) {
        setStaffOrderNotice('error', err.message || 'Unable to send document.');
    }
}

async function sendStaffOrderMessage() {
    if (!staffOrderId || !canOperateOrderDocuments()) return;
    const box = document.getElementById('staff-order-message');
    const message = box ? box.value.trim() : '';
    if (!message) {
        setStaffOrderNotice('error', 'Enter a message.');
        return;
    }
    try {
        const res = await fetch(`/api/admin/orders/${staffOrderId}/conversation`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({ message })
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') throw new Error(data.message || 'Unable to send message.');
        if (box) box.value = '';
        setStaffOrderNotice('success', 'Message sent to the customer.');
        await openStaffOrderWorkspace(staffOrderId);
    } catch (err) {
        setStaffOrderNotice('error', err.message || 'Unable to send message.');
    }
}

async function createTaskFromStaffOrder() {
    if (!canAssignStaffTasks() || !staffOrderId) return;
    closeStaffOrderModal();
    await openNewTaskModal(null, staffOrderClientId, staffOrderId);
}

let taskStaffCache = [];
let taskCustomerCache = [];
let taskAssocCache = {};

function canAssignStaffTasks() {
    return currentUser && ['ADMIN', 'SUPER_ADMIN', 'MANAGER'].includes(currentUser.role);
}

function showTasksError(message) {
    const box = document.getElementById('adm-tasks-error');
    if (!box) return;
    if (!message) {
        box.style.display = 'none';
        box.textContent = '';
        return;
    }
    box.textContent = message;
    box.style.display = 'block';
}

function showModalError(id, message) {
    const box = document.getElementById(id);
    if (!box) return;
    if (!message) {
        box.style.display = 'none';
        box.textContent = '';
        return;
    }
    box.textContent = message;
    box.style.display = 'block';
}

function escapeHtml(value) {
    return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function optionalId(value) {
    if (value === undefined || value === null || value === '') return null;
    const parsed = parseInt(value, 10);
    return Number.isNaN(parsed) ? null : parsed;
}

function taskStatusClass(status) {
    const key = (status || '').toLowerCase().replace(/ /g, '-');
    if (key === 'completed') return 'completed';
    if (key === 'in-progress') return 'in-progress';
    if (key === 'cancelled') return 'cancelled';
    return 'open';
}

function taskPriorityClass(priority) {
    if (priority === 'Urgent') return 'cancelled';
    if (priority === 'High') return 'pending';
    if (priority === 'Low') return 'open';
    return 'in-progress';
}

function applyTaskUiPermissions() {
    const canAssign = canAssignStaffTasks();
    const newBtn = document.getElementById('btn-new-task');
    if (newBtn) newBtn.style.display = canAssign ? 'inline-flex' : 'none';
    const assigneeFilter = document.getElementById('filter-task-assignee');
    if (assigneeFilter) assigneeFilter.style.display = canAssign ? '' : 'none';
    const teamBtn = document.getElementById('btn-tasks-open-team');
    if (teamBtn) teamBtn.style.display = canManageUsers() ? 'inline-flex' : 'none';
}

async function fetchTaskStaff() {
    const res = await fetch('/api/admin/staff');
    const data = await res.json();
    if (!res.ok || data.status !== 'success') {
        throw new Error(data.message || 'Unable to load staff list.');
    }
    taskStaffCache = data.staff || [];
    return taskStaffCache;
}

async function fetchTaskCustomers() {
    const res = await fetch('/api/admin/customers', { credentials: 'same-origin' });
    const data = await res.json();
    if (!res.ok || data.status !== 'success') {
        throw new Error(data.message || 'Unable to load clients.');
    }
    taskCustomerCache = data.customers || [];
    return taskCustomerCache;
}

function fillDepartmentSelect(selectId, selectedValue, includeBlankLabel) {
    const sel = document.getElementById(selectId);
    if (!sel) return;
    const blank = includeBlankLabel || 'Select department';
    sel.innerHTML = `<option value="">${escapeHtml(blank)}</option>` + STAFF_DEPARTMENTS.map((dept) =>
        `<option value="${escapeHtml(dept)}">${escapeHtml(dept)}</option>`
    ).join('');
    if (selectedValue) sel.value = selectedValue;
}

function staffDepartments(staff) {
    if (!staff) return [];
    if (Array.isArray(staff.departments) && staff.departments.length) return staff.departments;
    if (staff.department) return [staff.department];
    return [];
}

function staffForDepartment(department) {
    if (!department) return taskStaffCache;
    const matched = taskStaffCache.filter((s) => staffDepartments(s).includes(department));
    const unassigned = taskStaffCache.filter((s) => staffDepartments(s).length === 0);
    const seen = new Set();
    return [...matched, ...unassigned].filter((s) => {
        if (seen.has(s.id)) return false;
        seen.add(s.id);
        return true;
    });
}

function fillStaffSelect(selectId, selectedId, includeAllLabel, department) {
    const sel = document.getElementById(selectId);
    if (!sel) return;
    const first = includeAllLabel || 'Unassigned';
    const staff = staffForDepartment(department);
    sel.innerHTML = `<option value="">${escapeHtml(first)}</option>` + staff.map(s => {
        const dept = staffDepartments(s).length ? ` · ${staffDepartments(s).join(', ')}` : '';
        return `<option value="${s.id}">${escapeHtml(s.full_name)}${escapeHtml(dept)}</option>`;
    }).join('');
    if (selectedId) sel.value = String(selectedId);
}

function onTaskDepartmentChange(prefix) {
    const dept = document.getElementById(`${prefix}-task-department`)?.value || '';
    const current = document.getElementById(`${prefix}-task-assignee`)?.value || '';
    fillStaffSelect(`${prefix}-task-assignee`, current, 'Anyone in this department', dept);
}

function fillClientSelect(selectId, selectedId) {
    const sel = document.getElementById(selectId);
    if (!sel) return;
    sel.innerHTML = `<option value="">No client</option>` + taskCustomerCache.map(c =>
        `<option value="${c.id}">${escapeHtml(c.full_name)}</option>`
    ).join('');
    if (selectedId) sel.value = String(selectedId);
}

async function loadTaskAssociations(clientId) {
    if (!clientId) return { companies: [], orders: [] };
    if (taskAssocCache[clientId]) return taskAssocCache[clientId];
    const res = await fetch(`/api/admin/clients/${clientId}/full`);
    const data = await res.json();
    if (!res.ok || data.status !== 'success') {
        throw new Error(data.message || 'Unable to load client companies and orders.');
    }
    const packed = { companies: data.companies || [], orders: data.orders || [] };
    taskAssocCache[clientId] = packed;
    return packed;
}

function fillCompanyOrderSelects(prefix, assoc, selectedCompanyId, selectedOrderId) {
    const companySel = document.getElementById(`${prefix}-task-company`);
    const orderSel = document.getElementById(`${prefix}-task-order`);
    const companies = assoc.companies || [];
    const orders = assoc.orders || [];
    if (companySel) {
        companySel.innerHTML = `<option value="">No company</option>` + companies.map(c =>
            `<option value="${c.id}">${escapeHtml(c.name)}</option>`
        ).join('');
        if (selectedCompanyId) companySel.value = String(selectedCompanyId);
    }
    fillTaskOrderSelect(prefix, orders, companySel ? companySel.value : '', selectedOrderId);
}

function fillTaskOrderSelect(prefix, orders, companyId, selectedOrderId) {
    const orderSel = document.getElementById(`${prefix}-task-order`);
    if (!orderSel) return;
    const filtered = companyId
        ? orders.filter(o => !o.company_id || String(o.company_id) === String(companyId))
        : orders;
    orderSel.innerHTML = `<option value="">No order</option>` + filtered.map(o =>
        `<option value="${o.id}">${escapeHtml(o.order_number)} — ${escapeHtml(o.service_name || '')}</option>`
    ).join('');
    if (selectedOrderId) orderSel.value = String(selectedOrderId);
}

async function onTaskAssociationChange(prefix, selectedCompanyId, selectedOrderId) {
    const clientId = document.getElementById(`${prefix}-task-client`)?.value;
    try {
        const assoc = await loadTaskAssociations(clientId);
        fillCompanyOrderSelects(prefix, assoc, selectedCompanyId, selectedOrderId);
    } catch (err) {
        showModalError(prefix === 'new' ? 'new-task-error' : 'edit-task-error', err.message);
    }
}

async function onTaskCompanyChange(prefix) {
    const clientId = document.getElementById(`${prefix}-task-client`)?.value;
    const companyId = document.getElementById(`${prefix}-task-company`)?.value;
    try {
        const assoc = await loadTaskAssociations(clientId);
        fillTaskOrderSelect(prefix, assoc.orders || [], companyId, '');
    } catch (err) {
        showModalError(prefix === 'new' ? 'new-task-error' : 'edit-task-error', err.message);
    }
}

function setAssociationFieldsEnabled(enabled) {
    ['edit-task-assignee', 'edit-task-client', 'edit-task-company', 'edit-task-order'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.disabled = !enabled;
    });
}

async function loadAdminTasks() {
    applyTaskUiPermissions();
    showTasksError('');
    const tbody = document.getElementById('adm-tasks-table-body');
    if (tbody) {
        tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#64748b; padding:28px;">Loading tasks...</td></tr>`;
    }

    try {
        await fetchTaskStaff();
        const deptFilter = document.getElementById('filter-task-department');
        const previousDept = deptFilter ? deptFilter.value : '';
        fillDepartmentSelect('filter-task-department', previousDept, 'All departments');
        const assigneeSel = document.getElementById('filter-task-assignee');
        const previousAssignee = assigneeSel ? assigneeSel.value : '';
        fillStaffSelect('filter-task-assignee', previousAssignee, 'All Assignees', previousDept);
        if (assigneeSel && previousAssignee) assigneeSel.value = previousAssignee;

        const params = new URLSearchParams();
        const status = document.getElementById('filter-task-status')?.value;
        const priority = document.getElementById('filter-task-priority')?.value;
        const department = document.getElementById('filter-task-department')?.value;
        const assignee = document.getElementById('filter-task-assignee')?.value;
        const due = document.getElementById('filter-task-due')?.value;
        if (status) params.set('status', status);
        if (priority) params.set('priority', priority);
        if (department) params.set('department', department);
        if (due) params.set('due', due);
        if (assignee && canAssignStaffTasks()) params.set('assigned_staff_id', assignee);

        const qs = params.toString();
        const res = await fetch(`/api/admin/tasks${qs ? '?' + qs : ''}`);
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load tasks.');
        }
        renderAdminTasks(data.tasks || []);
    } catch (err) {
        console.error(err);
        showTasksError(err.message || 'Unable to load tasks.');
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#dc2626; padding:28px;">Unable to load tasks. Please try again.</td></tr>`;
        }
    }
}

function renderAdminTasks(tasks) {
    const tbody = document.getElementById('adm-tasks-table-body');
    if (!tbody) return;
    if (!tasks.length) {
        tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#64748b; padding:36px;">No tasks found.</td></tr>`;
        lucide.createIcons();
        return;
    }
    tbody.innerHTML = tasks.map(t => {
        const canComplete = t.status !== 'Completed' && t.status !== 'Cancelled';
        return `
            <tr>
                <td style="font-weight:700;">${escapeHtml(t.title)}</td>
                <td>${t.department ? `<span class="dept-badge">${escapeHtml(t.department)}</span>` : '—'}</td>
                <td>${escapeHtml(t.assigned_staff_name || (t.department ? 'Department queue' : 'Unassigned'))}</td>
                <td>${escapeHtml(t.client_name || '—')}</td>
                <td style="font-weight:600; color:#7c3aed;">${escapeHtml(t.order_number || '—')}</td>
                <td><span class="status-badge ${taskPriorityClass(t.priority)}">${escapeHtml(t.priority)}</span></td>
                <td>${t.due_date ? formatDate(t.due_date) : '—'}</td>
                <td><span class="status-badge ${taskStatusClass(t.status)}">${escapeHtml(t.status)}</span></td>
                <td>
                    <button class="btn-primary" style="padding:4px 10px; font-size:0.75rem; margin-right:6px;" onclick="openEditTaskModal(${t.id})">Open</button>
                    ${canComplete ? `<button class="btn-secondary" style="padding:4px 10px; font-size:0.75rem;" onclick="completeAdminTask(${t.id})">Complete</button>` : ''}
                </td>
            </tr>
        `;
    }).join('');
    lucide.createIcons();
}

async function openNewTaskModal(prefillAssigneeId, prefillClientId, prefillOrderId) {
    if (!canAssignStaffTasks()) {
        alert('You do not have permission to create tasks.');
        return;
    }
    showModalError('new-task-error', '');
    const form = document.getElementById('new-task-form');
    if (form) form.reset();
    document.getElementById('new-task-priority').value = 'Medium';
    try {
        await Promise.all([fetchTaskStaff(), fetchTaskCustomers()]);
        fillDepartmentSelect('new-task-department', '', 'Select department');
        fillStaffSelect('new-task-assignee', prefillAssigneeId || '', 'Anyone in this department', '');
        fillClientSelect('new-task-client', prefillClientId || '');
        if (prefillClientId) {
            await onTaskAssociationChange('new');
            const orderSel = document.getElementById('new-task-order');
            if (orderSel && prefillOrderId) orderSel.value = String(prefillOrderId);
        } else {
            fillCompanyOrderSelects('new', { companies: [], orders: [] }, '', '');
        }
        document.getElementById('modal-new-task').classList.add('active');
        lucide.createIcons();
    } catch (err) {
        alert(err.message || 'Unable to open new task form.');
    }
}

function closeNewTaskModal() {
    const modal = document.getElementById('modal-new-task');
    if (modal) modal.classList.remove('active');
}

function collectTaskForm(prefix, includeStatus) {
    const payload = {
        title: document.getElementById(`${prefix}-task-title`).value.trim(),
        description: document.getElementById(`${prefix}-task-description`).value,
        priority: document.getElementById(`${prefix}-task-priority`).value,
        due_date: document.getElementById(`${prefix}-task-due`).value || null,
        department: document.getElementById(`${prefix}-task-department`)?.value || '',
        assigned_staff_id: optionalId(document.getElementById(`${prefix}-task-assignee`).value),
        client_id: optionalId(document.getElementById(`${prefix}-task-client`).value),
        company_id: optionalId(document.getElementById(`${prefix}-task-company`).value),
        order_id: optionalId(document.getElementById(`${prefix}-task-order`).value),
        internal_notes: document.getElementById(`${prefix}-task-notes`).value
    };
    if (includeStatus) {
        payload.status = document.getElementById('edit-task-status').value;
    }
    return payload;
}

async function submitNewTaskForm(e) {
    e.preventDefault();
    showModalError('new-task-error', '');
    const submitBtn = document.getElementById('new-task-submit');
    const payload = collectTaskForm('new', false);
    if (!payload.title) {
        showModalError('new-task-error', 'Title is required.');
        return;
    }
    if (submitBtn) submitBtn.disabled = true;
    try {
        const res = await fetch('/api/admin/tasks', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to create task.');
        }
        closeNewTaskModal();
        alert('Task created successfully.');
        loadAdminTasks();
        loadNotificationsCount();
    } catch (err) {
        showModalError('new-task-error', err.message || 'Unable to create task.');
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
}

async function openEditTaskModal(taskId) {
    showModalError('edit-task-error', '');
    try {
        const [taskRes] = await Promise.all([
            fetch(`/api/admin/tasks/${taskId}`),
            fetchTaskStaff(),
            fetchTaskCustomers()
        ]);
        const data = await taskRes.json();
        if (!taskRes.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load task.');
        }
        const t = data.task;
        document.getElementById('edit-task-id').value = t.id;
        document.getElementById('edit-task-heading').textContent = t.title;
        document.getElementById('edit-task-meta').textContent = t.created_by_name ? `Created by ${t.created_by_name}` : 'Internal staff task';
        document.getElementById('edit-task-title').value = t.title || '';
        document.getElementById('edit-task-description').value = t.description || '';
        document.getElementById('edit-task-priority').value = t.priority || 'Medium';
        document.getElementById('edit-task-status').value = t.status || 'Open';
        document.getElementById('edit-task-due').value = t.due_date ? String(t.due_date).slice(0, 10) : '';
        document.getElementById('edit-task-notes').value = t.internal_notes || '';
        fillDepartmentSelect('edit-task-department', t.department || '', 'Select department');
        fillStaffSelect('edit-task-assignee', t.assigned_staff_id, 'Anyone in this department', t.department || '');
        fillClientSelect('edit-task-client', t.client_id);
        await onTaskAssociationChange('edit', t.company_id, t.order_id);
        setAssociationFieldsEnabled(canAssignStaffTasks());
        const completeBtn = document.getElementById('edit-task-complete-btn');
        if (completeBtn) completeBtn.style.display = (t.status === 'Completed' || t.status === 'Cancelled') ? 'none' : 'inline-flex';
        document.getElementById('modal-edit-task').classList.add('active');
        lucide.createIcons();
    } catch (err) {
        alert(err.message || 'Unable to open task.');
    }
}

function closeEditTaskModal() {
    const modal = document.getElementById('modal-edit-task');
    if (modal) modal.classList.remove('active');
}

async function submitEditTaskForm(e) {
    e.preventDefault();
    showModalError('edit-task-error', '');
    const taskId = document.getElementById('edit-task-id').value;
    const submitBtn = document.getElementById('edit-task-submit');
    const payload = collectTaskForm('edit', true);
    if (!payload.title) {
        showModalError('edit-task-error', 'Title is required.');
        return;
    }
    if (!canAssignStaffTasks()) {
        delete payload.assigned_staff_id;
        delete payload.department;
        delete payload.client_id;
        delete payload.company_id;
        delete payload.order_id;
    }
    if (submitBtn) submitBtn.disabled = true;
    try {
        const res = await fetch(`/api/admin/tasks/${taskId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to update task.');
        }
        closeEditTaskModal();
        alert('Task updated successfully.');
        loadAdminTasks();
    } catch (err) {
        showModalError('edit-task-error', err.message || 'Unable to update task.');
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
}

async function completeAdminTask(taskId) {
    try {
        const res = await fetch(`/api/admin/tasks/${taskId}/complete`, { method: 'POST' });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to complete task.');
        }
        alert('Task marked complete.');
        closeEditTaskModal();
        loadAdminTasks();
        loadNotificationsCount();
    } catch (err) {
        alert(err.message || 'Unable to complete task.');
    }
}

async function completeTaskFromModal() {
    const taskId = document.getElementById('edit-task-id').value;
    if (taskId) await completeAdminTask(taskId);
}

function setTeamMessage(kind, message) {
    const errBox = document.getElementById('adm-team-error');
    const okBox = document.getElementById('adm-team-success');
    const flash = document.getElementById('app-flash-notice');
    if (errBox) {
        errBox.style.display = kind === 'error' && message ? 'block' : 'none';
        errBox.textContent = kind === 'error' ? (message || '') : '';
    }
    if (okBox) {
        okBox.style.display = kind === 'success' && message ? 'block' : 'none';
        okBox.textContent = kind === 'success' ? (message || '') : '';
    }
    if (flash) {
        flash.style.display = kind === 'success' && message ? 'block' : 'none';
        flash.textContent = kind === 'success' ? (message || '') : '';
    }
}

async function loadAdminTeam() {
    if (!canManageUsers()) {
        setTeamMessage('error', 'You do not have permission to manage users.');
        return;
    }
    syncCreateUserButtons();
    try {
        const res = await fetch('/api/admin/staff?include_inactive=1', { credentials: 'same-origin' });
        const data = await res.json();
        const tbody = document.getElementById('adm-team-table-body');
        if (!tbody) return;
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load team users.');
        }
        const staff = data.staff || [];
        tbody.innerHTML = staff.length ? staff.map(s => `
            <tr>
                <td style="font-weight:700;">${escapeHtml(s.full_name)}</td>
                <td>${escapeHtml(s.email)}</td>
                <td>${escapeHtml(s.role)}</td>
                <td class="team-dept-cell">${renderStaffAccessCell(s)}</td>
                <td><span class="status-badge ${s.status === 'Active' ? 'completed' : 'pending'}">${escapeHtml(s.status)}</span></td>
            </tr>
        `).join('') : '<tr><td colspan="5" style="color:#64748b;">No team users yet.</td></tr>';
        lucide.createIcons();
    } catch (err) {
        setTeamMessage('error', err.message || 'Unable to load team users.');
    }
}

function fillCreateUserRoleOptions() {
    const sel = document.getElementById('create-user-role');
    if (!sel) return;
    const allowed = creatableRolesFor(currentUser);
    const allowedSet = new Set(allowed);
    sel.innerHTML = ALL_USER_ROLES.map((role) => {
        const permitted = allowedSet.has(role);
        const disabled = permitted ? '' : ' disabled';
        const label = permitted ? role : `${role} (not permitted)`;
        return `<option value="${escapeHtml(role)}"${disabled}>${escapeHtml(label)}</option>`;
    }).join('');
    if (allowed.includes('STAFF')) sel.value = 'STAFF';
    else if (allowed.length) sel.value = allowed[0];
    fillCreateUserDepartments([]);
    syncCreateUserDepartmentField();
}

function renderStaffAccessCell(staff) {
    if (!staff || staff.role !== 'STAFF') {
        return '<span class="access-full-badge">Full access</span>';
    }
    return renderDeptMultiSelect(staff.id, staffDepartments(staff), staff.full_name);
}

function renderDeptMultiSelect(staffId, selected, staffName) {
    const chosen = selected || [];
    return `
        <div class="dept-inline" data-staff-id="${staffId}" aria-label="Access for ${escapeHtml(staffName || 'staff')}">
            ${STAFF_DEPARTMENTS.map((dept) => `
                <label class="dept-chip${chosen.includes(dept) ? ' is-on' : ''}">
                    <input type="checkbox" value="${escapeHtml(dept)}" ${chosen.includes(dept) ? 'checked' : ''} onchange="saveStaffDepartments(${staffId}, this.closest('.dept-inline'))">
                    <span>${escapeHtml(dept)}</span>
                </label>
            `).join('')}
        </div>
    `;
}

function fillCreateUserDepartments(selected) {
    const box = document.getElementById('create-user-departments');
    if (!box) return;
    const chosen = selected || [];
    box.innerHTML = STAFF_DEPARTMENTS.map((dept) => `
        <label>
            <input type="checkbox" value="${escapeHtml(dept)}" ${chosen.includes(dept) ? 'checked' : ''}>
            <span>${escapeHtml(dept)}</span>
        </label>
    `).join('');
}

function selectedCreateUserDepartments() {
    return Array.from(document.querySelectorAll('#create-user-departments input[type="checkbox"]:checked')).map((el) => el.value);
}

async function saveStaffDepartments(staffId, wrap) {
    const departments = wrap
        ? Array.from(wrap.querySelectorAll('input[type="checkbox"]:checked')).map((el) => el.value)
        : [];
    if (wrap) {
        wrap.querySelectorAll('.dept-chip').forEach((chip) => {
            const box = chip.querySelector('input[type="checkbox"]');
            chip.classList.toggle('is-on', !!(box && box.checked));
        });
    }
    try {
        const res = await fetch(`/api/admin/staff/${staffId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ departments })
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to update access.');
        }
        taskStaffCache = [];
    } catch (err) {
        alert(err.message || 'Unable to update access.');
        loadAdminTeam();
    }
}

function syncCreateUserDepartmentField() {
    const role = document.getElementById('create-user-role')?.value;
    const wrap = document.getElementById('create-user-department-wrap');
    if (wrap) wrap.style.display = role === 'STAFF' ? '' : 'none';
}

function openCreateUserModal() {
    if (!canManageUsers()) {
        alert('You do not have permission to create users.');
        return;
    }
    const form = document.getElementById('create-user-form');
    if (form) form.reset();
    const country = document.getElementById('create-user-country');
    if (country) country.value = 'United Kingdom';
    const statusSel = document.getElementById('create-user-status');
    if (statusSel) statusSel.value = 'Active';
    fillCreateUserRoleOptions();
    showModalError('create-user-error', '');
    const modal = document.getElementById('modal-create-user');
    if (modal) modal.classList.add('active');
    lucide.createIcons();
}

function closeCreateUserModal() {
    const modal = document.getElementById('modal-create-user');
    if (modal) modal.classList.remove('active');
    const form = document.getElementById('create-user-form');
    if (form) form.reset();
    const pass = document.getElementById('create-user-password');
    const confirm = document.getElementById('create-user-password-confirm');
    if (pass) pass.value = '';
    if (confirm) confirm.value = '';
    showModalError('create-user-error', '');
}

async function submitCreateUserForm(event) {
    if (event) event.preventDefault();
    if (!canManageUsers()) {
        showModalError('create-user-error', 'You do not have permission to create users.');
        return;
    }
    const password = document.getElementById('create-user-password').value;
    const confirm = document.getElementById('create-user-password-confirm').value;
    if (password !== confirm) {
        showModalError('create-user-error', 'Passwords do not match.');
        return;
    }
    const submitBtn = document.getElementById('create-user-submit');
    if (submitBtn) submitBtn.disabled = true;
    showModalError('create-user-error', '');
    const payload = {
        full_name: document.getElementById('create-user-name').value.trim(),
        email: document.getElementById('create-user-email').value.trim(),
        phone: document.getElementById('create-user-phone').value.trim(),
        country: document.getElementById('create-user-country').value.trim(),
        role: document.getElementById('create-user-role').value,
        departments: document.getElementById('create-user-role').value === 'STAFF' ? selectedCreateUserDepartments() : [],
        status: document.getElementById('create-user-status').value,
        password,
        confirm_password: confirm
    };
    if (!creatableRolesFor(currentUser).includes(payload.role)) {
        showModalError('create-user-error', 'You cannot assign that role.');
        if (submitBtn) submitBtn.disabled = false;
        return;
    }
    try {
        const res = await fetch('/api/admin/staff', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to create user.');
        }
        const created = data.user || {};
        closeCreateUserModal();
        const successMsg = `${created.full_name || 'User'} can sign in with ${created.email || 'their email'} and the password you set.`;
        setTeamMessage('success', successMsg);
        taskStaffCache = [];
        if (created.role && created.role !== 'CLIENT') {
            await loadAdminTeam();
        }
        if (created.role === 'CLIENT' || activeView === 'admin-customers') {
            await loadAdminCustomers();
        }
        if (activeView === 'admin-team' && created.role === 'CLIENT') {
            await loadAdminTeam();
        }
        if (activeView === 'admin-tasks') {
            await loadAdminTasks();
        }
    } catch (err) {
        showModalError('create-user-error', err.message || 'Unable to create user.');
    } finally {
        if (submitBtn) submitBtn.disabled = false;
        lucide.createIcons();
    }
}

async function submitNewTeamUser(event) {
    return submitCreateUserForm(event);
}

let adminCustomersCache = [];

function customerSignupSource(customer) {
    return customer && customer.wordpress_user_id ? 'website' : 'crm';
}

function customerSignupAgeDays(customer) {
    if (!customer || !customer.created_at) return null;
    const created = new Date(String(customer.created_at).replace(' ', 'T'));
    if (Number.isNaN(created.getTime())) return null;
    return (Date.now() - created.getTime()) / 86400000;
}

function renderAdminCustomers() {
    const tbody = document.getElementById('adm-customers-table-body');
    const countEl = document.getElementById('adm-customers-count');
    if (!tbody) return;
    const search = (document.getElementById('filter-admin-customer-search')?.value || '').trim().toLowerCase();
    const source = document.getElementById('filter-admin-customer-source')?.value || '';
    const ageDays = parseInt(document.getElementById('filter-admin-customer-age')?.value || '', 10);
    const rows = adminCustomersCache.filter((c) => {
        if (search) {
            const hay = `${c.full_name || ''} ${c.email || ''}`.toLowerCase();
            if (!hay.includes(search)) return false;
        }
        if (source && customerSignupSource(c) !== source) return false;
        if (ageDays) {
            const age = customerSignupAgeDays(c);
            if (age == null || age > ageDays) return false;
        }
        return true;
    });
    if (countEl) {
        countEl.textContent = `${rows.length} of ${adminCustomersCache.length} accounts`;
    }
    if (!rows.length) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:#64748b; padding:28px;">No customer signups match the current filters.</td></tr>`;
        return;
    }
    tbody.innerHTML = rows.map((c) => {
        const sourceKey = customerSignupSource(c);
        const age = customerSignupAgeDays(c);
        const isNew = age != null && age <= 7;
        const sourceLabel = sourceKey === 'website' ? 'Website signup' : 'Created in CRM';
        return `
            <tr>
                <td style="font-weight:700;">${escapeHtml(c.full_name || '')}${isNew ? ' <span class="signup-new-badge">New</span>' : ''}</td>
                <td>${escapeHtml(c.email || '')}</td>
                <td>${escapeHtml(formatDateTime(c.created_at) || formatDate(c.created_at) || '—')}</td>
                <td>${escapeHtml(sourceLabel)}</td>
                <td>${c.companies_count ?? 0}</td>
                <td>${c.orders_count ?? 0}</td>
                <td><span class="status-badge completed">${escapeHtml(c.status || '')}</span></td>
                <td>
                    <button type="button" class="btn-primary" style="padding:4px 10px; font-size:0.75rem;" onclick="openCrmClientModal(${c.id})">View CRM Profile</button>
                </td>
            </tr>
        `;
    }).join('');
}

function filterAdminCustomers() {
    renderAdminCustomers();
}

async function loadAdminCustomers() {
    const tbody = document.getElementById('adm-customers-table-body');
    try {
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:#64748b; padding:28px;">Loading signups…</td></tr>`;
        }
        const res = await fetch('/api/admin/customers', { credentials: 'same-origin' });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load customers.');
        }
        adminCustomersCache = data.customers || [];
        renderAdminCustomers();
    } catch (err) {
        adminCustomersCache = [];
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:#dc2626; padding:28px;">${escapeHtml(err.message || 'Unable to load customers.')}</td></tr>`;
        }
    }
}

// ----------------------------------------------------
// CENTRALIZED CLIENT CRM RECORD MODAL HANDLERS
// ----------------------------------------------------
let currentCrmClientData = null;

async function openCrmClientModal(clientId) {
    try {
        const res = await fetch(`/api/admin/clients/${clientId}/full`);
        const data = await res.json();
        if (data.status === 'success') {
            currentCrmClientData = data;
            const c = data.client;
            
            document.getElementById('crm-modal-name').textContent = c.full_name;
            document.getElementById('crm-modal-meta').textContent = `WP User ID: ${c.wordpress_user_id || 'N/A'} | ${c.email}`;
            document.getElementById('crm-modal-avatar').textContent = c.full_name.split(' ').map(n => n[0]).join('');
            
            document.getElementById('crm-ov-email').textContent = c.email;
            document.getElementById('crm-ov-phone').textContent = c.phone || 'N/A';
            document.getElementById('crm-ov-country').textContent = c.country || 'United Kingdom';
            document.getElementById('crm-ov-status').textContent = c.status;
            document.getElementById('crm-ov-synced').textContent = c.last_synced_at ? `Synced (${c.last_synced_at})` : 'Not synced';
            document.getElementById('crm-ov-address').textContent = c.address || 'N/A';
            
            // Populate Companies tab
            const compBox = document.getElementById('crm-companies-list');
            compBox.innerHTML = data.companies.length ? data.companies.map(comp => `
                <div style="padding:10px; border:1px solid #e2e8f0; border-radius:8px; margin-bottom:8px;">
                    <strong>${comp.name}</strong> (#${comp.company_number}) • ${comp.package}
                    <div style="font-size:0.78rem; color:#64748b;">Office: ${comp.reg_office} | Status: ${comp.status}</div>
                </div>
            `).join('') : '<p style="color:#64748b;">No registered companies for this client.</p>';
            
            // Populate Orders tab
            const ordBox = document.getElementById('crm-orders-list');
            ordBox.innerHTML = data.orders.length ? data.orders.map(o => `
                <div style="padding:10px; border:1px solid #e2e8f0; border-radius:8px; margin-bottom:8px; display:flex; justify-content:space-between; gap:8px; align-items:center;">
                    <div>
                        <strong>${escapeHtml(o.order_number)}</strong> — ${escapeHtml(o.service_name)} (£${parseFloat(o.total).toFixed(2)})
                        <div style="font-size:0.78rem; color:#64748b;">${escapeHtml(formatDate(o.created_at))} · ${escapeHtml(o.status)} · ${o.progress_percent}%</div>
                    </div>
                    <div style="display:flex; gap:6px; flex-wrap:wrap;">
                        ${canUploadClientDocuments() ? `<button type="button" class="btn-secondary" style="padding:4px 10px; font-size:0.75rem;" onclick="openDeliverDocumentModal({orderId:${o.id}, companyId:${o.company_id || 'null'}})">Upload Document</button>` : ''}
                        <button type="button" class="btn-primary" style="padding:4px 10px; font-size:0.75rem;" onclick="closeCrmClientModal(); openStaffOrderWorkspace(${o.id})">Process</button>
                    </div>
                </div>
            `).join('') : '<p style="color:#64748b;">No order history available.</p>';
            
            // Populate Invoices tab
            const invBox = document.getElementById('crm-invoices-list');
            invBox.innerHTML = data.invoices.length ? data.invoices.map(inv => `
                <div style="padding:10px; border:1px solid #e2e8f0; border-radius:8px; margin-bottom:8px;">
                    <strong>${inv.invoice_number}</strong> — £${parseFloat(inv.total).toFixed(2)} (${inv.status})
                </div>
            `).join('') : '<p style="color:#64748b;">No invoices available.</p>';
            
            renderCrmDocumentsList(data.documents || []);
            const uploadBtn = document.getElementById('crm-upload-document-btn');
            if (uploadBtn) uploadBtn.style.display = canUploadClientDocuments() ? 'inline-flex' : 'none';
            
            // Populate Support tab
            const suppBox = document.getElementById('crm-support-list');
            suppBox.innerHTML = data.support_tickets.length ? data.support_tickets.map(t => `
                <div style="padding:10px; border:1px solid #e2e8f0; border-radius:8px; margin-bottom:8px;">
                    <strong>Ticket #${t.ticket_number}</strong>: ${t.subject} (${t.status})
                </div>
            `).join('') : '<p style="color:#64748b;">No support tickets filed.</p>';

            // Populate Activity Logs tab
            const logBox = document.getElementById('crm-logs-list');
            logBox.innerHTML = data.activity_logs.length ? data.activity_logs.map(lg => `
                <div style="padding:8px; border-bottom:1px solid #f1f5f9; font-size:0.8rem;">
                    <strong>${lg.action}</strong> • <span style="color:#64748b;">${formatDate(lg.created_at)}</span>
                    <div style="color:#475569;">${lg.details || ''}</div>
                </div>
            `).join('') : '<p style="color:#64748b;">No audit trail recorded.</p>';

            switchCrmTab('overview');
            document.getElementById('crm-client-modal').classList.add('active');
        }
    } catch (err) { console.error(err); }
}

function switchCrmTab(tabName) {
    const tabs = ['overview', 'companies', 'orders', 'invoices', 'documents', 'support', 'logs'];
    tabs.forEach(t => {
        const btn = document.getElementById(`crm-tab-${t}`);
        const pane = document.getElementById(`crm-tab-content-${t}`);
        if (btn) btn.classList.toggle('active', t === tabName);
        if (pane) pane.style.display = t === tabName ? 'block' : 'none';
    });
}

function closeCrmClientModal() {
    const modal = document.getElementById('crm-client-modal');
    if (modal) modal.classList.remove('active');
}

function setCrmDeliverStatus(message) {
    const box = document.getElementById('crm-deliver-doc-status');
    if (!box) return;
    if (!message) {
        box.style.display = 'none';
        box.textContent = '';
        return;
    }
    box.style.display = 'block';
    box.textContent = message;
}

function renderCrmDocumentsList(docs) {
    const docBox = document.getElementById('crm-documents-list');
    if (!docBox) return;
    const list = Array.isArray(docs) ? docs : [];
    if (!list.length) {
        docBox.innerHTML = '<p style="color:#64748b;">No documents uploaded.</p>';
        return;
    }
    const canReview = canUploadClientDocuments();
    docBox.innerHTML = list.map(doc => `
        <div style="padding:10px; border:1px solid #e2e8f0; border-radius:8px; margin-bottom:8px; display:flex; justify-content:space-between; gap:10px; align-items:flex-start;">
            <div>
                <strong>${escapeHtml(doc.name)}</strong>
                <div style="font-size:0.78rem; color:#64748b;">
                    ${escapeHtml(doc.category || '—')}
                    · ${escapeHtml(doc.order_number || 'No order')}
                    · ${escapeHtml(formatDate(doc.created_at))}
                    · ${escapeHtml(doc.uploaded_by || '—')}
                </div>
                <div style="margin-top:6px;"><span class="status-badge ${documentStatusClass(doc.status)}">${escapeHtml(doc.status || '—')}</span></div>
            </div>
            <div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                <a href="/api/documents/${doc.id}/download" target="_blank" class="btn-secondary" style="padding:4px 10px; font-size:0.75rem; text-decoration:none;">View</a>
                <a href="/api/documents/${doc.id}/download" class="btn-primary" style="padding:4px 10px; font-size:0.75rem; text-decoration:none;">Download</a>
                ${canReview ? `
                    <select class="select-filter" style="min-width:140px;" onchange="reviewCrmDocument(${doc.id}, this.value)">
                        <option value="Pending Review" ${doc.status === 'Pending Review' ? 'selected' : ''}>Pending Review</option>
                        <option value="Approved" ${doc.status === 'Approved' ? 'selected' : ''}>Approved</option>
                        <option value="Rejected" ${doc.status === 'Rejected' ? 'selected' : ''}>Rejected</option>
                        <option value="Requires Update" ${doc.status === 'Requires Update' ? 'selected' : ''}>Requires Update</option>
                    </select>
                ` : ''}
            </div>
        </div>
    `).join('');
}

async function refreshCrmClientDocuments() {
    if (!currentCrmClientData || !currentCrmClientData.client) return;
    const res = await fetch(`/api/admin/clients/${currentCrmClientData.client.id}/full`);
    const data = await res.json();
    if (!res.ok || data.status !== 'success') {
        throw new Error(data.message || 'Unable to refresh documents.');
    }
    currentCrmClientData = data;
    renderCrmDocumentsList(data.documents || []);
}

async function reviewCrmDocument(docId, status) {
    if (!canUploadClientDocuments()) return;
    try {
        const res = await fetch(`/api/admin/documents/${docId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify({ status })
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to update document status.');
        }
        await refreshCrmClientDocuments();
        setCrmDeliverStatus(data.message || 'Document status updated.');
    } catch (err) {
        alert(err.message || 'Unable to update document status.');
    }
}

let deliverDocClientId = null;
let deliverDocAssoc = { companies: [], orders: [] };

function showDeliverDocumentError(message) {
    const box = document.getElementById('deliver-document-error');
    if (!box) return;
    box.style.display = message ? 'block' : 'none';
    box.textContent = message || '';
}

function fillDeliverDocumentSelects(selectedCompanyId, selectedOrderId) {
    const companySel = document.getElementById('deliver-document-company');
    const orderSel = document.getElementById('deliver-document-order');
    const companies = deliverDocAssoc.companies || [];
    const orders = deliverDocAssoc.orders || [];
    if (companySel) {
        companySel.innerHTML = `<option value="">No company</option>` + companies.map(c =>
            `<option value="${c.id}">${escapeHtml(c.name)}</option>`
        ).join('');
        if (selectedCompanyId) companySel.value = String(selectedCompanyId);
    }
    const companyId = companySel ? companySel.value : '';
    const filtered = companyId
        ? orders.filter(o => !o.company_id || String(o.company_id) === String(companyId))
        : orders;
    if (orderSel) {
        orderSel.innerHTML = `<option value="">No order</option>` + filtered.map(o =>
            `<option value="${o.id}">${escapeHtml(o.order_number)} — ${escapeHtml(o.service_name || '')}</option>`
        ).join('');
        if (selectedOrderId) orderSel.value = String(selectedOrderId);
    }
}

function onDeliverDocumentCompanyChange() {
    fillDeliverDocumentSelects(document.getElementById('deliver-document-company')?.value || '', '');
}

async function loadDeliverDocumentAssociations(clientId) {
    if (currentCrmClientData && currentCrmClientData.client && String(currentCrmClientData.client.id) === String(clientId)) {
        return { companies: currentCrmClientData.companies || [], orders: currentCrmClientData.orders || [] };
    }
    const res = await fetch(`/api/admin/clients/${clientId}/full`);
    const data = await res.json();
    if (!res.ok || data.status !== 'success') {
        throw new Error(data.message || 'Unable to load customer companies and orders.');
    }
    return { companies: data.companies || [], orders: data.orders || [], client: data.client };
}

function setDeliverDocumentClientMode(pickClient) {
    const locked = document.getElementById('deliver-document-client-locked');
    const pick = document.getElementById('deliver-document-client-pick');
    if (locked) locked.style.display = pickClient ? 'none' : 'block';
    if (pick) pick.style.display = pickClient ? 'block' : 'none';
}

function onDeliverDocumentFileChange() {
    const fileInput = document.getElementById('deliver-document-file');
    const nameInput = document.getElementById('deliver-document-name');
    const file = fileInput && fileInput.files ? fileInput.files[0] : null;
    if (!file || !nameInput || nameInput.value.trim()) return;
    nameInput.value = file.name.replace(/\.[^.]+$/, '') || file.name;
}

async function onDeliverDocumentClientChange() {
    const select = document.getElementById('deliver-document-client-select');
    const clientId = select ? select.value : '';
    showDeliverDocumentError('');
    if (!clientId) {
        deliverDocClientId = null;
        deliverDocAssoc = { companies: [], orders: [] };
        fillDeliverDocumentSelects('', '');
        return;
    }
    try {
        const assoc = await loadDeliverDocumentAssociations(clientId);
        deliverDocClientId = Number(clientId);
        deliverDocAssoc = { companies: assoc.companies || [], orders: assoc.orders || [] };
        fillDeliverDocumentSelects('', '');
    } catch (err) {
        deliverDocClientId = null;
        showDeliverDocumentError(err.message || 'Unable to load this customer.');
    }
}

async function openDeliverDocumentModalFromReview() {
    if (!canUploadClientDocuments()) {
        alert('You do not have permission to upload documents.');
        return;
    }
    await openDeliverDocumentModal({ pickClient: true });
}

async function openDeliverDocumentModal(prefill) {
    if (!canUploadClientDocuments()) {
        alert('You do not have permission to upload documents.');
        return;
    }
    const options = prefill || {};
    const client = (currentCrmClientData && currentCrmClientData.client) || null;
    const clientId = options.clientId || (client && client.id);
    showDeliverDocumentError('');
    const form = document.getElementById('deliver-document-form');
    if (form) form.reset();
    const pickSelect = document.getElementById('deliver-document-client-select');
    try {
        if (options.pickClient) {
            setDeliverDocumentClientMode(true);
            deliverDocClientId = null;
            deliverDocAssoc = { companies: [], orders: [] };
            fillDeliverDocumentSelects('', '');
            const customers = await fetchTaskCustomers();
            if (pickSelect) {
                pickSelect.innerHTML = `<option value="">Select a customer</option>` + (customers || []).map((c) =>
                    `<option value="${c.id}">${escapeHtml(c.full_name || 'Customer')}${c.email ? ' (' + escapeHtml(c.email) + ')' : ''}</option>`
                ).join('');
            }
            document.getElementById('modal-deliver-document').classList.add('active');
            safeCreateIcons();
            return;
        }
        if (!clientId) {
            alert('Open a customer record or choose a customer first.');
            return;
        }
        setDeliverDocumentClientMode(false);
        if (pickSelect) pickSelect.innerHTML = `<option value="">Select a customer</option>`;
        const assoc = await loadDeliverDocumentAssociations(clientId);
        deliverDocClientId = clientId;
        deliverDocAssoc = { companies: assoc.companies || [], orders: assoc.orders || [] };
        const label = document.getElementById('deliver-document-client');
        const clientName = (assoc.client && assoc.client.full_name) || (client && client.full_name) || 'Customer';
        const clientEmail = (assoc.client && assoc.client.email) || (client && client.email) || '';
        if (label) label.value = clientEmail ? `${clientName} (${clientEmail})` : clientName;
        fillDeliverDocumentSelects(options.companyId || '', options.orderId || '');
        document.getElementById('modal-deliver-document').classList.add('active');
        safeCreateIcons();
    } catch (err) {
        alert(err.message || 'Unable to open upload form.');
    }
}

function openDeliverDocumentModalFromOrder() {
    if (!canOperateOrderDocuments()) {
        setStaffOrderNotice('error', 'You do not have permission to upload documents.');
        return;
    }
    if (!staffOrderClientId) {
        setStaffOrderNotice('error', 'This order has no linked customer, so a document cannot be saved.');
        return;
    }
    openDeliverDocumentModal({
        clientId: staffOrderClientId,
        companyId: staffOrderCompanyId,
        orderId: staffOrderId
    });
}

function closeDeliverDocumentModal() {
    const modal = document.getElementById('modal-deliver-document');
    if (modal) modal.classList.remove('active');
}

function readFileAsBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
        reader.onerror = () => reject(new Error('Unable to read the selected file.'));
        reader.readAsDataURL(file);
    });
}

function formatDeliverSuccess(data) {
    const lines = ['Document uploaded successfully.'];
    lines.push('✓ Document uploaded');
    if (data.notification_created) lines.push('✓ Client notification created');
    if (data.email_sent) {
        lines.push('✓ Email notification sent');
    } else if (data.email_status) {
        lines.push(`Email notification logged (${data.email_status}).`);
    }
    return lines.join('\n');
}

async function submitDeliverDocumentForm(event) {
    event.preventDefault();
    if (!canUploadClientDocuments()) return;
    if (!deliverDocClientId) {
        showDeliverDocumentError('Select a customer first.');
        return;
    }
    showDeliverDocumentError('');
    const nameInput = document.getElementById('deliver-document-name');
    const fileInput = document.getElementById('deliver-document-file');
    const name = nameInput ? nameInput.value.trim() : '';
    const file = fileInput && fileInput.files ? fileInput.files[0] : null;
    if (!name) {
        showDeliverDocumentError('Document name is required.');
        return;
    }
    if (!file) {
        showDeliverDocumentError('Choose a file to upload.');
        return;
    }
    const submitBtn = document.getElementById('deliver-document-submit');
    if (submitBtn) submitBtn.disabled = true;
    try {
        const b64 = await readFileAsBase64(file);
        const payload = {
            client_id: deliverDocClientId,
            name,
            category: document.getElementById('deliver-document-category')?.value || 'Order Documents',
            client_message: document.getElementById('deliver-document-message')?.value || '',
            file_content_base64: b64
        };
        const companyId = document.getElementById('deliver-document-company')?.value;
        const orderId = document.getElementById('deliver-document-order')?.value;
        if (companyId) payload.company_id = Number(companyId);
        if (orderId) payload.order_id = Number(orderId);
        const res = await fetch('/api/admin/documents', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Upload failed.');
        }
        closeDeliverDocumentModal();
        const statusText = formatDeliverSuccess(data);
        setCrmDeliverStatus(statusText.replace(/\n/g, ' '));
        if (currentCrmClientData && currentCrmClientData.client && String(currentCrmClientData.client.id) === String(deliverDocClientId)) {
            await refreshCrmClientDocuments();
            switchCrmTab('documents');
        }
        if (staffOrderId) {
            setStaffOrderNotice('success', statusText.replace(/\n/g, ' '));
            await openStaffOrderWorkspace(staffOrderId);
        }
        if (typeof loadAdminDocuments === 'function') loadAdminDocuments();
        loadNotificationsCount();
    } catch (err) {
        showDeliverDocumentError(err.message || 'Upload failed.');
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
}

async function loadAdminDocuments() {
    const tbody = document.getElementById('adm-documents-table-body');
    const errBox = document.getElementById('adm-documents-error');
    if (errBox) {
        errBox.style.display = 'none';
        errBox.textContent = '';
    }
    if (tbody) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#64748b; padding:28px;">Loading documents…</td></tr>`;
    }
    try {
        const res = await fetch('/api/admin/documents', { credentials: 'same-origin' });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.status !== 'success') {
            throw new Error('Unable to load documents.');
        }
        const docs = Array.isArray(data.documents) ? data.documents : [];
        if (!tbody) return;
        if (!docs.length) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:36px 20px;">
                <div style="font-weight:800; color:#0f172a; margin-bottom:8px;">No files uploaded yet</div>
                <div style="color:#64748b; font-size:0.85rem; max-width:440px; margin:0 auto 16px;">Website order products such as Apostilled Documents Service are not files. Upload a PDF or image here to see it in this list.</div>
                <button type="button" class="btn-primary" onclick="openDeliverDocumentModalFromReview()">Upload Document</button>
            </td></tr>`;
            return;
        }
        tbody.innerHTML = docs.map(d => {
            const pending = d.status === 'Pending Review' || d.status === 'Requires Update';
            return `
                <tr>
                    <td>${escapeHtml(d.client_name || '—')}<div style="font-size:0.72rem; color:#64748b;">${escapeHtml(d.client_email || '')}</div></td>
                    <td>${escapeHtml(d.order_number || '—')}</td>
                    <td style="font-weight:700;">${escapeHtml(d.name || 'Document')}</td>
                    <td>${escapeHtml(d.category || '—')}</td>
                    <td><span class="status-badge ${d.status === 'Approved' ? 'completed' : (d.status === 'Rejected' ? 'cancelled' : 'pending')}">${escapeHtml(d.status || '')}</span></td>
                    <td>
                        <div class="order-row-actions">
                            <a class="btn-secondary" style="padding:4px 10px; font-size:0.75rem; text-decoration:none;" href="/api/documents/${d.id}/download">View</a>
                            ${pending ? `<button type="button" class="btn-primary" style="padding:4px 10px; font-size:0.75rem;" onclick="approveDocument(${d.id})">Approve</button>` : ''}
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    } catch (err) {
        console.error(err);
        if (errBox) {
            errBox.style.display = 'block';
            errBox.textContent = 'Unable to load documents. Please try again.';
        }
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#dc2626; padding:28px;">Unable to load documents.</td></tr>`;
        }
    }
}

async function approveDocument(docId) {
    try {
        await fetch(`/api/admin/documents/${docId}`, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ status: 'Approved', review_notes: 'Verified compliance.' })
        });
        alert('Document approved and client notified.');
        loadAdminDocuments();
    } catch (err) { console.error(err); }
}

async function loadAdminLogs() {
    try {
        const res = await fetch('/api/admin/activity-logs');
        const data = await res.json();
        const tbody = document.getElementById('adm-logs-table-body');
        if (tbody && data.status === 'success') {
            tbody.innerHTML = data.logs.map(l => `
                <tr>
                    <td>${formatDate(l.created_at)}</td>
                    <td style="font-weight:700; color:#7c3aed;">${l.user_email}</td>
                    <td><code>${l.action}</code></td>
                    <td>${l.details}</td>
                </tr>
            `).join('');
        }
    } catch (err) { console.error(err); }
}

async function loadAdminServices() {
    const tbody = document.getElementById('adm-services-table-body');
    const errBox = document.getElementById('adm-services-error');
    const addBtn = document.getElementById('btn-admin-add-service');
    if (addBtn) addBtn.style.display = canManageServiceCatalog() ? 'inline-flex' : 'none';
    if (errBox) {
        errBox.style.display = 'none';
        errBox.textContent = '';
    }
    if (tbody) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:28px;">Loading services…</td></tr>`;
    }
    try {
        const res = await fetch('/api/admin/services', { credentials: 'same-origin' });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load services.');
        }
        const services = Array.isArray(data.services) ? data.services : [];
        if (!tbody) return;
        if (!services.length) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:36px 20px;">
                <div style="font-weight:800; color:#0f172a; margin-bottom:8px;">No services in the CRM catalog yet</div>
                <div style="color:#64748b; font-size:0.85rem; max-width:440px; margin:0 auto 16px;">Website products still show on orders. Add a service here to list it in the CRM catalog.</div>
                ${canManageServiceCatalog() ? '<button type="button" class="btn-primary" onclick="openCreateServiceModal()">Add Service</button>' : ''}
            </td></tr>`;
            return;
        }
        tbody.innerHTML = services.map((s) => `
            <tr>
                <td><strong>${escapeHtml(s.name || 'Service')}</strong><div style="font-size:0.75rem; color:#64748b;">${escapeHtml(s.description || '')}</div></td>
                <td>${escapeHtml(s.category || '—')}</td>
                <td>£${parseFloat(s.price || 0).toFixed(2)}</td>
                <td>${escapeHtml(s.duration || '—')}</td>
                <td><span class="status-badge ${s.status === 'Active' ? 'completed' : 'pending'}">${escapeHtml(s.status || '')}</span></td>
            </tr>
        `).join('');
    } catch (err) {
        console.error(err);
        if (errBox) {
            errBox.style.display = 'block';
            errBox.textContent = err.message || 'Unable to load services.';
        }
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#dc2626; padding:28px;">Unable to load services.</td></tr>`;
        }
    }
}

function openCreateServiceModal() {
    if (!canManageServiceCatalog()) return;
    const err = document.getElementById('create-service-error');
    if (err) {
        err.style.display = 'none';
        err.textContent = '';
    }
    const form = document.getElementById('create-service-form');
    if (form) form.reset();
    const cat = document.getElementById('create-service-category');
    if (cat && !cat.value) cat.value = 'Corporate';
    const dur = document.getElementById('create-service-duration');
    if (dur && !dur.value) dur.value = '12 Months';
    const modal = document.getElementById('modal-create-service');
    if (modal) modal.classList.add('active');
    safeCreateIcons();
}

function closeCreateServiceModal() {
    const modal = document.getElementById('modal-create-service');
    if (modal) modal.classList.remove('active');
}

async function submitCreateServiceForm(event) {
    event.preventDefault();
    if (!canManageServiceCatalog()) return;
    const err = document.getElementById('create-service-error');
    if (err) {
        err.style.display = 'none';
        err.textContent = '';
    }
    const payload = {
        name: document.getElementById('create-service-name')?.value.trim() || '',
        category: document.getElementById('create-service-category')?.value.trim() || 'Corporate',
        description: document.getElementById('create-service-description')?.value.trim() || '',
        price: document.getElementById('create-service-price')?.value,
        duration: document.getElementById('create-service-duration')?.value.trim() || '12 Months'
    };
    const submitBtn = document.getElementById('create-service-submit');
    if (submitBtn) submitBtn.disabled = true;
    try {
        const res = await fetch('/api/admin/services', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to create service.');
        }
        closeCreateServiceModal();
        await loadAdminServices();
    } catch (ex) {
        if (err) {
            err.style.display = 'block';
            err.textContent = ex.message || 'Unable to create service.';
        }
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
}

async function loadAdminInvoices() {
    const tbody = document.getElementById('adm-invoices-table-body');
    const errBox = document.getElementById('adm-invoices-error');
    if (errBox) {
        errBox.style.display = 'none';
        errBox.textContent = '';
    }
    if (tbody) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#64748b; padding:28px;">Loading invoices…</td></tr>`;
    }
    try {
        const res = await fetch('/api/admin/invoices', { credentials: 'same-origin' });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load invoices.');
        }
        const invoices = Array.isArray(data.invoices) ? data.invoices : [];
        if (!tbody) return;
        if (!invoices.length) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#64748b; padding:28px;">No invoices yet.</td></tr>`;
            return;
        }
        tbody.innerHTML = invoices.map((inv) => `
            <tr>
                <td style="font-weight:700;">${escapeHtml(inv.invoice_number || '—')}</td>
                <td>${escapeHtml(inv.client_name || '—')}<div style="font-size:0.72rem; color:#64748b;">${escapeHtml(inv.client_email || '')}</div></td>
                <td>${escapeHtml(inv.order_number || '—')}</td>
                <td>£${parseFloat(inv.total || 0).toFixed(2)}</td>
                <td><span class="status-badge ${inv.status === 'Paid' ? 'completed' : (inv.status === 'Overdue' ? 'cancelled' : 'pending')}">${escapeHtml(inv.status || '')}</span></td>
                <td>${escapeHtml(formatDate(inv.created_at))}</td>
            </tr>
        `).join('');
    } catch (err) {
        console.error(err);
        if (errBox) {
            errBox.style.display = 'block';
            errBox.textContent = err.message || 'Unable to load invoices.';
        }
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#dc2626; padding:28px;">Unable to load invoices.</td></tr>`;
        }
    }
}

async function loadAdminSettings() {
    try {
        const res = await fetch('/api/settings');
        const data = await res.json();
        if (data.status === 'success') {
            const s = data.settings;
            if (s.company_name) document.getElementById('set-company-name').value = s.company_name;
            if (s.support_email) document.getElementById('set-support-email').value = s.support_email;
            if (s.currency) document.getElementById('set-currency').value = s.currency;
            if (s.order_prefix) document.getElementById('set-order-prefix').value = s.order_prefix;
        }
    } catch (err) { console.error(err); }
}

async function saveAdminSettings(e) {
    e.preventDefault();
    const company_name = document.getElementById('set-company-name').value;
    const support_email = document.getElementById('set-support-email').value;
    const currency = document.getElementById('set-currency').value;
    const order_prefix = document.getElementById('set-order-prefix').value;
    
    try {
        await fetch('/api/admin/settings', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ company_name, support_email, currency, order_prefix })
        });
        alert('Admin settings saved! Branding updated.');
        document.querySelectorAll('.brand-name-display').forEach(el => el.textContent = company_name);
    } catch (err) { console.error(err); }
}

// ----------------------------------------------------
// UTILITIES & NOTIFICATIONS
// ----------------------------------------------------
function isStaffTaskNotification(note) {
    const type = String(note && note.type ? note.type : '').toLowerCase();
    return type === 'task_assigned' || type === 'task_completed' || type.startsWith('task');
}

function visibleNotificationsForUser(notes) {
    const list = Array.isArray(notes) ? notes : [];
    if (currentUser && currentUser.role === 'CLIENT') {
        return list.filter(n => !isStaffTaskNotification(n));
    }
    return list;
}

function setUnreadBadge(count) {
    const badge = document.getElementById('header-unread-count');
    if (!badge) return;
    const n = Number(count) || 0;
    badge.textContent = n > 99 ? '99+' : String(n);
    badge.style.display = n > 0 ? 'flex' : 'none';
}

async function loadNotificationsCount() {
    try {
        const res = await fetch('/api/client/notifications');
        const data = await res.json();
        if (data.status === 'success') {
            const visible = visibleNotificationsForUser(data.notifications || []);
            const unread = visible.filter(n => !n.is_read).length;
            setUnreadBadge(unread);
        }
    } catch (err) { console.error(err); }
}

function closeNotificationsDropdown() {
    const dropdown = document.getElementById('notifications-dropdown');
    if (dropdown) dropdown.style.display = 'none';
    notificationsOpen = false;
}

async function toggleNotificationsModal(event) {
    if (event) event.stopPropagation();
    const dropdown = document.getElementById('notifications-dropdown');
    if (!dropdown) return;
    if (notificationsOpen) {
        closeNotificationsDropdown();
        return;
    }
    await openNotificationsDropdown();
}

async function openNotificationsDropdown() {
    const dropdown = document.getElementById('notifications-dropdown');
    const list = document.getElementById('notifications-list');
    if (!dropdown || !list) return;
    notificationsOpen = true;
    dropdown.style.display = 'block';
    list.innerHTML = `<div style="padding:20px 14px; text-align:center; color:#64748b; font-size:0.82rem;">Loading notifications...</div>`;
    try {
        const res = await fetch('/api/client/notifications');
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to load notifications.');
        }
        lastNotifications = visibleNotificationsForUser(data.notifications || []);
        renderNotificationsList(lastNotifications);
        const unread = lastNotifications.filter(n => !n.is_read).length;
        setUnreadBadge(unread);
    } catch (err) {
        list.innerHTML = `<div style="padding:16px 14px; color:#dc2626; font-size:0.82rem; font-weight:600;">${escapeHtml(err.message || 'Unable to load notifications.')}</div>`;
    }
}

function renderNotificationsList(notes) {
    const list = document.getElementById('notifications-list');
    if (!list) return;
    if (!notes.length) {
        list.innerHTML = `<div style="padding:28px 14px; text-align:center; color:#64748b; font-size:0.82rem;">No notifications.</div>`;
        return;
    }
    list.innerHTML = notes.map((n, idx) => {
        const unread = !n.is_read;
        return `
            <button type="button" data-note-idx="${idx}" onclick="handleNotificationItemClick(${idx})" style="display:block; width:100%; text-align:left; border:0; border-bottom:1px solid #f1f5f9; background:${unread ? '#f8fafc' : '#ffffff'}; padding:12px 14px; cursor:pointer;">
                <div style="font-size:0.82rem; font-weight:700; color:#0f172a;">${escapeHtml(n.title || 'Notification')}</div>
                <div style="font-size:0.78rem; color:#64748b; margin-top:4px;">${escapeHtml(n.message || '')}</div>
                <div style="font-size:0.72rem; color:#94a3b8; margin-top:6px;">${escapeHtml(formatDateTime(n.created_at))}</div>
            </button>
        `;
    }).join('');
}

function resolveNotificationView(note) {
    if (!note) return null;
    if (isStaffTaskNotification(note)) {
        if (currentUser && currentUser.role === 'CLIENT') return null;
        return isAdminShellUser(currentUser) ? 'admin-tasks' : null;
    }
    const raw = String(note.link || '').replace(/^#/, '').replace(/^\//, '');
    if (isAdminShellUser(currentUser)) {
        if (raw === 'admin-tasks' || raw.includes('admin-tasks')) return 'admin-tasks';
        if (raw === 'orders' || raw === 'admin-orders') return 'admin-orders';
        if (raw === 'documents' || raw === 'admin-documents') return 'admin-documents';
        if (raw.startsWith('admin-')) return raw;
        return null;
    }
    if (raw === 'orders' || raw === 'client-orders') return 'client-orders';
    if (raw === 'documents' || raw === 'client-documents') return 'client-documents';
    if (raw === 'invoices' || raw === 'client-invoices') return 'client-invoices';
    if (raw === 'dashboard' || raw === 'client-dashboard') return 'client-dashboard';
    return null;
}

function handleNotificationItemClick(idx) {
    const note = lastNotifications[idx];
    closeNotificationsDropdown();
    const view = resolveNotificationView(note);
    if (view) switchView(view);
}

async function markNotificationsRead(event) {
    if (event) event.stopPropagation();
    try {
        const res = await fetch('/api/client/notifications/read', { method: 'POST' });
        const data = await res.json();
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Unable to mark notifications read.');
        }
        lastNotifications = lastNotifications.map(n => ({ ...n, is_read: 1 }));
        renderNotificationsList(lastNotifications);
        setUnreadBadge(0);
    } catch (err) {
        const list = document.getElementById('notifications-list');
        if (list) {
            list.insertAdjacentHTML('afterbegin', `<div style="padding:10px 14px; color:#dc2626; font-size:0.78rem; font-weight:600;">${escapeHtml(err.message)}</div>`);
        }
    }
}

function formatDateTime(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function handleGlobalSearch(query) {
    if (activeView === 'client-orders') {
        resetClientOrdersPage();
        loadClientOrders();
    }
}

function formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}
