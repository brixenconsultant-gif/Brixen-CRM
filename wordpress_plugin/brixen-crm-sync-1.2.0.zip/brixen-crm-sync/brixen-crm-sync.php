<?php
/**
 * Plugin Name: Brixen Consultants CRM & WooCommerce Sync
 * Plugin URI: https://brixenconsultants.com
 * Description: Official integration plugin for Brixen Consultants connecting WordPress User Registration and WooCommerce Checkout to the Brixen CRM & Client Portal.
 * Version: 1.2.0
 * Author: Brixen Consultants Engineering Team
 * Author URI: https://brixenconsultants.com
 * License: Proprietary
 * Text Domain: brixen-crm-sync
 *
 * @package BrixenCRMSync
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

require_once plugin_dir_path(__FILE__) . 'class-brixen-webhook-sender.php';
require_once plugin_dir_path(__FILE__) . 'class-brixen-bulk-sync.php';
require_once plugin_dir_path(__FILE__) . 'class-brixen-client-documents.php';

class Brixen_CRM_Sync_Plugin {

    /**
     * Singleton instance.
     */
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // WordPress User Hooks
        add_action('user_register', array($this, 'on_user_registered'), 10, 1);
        add_action('profile_update', array($this, 'on_user_updated'), 10, 2);

        // WooCommerce Checkout & Order Hooks
        add_action('woocommerce_checkout_order_processed', array($this, 'on_order_created'), 10, 3);
        add_action('woocommerce_order_status_changed', array($this, 'on_order_status_changed'), 10, 4);
        add_action('woocommerce_payment_complete', array($this, 'on_payment_complete'), 10, 1);

        // WP Admin Menu & Settings
        add_action('admin_menu', array($this, 'register_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_post_brixen_sync_orders', array($this, 'handle_sync_orders'));

        // Shortcode for Client Portal SSO Login Button
        add_shortcode('brixen_client_portal_button', array($this, 'render_portal_sso_button'));

        // Messages & Files: show CRM posted documents on the website client panel
        Brixen_CRM_Client_Documents::init();
    }

    /**
     * Handle WordPress User Registration Event
     */
    public function on_user_registered($user_id) {
        $user = get_userdata($user_id);
        if (!$user) return;

        $data = array(
            'wordpress_user_id' => (string) $user_id,
            'email'             => $user->user_email,
            'first_name'        => get_user_meta($user_id, 'first_name', true),
            'last_name'         => get_user_meta($user_id, 'last_name', true),
            'full_name'         => $user->display_name ? $user->display_name : $user->user_email,
            'phone'             => get_user_meta($user_id, 'billing_phone', true),
            'country'           => get_user_meta($user_id, 'billing_country', true) ?: 'United Kingdom',
        );

        Brixen_CRM_Webhook_Sender::send_event('user.created', $data);
    }

    /**
     * Handle WordPress User Profile Update Event
     */
    public function on_user_updated($user_id, $old_user_data = null) {
        $user = get_userdata($user_id);
        if (!$user) return;

        $data = array(
            'wordpress_user_id' => (string) $user_id,
            'email'             => $user->user_email,
            'first_name'        => get_user_meta($user_id, 'first_name', true),
            'last_name'         => get_user_meta($user_id, 'last_name', true),
            'full_name'         => $user->display_name ? $user->display_name : $user->user_email,
            'phone'             => get_user_meta($user_id, 'billing_phone', true),
            'country'           => get_user_meta($user_id, 'billing_country', true) ?: 'United Kingdom',
        );

        Brixen_CRM_Webhook_Sender::send_event('user.updated', $data);
    }

    public static function extract_order_company_name($order) {
        $candidates = array();
        $billing = $order->get_billing_company();
        if ($billing) {
            $candidates[] = $billing;
        }
        if (method_exists($order, 'get_meta_data')) {
            foreach ($order->get_meta_data() as $meta_item) {
                $data = $meta_item->get_data();
                $key = strtolower((string) ($data['key'] ?? ''));
                $value = $data['value'] ?? '';
                if (!is_string($value) || !trim($value)) {
                    continue;
                }
                if (strpos($key, 'company') !== false || strpos($key, 'proposed') !== false || strpos($key, 'ltd') !== false) {
                    $candidates[] = trim($value);
                }
            }
        }
        foreach ($order->get_items() as $item) {
            foreach ($item->get_meta_data() as $meta_item) {
                $data = $meta_item->get_data();
                $key = strtolower((string) ($data['key'] ?? ''));
                $value = $data['value'] ?? '';
                if (!is_string($value) || !trim($value)) {
                    continue;
                }
                if (strpos($key, 'company') !== false || strpos($key, 'proposed') !== false || strpos($key, 'name') !== false) {
                    $candidates[] = trim($value);
                }
            }
        }
        foreach ($candidates as $name) {
            if ($name && strcasecmp($name, 'United Kingdom') !== 0) {
                return $name;
            }
        }
        return $billing ? $billing : '';
    }

    public static function build_order_payload($order) {
        $items = array();
        $item_names = array();
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $product_id = $item->get_product_id();
            $variation_id = $item->get_variation_id();
            $sku = ($product && method_exists($product, 'get_sku')) ? $product->get_sku() : '';
            $cats = array();
            if ($product_id && function_exists('get_the_terms')) {
                $terms = get_the_terms($product_id, 'product_cat');
                if ($terms && !is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        $cats[] = array(
                            'id'   => $term->term_id,
                            'name' => $term->name,
                        );
                    }
                }
            }
            $qty = (int) $item->get_quantity();
            $line_total = (float) $item->get_total();
            $unit_price = $qty > 0 ? round($line_total / $qty, 2) : $line_total;
            $name = $item->get_name();
            $item_names[] = $name;
            $item_meta = array();
            foreach ($item->get_meta_data() as $meta_item) {
                $meta = $meta_item->get_data();
                $key = (string) ($meta['key'] ?? '');
                $value = $meta['value'] ?? '';
                if ($key !== '' && is_scalar($value) && trim((string) $value) !== '') {
                    $item_meta[$key] = (string) $value;
                }
            }
            $items[] = array(
                'product_id'    => $product_id ? (string) $product_id : null,
                'variation_id'  => $variation_id ? (string) $variation_id : null,
                'sku'           => $sku,
                'product_name'  => $name,
                'quantity'      => $qty,
                'unit_price'    => $unit_price,
                'line_total'    => $line_total,
                'categories'    => $cats,
                'category'      => !empty($cats) ? $cats[0]['name'] : null,
                'category_id'   => !empty($cats) ? $cats[0]['id'] : null,
                'item_meta'     => $item_meta,
            );
        }
        $company_meta = array();
        if (method_exists($order, 'get_meta_data')) {
            foreach ($order->get_meta_data() as $meta_item) {
                $data = $meta_item->get_data();
                $key = (string) ($data['key'] ?? '');
                $value = $data['value'] ?? '';
                if ($key === '' || !is_scalar($value) || trim((string) $value) === '') {
                    continue;
                }
                $kl = strtolower($key);
                if (strpos($kl, 'company') !== false || strpos($kl, 'proposed') !== false) {
                    $company_meta[$key] = (string) $value;
                }
            }
        }
        return array(
            'woocommerce_order_id' => (string) $order->get_id(),
            'order_number'         => '#' . $order->get_order_number(),
            'wordpress_user_id'    => (string) $order->get_customer_id(),
            'email'                => $order->get_billing_email(),
            'full_name'            => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
            'phone'                => $order->get_billing_phone(),
            'company_name'         => self::extract_order_company_name($order),
            'billing_company'      => $order->get_billing_company(),
            'billing_address_1'    => $order->get_billing_address_1(),
            'billing_city'         => $order->get_billing_city(),
            'billing_postcode'     => $order->get_billing_postcode(),
            'billing_country'      => $order->get_billing_country() ?: 'United Kingdom',
            'service_name'         => !empty($item_names) ? implode(', ', $item_names) : 'Corporate Formation Service',
            'line_items'           => $items,
            'meta'                 => $company_meta,
            'price'                => (float) $order->get_subtotal(),
            'total'                => (float) $order->get_total(),
            'currency'             => $order->get_currency(),
            'status'               => ucfirst($order->get_status()),
            'created_at'           => $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : date('Y-m-d H:i:s'),
        );
    }

    /**
     * Handle WooCommerce Order Creation Event
     */
    public function on_order_created($order_id, $posted_data, $order) {
        if (!$order) {
            $order = wc_get_order($order_id);
        }
        if (!$order) return;
        Brixen_CRM_Webhook_Sender::send_event('order.created', self::build_order_payload($order));
    }

    /**
     * Handle WooCommerce Order Status Change Event
     */
    public function on_order_status_changed($order_id, $old_status, $new_status, $order) {
        if (!$order) {
            $order = wc_get_order($order_id);
        }
        if (!$order) return;

        $data = self::build_order_payload($order);
        $data['status'] = ucfirst($new_status);
        Brixen_CRM_Webhook_Sender::send_event('order.updated', $data);
    }

    /**
     * Handle WooCommerce Payment Complete Event
     */
    public function on_payment_complete($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        $data = array(
            'woocommerce_order_id' => (string) $order_id,
            'order_number'         => '#' . $order->get_order_number(),
            'wordpress_user_id'   => (string) $order->get_customer_id(),
            'email'                => $order->get_billing_email(),
            'status'               => 'Processing',
            'payment_status'       => 'Paid',
            'total'                => (float) $order->get_total(),
        );

        Brixen_CRM_Webhook_Sender::send_event('payment.completed', $data);
    }

    /**
     * Register WP Admin Menu Page
     */
    public function register_admin_menu() {
        add_menu_page(
            'Brixen CRM Sync',
            'Brixen CRM',
            'manage_options',
            'brixen-crm-sync',
            array($this, 'render_admin_settings_page'),
            'dashicons-cloud',
            80
        );
    }

    /**
     * Register Plugin Settings
     */
    public function register_settings() {
        register_setting('brixen_crm_options', 'brixen_crm_url');
        register_setting('brixen_crm_options', 'brixen_crm_webhook_secret');
    }

    /**
     * Render Plugin Admin Settings Page
     */
    public function render_admin_settings_page() {
        ?>
        <div class="wrap">
            <h1>Brixen Consultants CRM & WooCommerce Integration</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('brixen_crm_options');
                do_settings_sections('brixen_crm_options');
                ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">CRM Base URL</th>
                        <td>
                            <input type="url" name="brixen_crm_url" value="<?php echo esc_attr(get_option('brixen_crm_url', 'https://portal.brixenconsultants.com')); ?>" class="regular-text" placeholder="https://portal.brixenconsultants.com" required />
                            <p class="description">CRM endpoint and client dashboard: https://portal.brixenconsultants.com</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Webhook Secret</th>
                        <td>
                            <input type="password" name="brixen_crm_webhook_secret" value="<?php echo esc_attr(get_option('brixen_crm_webhook_secret', '')); ?>" class="regular-text" placeholder="Enter secure webhook secret" required />
                            <p class="description">Shared secret key used to compute HMAC-SHA256 signatures for webhook verification.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
            <hr />
            <h2>Sync existing website companies</h2>
            <p>Send past WooCommerce company-registration orders to the CRM Company Registered cards, including the company name from checkout.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="brixen_sync_orders" />
                <?php wp_nonce_field('brixen_sync_orders'); ?>
                <?php submit_button('Sync existing orders to CRM', 'secondary', 'submit', false); ?>
            </form>
            <?php if (isset($_GET['brixen_sync']) && $_GET['brixen_sync'] === 'ok') : ?>
                <div class="notice notice-success"><p>Existing website orders were sent to the CRM.</p></div>
            <?php elseif (isset($_GET['brixen_sync']) && $_GET['brixen_sync'] === 'err') : ?>
                <div class="notice notice-error"><p>The CRM sync could not finish. Check the CRM URL and webhook secret.</p></div>
            <?php endif; ?>
        </div>
        <?php
    }

    public function handle_sync_orders() {
        if (!current_user_can('manage_options') || !check_admin_referer('brixen_sync_orders')) {
            wp_die('Not allowed');
        }
        $result = Brixen_CRM_Bulk_Sync::sync_all_orders(500);
        $ok = is_array($result) && (isset($result['status']) && $result['status'] === 'success' || isset($result['summary']));
        wp_safe_redirect(add_query_arg('brixen_sync', $ok ? 'ok' : 'err', admin_url('admin.php?page=brixen-crm-sync')));
        exit;
    }

    /**
     * SSO Portal Link Shortcode [brixen_client_portal_button]
     */
    public function render_portal_sso_button() {
        if (!is_user_logged_in()) {
            return '<a href="' . esc_url(wp_login_url()) . '" class="button button-primary">Log In to Access Portal</a>';
        }

        $user = wp_get_current_user();
        $user_id = (string) $user->ID;
        $email = $user->user_email;
        $crm_url = rtrim(Brixen_CRM_Webhook_Sender::get_crm_url(), '/');
        $secret = Brixen_CRM_Webhook_Sender::get_webhook_secret();

        $timestamp = time();
        $payload_str = $user_id . '|' . $email . '|' . $timestamp;
        $signature = hash_hmac('sha256', $payload_str, $secret);

        $sso_url = add_query_arg(array(
            'wordpress_user_id' => $user_id,
            'email'             => $email,
            'timestamp'         => $timestamp,
            'signature'         => $signature,
        ), $crm_url . '/api/v1/auth/sso');

        return '<a href="' . esc_url($sso_url) . '" target="_blank" class="button button-primary brixen-portal-sso-btn" style="background:#003971; color:#fff; border-radius:9999px; padding:10px 24px; font-weight:700; text-decoration:none; display:inline-block;">Access Brixen Client Portal &rarr;</a>';
    }
}

register_activation_hook(__FILE__, 'brixen_crm_sync_on_activate');
function brixen_crm_sync_on_activate() {
    add_rewrite_endpoint('customer-messages', EP_ROOT | EP_PAGES);
    flush_rewrite_rules();
    if (!class_exists('WooCommerce') || !class_exists('Brixen_CRM_Bulk_Sync')) {
        return;
    }
    Brixen_CRM_Bulk_Sync::sync_all_orders(500);
}

// Defer initialization until ALL active plugins (including WooCommerce) are loaded
add_action('plugins_loaded', 'run_brixen_crm_sync_plugin');
function run_brixen_crm_sync_plugin() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-warning"><p>Brixen CRM Sync requires WooCommerce to be installed and active.</p></div>';
        });
        return;
    }
    return Brixen_CRM_Sync_Plugin::get_instance();
}
